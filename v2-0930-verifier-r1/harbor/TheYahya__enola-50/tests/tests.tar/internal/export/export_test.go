package export

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"
	"testing"
)

func TestCheckExportType(t *testing.T) {
	tests := []struct {
		path string
		want ExportType
	}{
		{"results.json", JSON},
		{"results.JSON", JSON},
		{"results.csv", CSV},
		{"results.txt", NotSupported},
	}

	for _, tt := range tests {
		if got := CheckExportType(tt.path); got != tt.want {
			t.Fatalf("CheckExportType(%q) = %q, want %q", tt.path, got, tt.want)
		}
	}
}

func TestNewWriterUnsupported(t *testing.T) {
	_, err := NewWriter("out.txt", nil)
	if err == nil {
		t.Fatal("expected error for unsupported format")
	}
}

func TestJSONWriterRoundTrip(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "out.json")
	items := []Item{
		{Title: "Twitter", URL: "https://twitter.com/alice", Found: true},
	}

	writer, err := NewWriter(path, items)
	if err != nil {
		t.Fatalf("NewWriter failed: %v", err)
	}
	if err := writer.Write(); err != nil {
		t.Fatalf("Write failed: %v", err)
	}

	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile failed: %v", err)
	}

	var got []Item
	if err := json.Unmarshal(data, &got); err != nil {
		t.Fatalf("json.Unmarshal failed: %v", err)
	}
	if len(got) != 1 || got[0].Title != "Twitter" || !got[0].Found {
		t.Fatalf("unexpected data: %+v", got)
	}
}

func TestCSVWriterRoundTrip(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "out.csv")
	items := []Item{
		{Title: "GitHub", URL: "https://github.com/alice", Found: false},
	}

	writer, err := NewWriter(path, items)
	if err != nil {
		t.Fatalf("NewWriter failed: %v", err)
	}
	if err := writer.Write(); err != nil {
		t.Fatalf("Write failed: %v", err)
	}

	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile failed: %v", err)
	}

	content := string(data)
	if !strings.Contains(content, "GitHub") || !strings.Contains(content, "false") {
		t.Fatalf("unexpected csv content: %q", content)
	}
}

func TestCheckExportTypeCaseInsensitiveCSV(t *testing.T) {
	if got := CheckExportType("results.CSV"); got != CSV {
		t.Fatalf("uppercase CSV suffix must select CSV, got %q", got)
	}
}

// A test-owned row describes the external format, independently of Item's
// JSON tags or the candidate's decoder. Order is not prescribed by the task.
type exportedRow struct {
	Title string
	URL   string
	Found bool
}

func requiredJSONRows(t *testing.T, data []byte) []exportedRow {
	t.Helper()
	var records []map[string]any
	if err := json.Unmarshal(data, &records); err != nil {
		t.Fatalf("export must contain one complete valid JSON array: %v", err)
	}
	rows := make([]exportedRow, 0, len(records))
	for _, record := range records {
		title, titleOK := record["title"].(string)
		url, urlOK := record["url"].(string)
		found, foundOK := record["found"].(bool)
		if !titleOK || !urlOK || !foundOK {
			t.Fatalf("JSON requires title/url string fields and found boolean: %#v", record)
		}
		rows = append(rows, exportedRow{title, url, found})
	}
	// Additional JSON fields are allowed; whitespace/key order are irrelevant.
	return rows
}

func requiredCSVRows(t *testing.T, data []byte) []exportedRow {
	t.Helper()
	reader := csv.NewReader(bytes.NewReader(data))
	reader.FieldsPerRecord = -1
	records, err := reader.ReadAll()
	if err != nil {
		t.Fatalf("export must contain complete valid CSV records: %v", err)
	}
	if len(records) == 0 || !reflect.DeepEqual(records[0], []string{"title", "url", "found"}) {
		t.Fatalf("CSV requires header title,url,found: %#v", records)
	}
	rows := make([]exportedRow, 0, len(records)-1)
	for _, record := range records[1:] {
		if len(record) != 3 {
			t.Fatalf("CSV data row requires exactly the three declared columns: %#v", record)
		}
		found, err := strconv.ParseBool(record[2])
		if err != nil {
			t.Fatalf("CSV found column must express its boolean value: %q", record[2])
		}
		rows = append(rows, exportedRow{record[0], record[1], found})
	}
	return rows
}

func exportRowCounts(rows []exportedRow) map[exportedRow]int {
	counts := make(map[exportedRow]int)
	for _, row := range rows {
		counts[row]++
	}
	return counts
}

func TestExportRequiredSchemaAndFileBehavior(t *testing.T) {
	items := []Item{
		{Title: `Comma, "quoted" site`, URL: "https://example.com/u/alice?x=one,two&y=three", Found: true},
		{Title: "Missing profile", URL: "https://other.example/profiles/alice", Found: false},
	}
	want := []exportedRow{
		{`Comma, "quoted" site`, "https://example.com/u/alice?x=one,two&y=three", true},
		{"Missing profile", "https://other.example/profiles/alice", false},
	}
	for _, suffix := range []string{".json", ".JSON", ".csv", ".CSV"} {
		for _, layout := range []string{"nested", "overwrite"} {
			t.Run(suffix+"/"+layout, func(t *testing.T) {
				path := filepath.Join(t.TempDir(), "parent", "child", "results"+suffix)
				if layout == "overwrite" {
					if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
						t.Fatal(err)
					}
					// Longer stale content must not remain as suffix or extra rows.
					if err := os.WriteFile(path, bytes.Repeat([]byte("STALE-EXPORT-DATA,"), 512), 0o600); err != nil {
						t.Fatal(err)
					}
				}
				writer, err := NewWriter(path, items)
				if err != nil {
					t.Fatalf("NewWriter must support the output path: %v", err)
				}
				if err := writer.Write(); err != nil {
					t.Fatalf("Write must create missing parents and replace existing output: %v", err)
				}
				data, err := os.ReadFile(path)
				if err != nil {
					t.Fatalf("ReadFile failed: %v", err)
				}
				var got []exportedRow
				if strings.EqualFold(suffix, ".json") {
					got = requiredJSONRows(t, data)
				} else {
					got = requiredCSVRows(t, data)
				}
				if !reflect.DeepEqual(exportRowCounts(got), exportRowCounts(want)) {
					t.Fatalf("exported rows must preserve every complete title/URL/found value exactly once: got %#v, want %#v", got, want)
				}
			})
		}
	}
}
