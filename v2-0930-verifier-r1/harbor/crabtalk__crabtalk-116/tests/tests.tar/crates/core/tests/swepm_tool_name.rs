//! Behavioral acceptance tests for the tool-result name contract.
//! These use the existing public Message API and serialized message format.

use crabtalk_core::model::Message;
use serde_json::json;

#[test]
fn constructor_preserves_each_tool_name_in_the_message_format() {
    for (name, content, call_id) in [
        ("bash", "command output", "call_shell"),
        ("lookup_document", "a document", "call_lookup"),
        ("fetch_weather", "", "call_empty_output"),
    ] {
        let message = Message::tool(content, call_id, name);
        let wire = serde_json::to_value(&message).unwrap();
        assert_eq!(wire["role"], "tool");
        assert_eq!(wire["name"], name, "the constructor must store its name argument");
        assert_eq!(wire["tool_call_id"], call_id);
        let restored: Message = serde_json::from_value(wire).unwrap();
        assert_eq!(serde_json::to_value(restored).unwrap()["name"], name);
    }
}

#[test]
fn deserialization_keeps_the_name_in_existing_message_records() {
    let wire = json!({
        "role": "tool",
        "content": "answer",
        "tool_call_id": "call_preserved",
        "name": "search_local_index"
    });
    let restored: Message = serde_json::from_value(wire.clone()).unwrap();
    let serialized = serde_json::to_value(restored).unwrap();
    for field in ["role", "content", "tool_call_id", "name"] {
        assert_eq!(serialized[field], wire[field], "round-trip changed {field}");
    }
}

#[test]
fn old_records_without_a_name_remain_readable() {
    for role in ["user", "assistant", "tool"] {
        let old = json!({"role": role, "content": "old content"});
        let restored: Message = serde_json::from_value(old).unwrap();
        let wire = serde_json::to_value(restored).unwrap();
        assert_eq!(wire["content"], "old content");
        assert!(wire.get("name").is_none_or(|name| name == ""));
    }
}
