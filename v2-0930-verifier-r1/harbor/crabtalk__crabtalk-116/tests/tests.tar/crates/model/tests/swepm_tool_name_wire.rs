//! Exercise the public Provider through a local HTTP peer, without an API key
//! or any external endpoint. In particular, test the real conversion layer.

use std::time::Duration;

use crabtalk_model::{Client, ProviderDef, build_provider};
use serde_json::{Value, json};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use wcore::model::{Message, Model, Request};

fn install_test_tls_provider() {
    static INITIALIZE: std::sync::Once = std::sync::Once::new();
    INITIALIZE.call_once(|| {
        // reqwest uses rustls-no-provider. Match CLI startup before constructing
        // a Client, including clients which only talk to this HTTP fixture.
        // Another test may already have installed the process-wide provider.
        let _ = rustls::crypto::ring::default_provider().install_default();
        assert!(rustls::crypto::CryptoProvider::get_default().is_some());
    });
}

#[tokio::test]
async fn provider_wire_format_preserves_both_tool_names_and_call_ids() {
    install_test_tls_provider();
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let peer = tokio::spawn(async move {
        let (mut socket, _) = tokio::time::timeout(Duration::from_secs(8), listener.accept())
            .await.expect("provider never reached the local fixture").unwrap();
        let mut request = Vec::new();
        let (header_end, content_length) = loop {
            let mut bytes = [0_u8; 4096];
            let count = tokio::time::timeout(Duration::from_secs(8), socket.read(&mut bytes))
                .await.expect("provider request timed out").unwrap();
            assert!(count > 0, "incomplete HTTP headers");
            request.extend_from_slice(&bytes[..count]);
            assert!(request.len() < 65536, "unexpectedly large fixture request");
            if let Some(end) = request.windows(4).position(|value| value == b"\r\n\r\n") {
                let headers = std::str::from_utf8(&request[..end]).unwrap();
                assert!(headers.starts_with("POST /v1/chat/completions "), "{headers}");
                let length: usize = headers.lines().find_map(|line| {
                    let (name, value) = line.split_once(':')?;
                    name.eq_ignore_ascii_case("content-length").then(|| value.trim().parse().unwrap())
                }).expect("JSON request must have a content length");
                break (end + 4, length);
            }
        };
        while request.len() < header_end + content_length {
            let mut bytes = [0_u8; 4096];
            let count = tokio::time::timeout(Duration::from_secs(8), socket.read(&mut bytes))
                .await.expect("provider body timed out").unwrap();
            assert!(count > 0, "incomplete HTTP body");
            request.extend_from_slice(&bytes[..count]);
            assert!(request.len() < 65536);
        }
        let body: Value = serde_json::from_slice(&request[header_end..header_end + content_length]).unwrap();
        let response = json!({
            "id": "offline-fixture", "object": "chat.completion", "created": 0,
            "model": "offline-model", "choices": [{"index": 0,
                "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}
        }).to_string();
        socket.write_all(format!(
            "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
            response.len(), response
        ).as_bytes()).await.unwrap();
        body
    });
    let definition: ProviderDef = serde_json::from_value(json!({
        "kind": "openai", "api_key": "offline-fixture-only", "models": ["offline-model"],
        "base_url": format!("http://{address}/v1/chat/completions"),
        "max_retries": 0, "timeout": 8
    })).unwrap();
    let client = Client::builder().no_proxy().build().unwrap();
    let provider = build_provider(&definition, "offline-model", client).unwrap();
    let request = Request::new("offline-model").with_messages(vec![
        Message::tool("shell output", "call_a", "bash"),
        Message::tool("search output", "call_b", "search_docs"),
    ]);
    provider.send(&request).await.expect("local provider response must be readable");
    let body = peer.await.unwrap();
    let messages = body["messages"].as_array().expect("messages array");
    assert_eq!(messages.len(), 2);
    for (message, name, call_id) in [(&messages[0], "bash", "call_a"), (&messages[1], "search_docs", "call_b")] {
        assert_eq!(message["role"], "tool");
        assert_eq!(message["name"], name, "provider conversion discarded the function name");
        assert_eq!(message["tool_call_id"], call_id);
    }
}
