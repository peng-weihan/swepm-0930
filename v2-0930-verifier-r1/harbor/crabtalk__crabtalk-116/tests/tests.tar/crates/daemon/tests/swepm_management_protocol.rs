//! Exercise the real daemon through its public local TCP protocol.
//! No production/private preset constant is imported or copied into the test.

use std::{path::PathBuf, time::{Duration, SystemTime, UNIX_EPOCH}};

use crabtalk_daemon::{Daemon, DaemonHandle, bridge_shutdown};
use crabtalk_daemon::daemon::event::DaemonEvent;
use serde_json::{Value, json};
use transport::tcp::TcpConnection;
use wcore::protocol::api::Client;

fn install_test_tls_provider() {
    static INITIALIZE: std::sync::Once = std::sync::Once::new();
    INITIALIZE.call_once(|| {
        // Mirror the CLI's rustls-no-provider initialization. This belongs to
        // the test process, not to any daemon/provider production change.
        let _ = rustls::crypto::ring::default_provider().install_default();
        assert!(rustls::crypto::CryptoProvider::get_default().is_some());
    });
}

struct Fixture {
    daemon: DaemonHandle,
    transport: tokio::task::JoinHandle<()>,
    client: TcpConnection,
    directory: PathBuf,
}

impl Fixture {
    async fn start() -> Self {
        install_test_tls_provider();
        // The harness sets TMPDIR to its persistent /logs/verifier/tmp bind.
        let root = std::env::var_os("TMPDIR").expect("set persistent TMPDIR before the test");
        let nonce = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        let directory = PathBuf::from(root).join(format!("swepm-crabtalk-{}-{nonce}", std::process::id()));
        std::fs::create_dir_all(&directory).unwrap();
        std::fs::write(directory.join("config.toml"), r#"
[provider.offline]
kind = "openai"
base_url = "http://127.0.0.1:9/v1"
api_key = "offline-fixture-only"
models = ["offline-model"]
max_retries = 0
timeout = 1
[system.crab]
model = "offline-model"
"#).unwrap();
        let daemon = tokio::time::timeout(Duration::from_secs(15), Daemon::start(&directory))
            .await.expect("daemon startup timed out").expect("offline daemon config should load");
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let events = daemon.event_tx.clone();
        let shutdown = bridge_shutdown(daemon.shutdown_tx.subscribe());
        let transport = tokio::spawn(transport::tcp::accept_loop(listener, move |msg, reply| {
            events.send(DaemonEvent::Message { msg, reply }).unwrap();
        }, shutdown));
        let client = TcpConnection::connect(address).await.unwrap();
        Self { daemon, transport, client, directory }
    }

    async fn close(self) {
        drop(self.client);
        tokio::time::timeout(Duration::from_secs(10), self.daemon.shutdown()).await
            .expect("daemon shutdown timed out").unwrap();
        tokio::time::timeout(Duration::from_secs(10), self.transport).await
            .expect("transport shutdown timed out").unwrap();
        // Preserve only this small fixture directory for failure investigation.
        eprintln!("SWEPM_DAEMON_FIXTURE={}", self.directory.display());
    }
}

#[tokio::test]
async fn list_provider_presets_includes_every_required_public_choice() {
    let mut fixture = Fixture::start().await;
    let presets = tokio::time::timeout(Duration::from_secs(10), fixture.client.list_provider_presets())
        .await.expect("ListProviderPresets timed out").expect("ListProviderPresets must be implemented");
    fixture.close().await;
    for required in ["anthropic", "openai", "google", "ollama", "azure", "custom"] {
        assert!(presets.iter().any(|preset| preset.name == required),
            "public ListProviderPresets omits required choice {required}");
    }
}

#[tokio::test]
async fn granular_provider_changes_round_trip_and_reject_unknown_names() {
    let mut fixture = Fixture::start().await;
    let result = tokio::time::timeout(Duration::from_secs(30), async {
        fixture.client.ping().await.unwrap();
        let candidate = json!({
            "kind": "openai", "base_url": "http://127.0.0.1:9/v1",
            "api_key": "second-offline-fixture", "models": ["second-offline-model", "another-offline-model"],
            "max_retries": 0, "timeout": 1
        });
        let response = fixture.client.set_provider("second".to_owned(), candidate.to_string()).await.unwrap();
        assert_eq!(response.name, "second");
        let loaded: Value = serde_json::from_str(&response.config).unwrap();
        // ProviderDef permits omitted default Openai kind; compare loaded semantics.
        let loaded_provider: wcore::ProviderDef = serde_json::from_str(&response.config).unwrap();
        assert_eq!(loaded_provider.kind, wcore::ApiStandard::Openai);
        assert!(loaded.get("standard").is_none(), "canonical config must use kind");
        let expected_provider: wcore::ProviderDef = serde_json::from_value(candidate.clone()).unwrap();
        assert_eq!(serde_json::to_value(&loaded_provider).unwrap(),
                   serde_json::to_value(&expected_provider).unwrap(),
                   "SetProvider must preserve the supplied provider configuration");
        assert_eq!(loaded["models"], json!(["second-offline-model", "another-offline-model"]));
        let listed = fixture.client.list_providers().await.unwrap();
        let matches: Vec<_> = listed.iter().filter(|provider| provider.name == "second").collect();
        assert_eq!(matches.len(), 1, "one provider entry is returned regardless of its model count");
        let listed_json: Value = serde_json::from_str(&matches[0].config).unwrap();
        assert!(listed_json.get("standard").is_none(), "listed canonical config must use kind");
        let listed_provider: wcore::ProviderDef = serde_json::from_value(listed_json).unwrap();
        assert_eq!(serde_json::to_value(&listed_provider).unwrap(),
                   serde_json::to_value(&expected_provider).unwrap(),
                   "ListProviders must return the complete provider configuration");

        fixture.client.set_active_model("second-offline-model".to_owned()).await.unwrap();
        let config: Value = serde_json::from_str(&fixture.client.get_config().await.unwrap()).unwrap();
        assert_eq!(config["system"]["crab"]["model"], "second-offline-model");
        let missing_model = fixture.client.set_active_model("swepm-missing-model".to_owned()).await.unwrap_err();
        assert!(missing_model.to_string().contains("model 'swepm-missing-model' not found in any provider"));
        let missing_provider = fixture.client.delete_provider("swepm-missing-provider".to_owned()).await.unwrap_err();
        assert!(missing_provider.to_string().contains("provider 'swepm-missing-provider' not found"));

        // Duplicate model names must be rejected before any invalid config is persisted.
        let duplicate = json!({"kind": "openai", "base_url": "http://127.0.0.1:9/v1",
            "api_key": "unused", "models": ["offline-model"]});
        assert!(fixture.client.set_provider("bad-duplicate".to_owned(), duplicate.to_string()).await.is_err());
        assert!(!fixture.client.list_providers().await.unwrap().iter().any(|provider| provider.name == "bad-duplicate"));

        fixture.client.set_active_model("offline-model".to_owned()).await.unwrap();
        fixture.client.delete_provider("second".to_owned()).await.unwrap();
        assert!(!fixture.client.list_providers().await.unwrap().iter().any(|provider| provider.name == "second"));
    }).await;
    fixture.close().await;
    result.expect("management protocol scenario timed out");
}


#[tokio::test]
async fn local_mcp_configuration_preserves_round_trippable_fields() {
    use wcore::protocol::message::McpInfo;
    let mut fixture = Fixture::start().await;
    let result = tokio::time::timeout(Duration::from_secs(30), async {
        // Connections may fail immediately: these are local config-only fixtures,
        // not real remote MCP services. No provider inference is requested.
        let stdio = McpInfo {
            name: "swepm-local-stdio".to_owned(),
            command: "/bin/false".to_owned(),
            args: vec!["swepm-argument".to_owned(), "value with spaces".to_owned()],
            env: [("SWEPM_SAMPLE".to_owned(), "value=with spaces".to_owned())].into(),
            url: String::new(), auth: true, source: "local".to_owned(), auto_restart: true,
        };
        let http = McpInfo {
            name: "swepm-local-http".to_owned(), command: String::new(), args: vec![],
            env: [("SWEPM_HTTP".to_owned(), "opaque-value".to_owned())].into(),
            url: "http://127.0.0.1:1/mcp".to_owned(), auth: true,
            source: "local".to_owned(), auto_restart: true,
        };
        let original = vec![stdio, http];
        fixture.client.set_local_mcps(original.clone()).await.unwrap();
        let first = fixture.client.list_mcps().await.unwrap();
        for expected in &original {
            let rows: Vec<_> = first.iter().filter(|m| m.name == expected.name).collect();
            assert_eq!(rows.len(), 1, "saved MCP must be listed exactly once");
            let actual = rows[0];
            assert_eq!(actual.command, expected.command);
            assert_eq!(actual.args, expected.args);
            assert_eq!(actual.env, expected.env);
            assert_eq!(actual.url, expected.url);
            assert_eq!(actual.auth, expected.auth);
            assert_eq!(actual.auto_restart, expected.auto_restart);
            assert!(!actual.source.is_empty(), "MCP source must be reported");
        }
        // Auth UI style read-modify-write: saving the returned representation
        // must not lose fields on the second round trip either.
        let mut updated = first;
        for config in &mut updated {
            config.auth = false;
            config.auto_restart = false;
            config.env.insert("SWEPM_UPDATED".to_owned(), "second".to_owned());
        }
        fixture.client.set_local_mcps(updated.clone()).await.unwrap();
        let second = fixture.client.list_mcps().await.unwrap();
        for expected in &updated {
            let actual = second.iter().find(|m| m.name == expected.name).unwrap();
            assert_eq!(actual.command, expected.command);
            assert_eq!(actual.args, expected.args);
            assert_eq!(actual.env, expected.env);
            assert_eq!(actual.url, expected.url);
            assert_eq!(actual.auth, expected.auth);
            assert_eq!(actual.auto_restart, expected.auto_restart);
            assert!(!actual.source.is_empty());
        }
    }).await;
    fixture.close().await;
    result.expect("MCP config roundtrip timed out");
}
