import type { ICommand, IMutation, IWorkbookData, Workbook } from '@univerjs/core';
import {
    CommandType,
    ICommandService,
    IUndoRedoService,
    IUniverInstanceService,
    LocaleService,
    LocaleType,
    LogLevel,
    RedoCommand,
    UndoCommand,
    Univer,
    UniverInstanceType,
} from '@univerjs/core';
import * as sheetAPI from '@univerjs/sheets';
import * as tableAPI from '@univerjs/sheets-table';
import { afterEach, describe, expect, it, vi } from 'vitest';

const UNIT = 'direct-command-workbook';
const SHEET = 'sheet-with-table';
const TABLE = 'target-table';
const initialRange = { startRow: 0, endRow: 4, startColumn: 1, endColumn: 3 };
const originalColumnIds = new Set(['left-column', 'middle-column', 'right-column']);
const disposables: Univer[] = [];

afterEach(() => {
    for (const univer of disposables.splice(0)) univer.dispose();
});

// Real workbook, table, command dispatcher and undo service. No mock method
// specifies how a candidate must find a table or construct mutation payloads.
function fixture() {
    const univer = new Univer({ locale: LocaleType.EN_US, logLevel: LogLevel.SILENT });
    disposables.push(univer);
    const injector = univer.__getInjector(); // Existing core test-fixture access only.
    injector.add([tableAPI.TableManager]);
    injector.get(LocaleService).load({ enUS: { 'sheets-table': { columnPrefix: 'Field' } } });

    const cellData: Record<number, Record<number, { v: string }>> = {};
    for (let row = 0; row <= 6; row++) {
        cellData[row] = {};
        for (let col = 0; col <= 5; col++) cellData[row][col] = { v: `r${row}c${col}` };
    }
    const workbook = univer.createUnit<IWorkbookData, Workbook>(UniverInstanceType.UNIVER_SHEET, {
        id: UNIT,
        name: 'Direct commands',
        locale: LocaleType.EN_US,
        appVersion: '3.0.0-alpha',
        styles: {},
        sheetOrder: [SHEET, 'other-sheet'],
        sheets: {
            [SHEET]: { id: SHEET, name: 'Main', rowCount: 30, columnCount: 30, cellData },
            'other-sheet': { id: 'other-sheet', name: 'Other', rowCount: 30, columnCount: 30 },
        },
    });
    injector.get(IUniverInstanceService).focusUnit(UNIT);
    const worksheet = workbook.getSheetBySheetId(SHEET)!;
    const manager = injector.get(tableAPI.TableManager);
    manager.addTable(UNIT, SHEET, 'TargetTable', { ...initialRange }, ['Left', 'Middle', 'Right'], TABLE, {
        columns: [['left-column', 'Left'], ['middle-column', 'Middle'], ['right-column', 'Right']].map(([id, displayName]) => ({
            id, displayName, dataType: tableAPI.TableColumnDataTypeEnum.String, formula: '', meta: {}, style: {},
        })),
    });
    const table = manager.getTable(UNIT, TABLE)!;
    // Distinct public metadata must survive deleting and undoing the middle column.
    table.getTableColumnByIndex(1)!.setMeta({ purpose: 'preserve-on-undo' });
    manager.addTable(UNIT, 'other-sheet', 'OtherTable', { ...initialRange }, ['A', 'B', 'C'], 'other-table');

    const commands = injector.get(ICommandService);
    const undo = injector.get(IUndoRedoService); // Registers the existing Undo/Redo commands.
    const mutationIds = new Set<string>();
    // Admit all existing public mutations, including equivalent implementations;
    // never whitelist the gold handler's chosen list or inspect its params.
    for (const candidate of [...Object.values(sheetAPI), ...Object.values(tableAPI)]) {
        if (candidate && typeof candidate === 'object'
            && 'type' in candidate && candidate.type === CommandType.MUTATION
            && 'id' in candidate && typeof candidate.id === 'string'
            && 'handler' in candidate && typeof candidate.handler === 'function'
            && !mutationIds.has(candidate.id)) {
            commands.registerCommand(candidate as IMutation);
            mutationIds.add(candidate.id);
        }
    }
    for (const command of operations.map(({ command }) => command)) commands.registerCommand(command);
    const executedMutations: string[] = [];
    commands.onCommandExecuted(({ id }) => {
        if (mutationIds.has(id)) executedMutations.push(id);
    });

    const cell = (row: number, col: number) => worksheet.getCellMatrix().getValue(row, col)?.v ?? null;
    const currentTable = () => manager.getTable(UNIT, TABLE)!;
    const columns = () => structuredClone(currentTable().getTableInfo().columns);
    const state = () => ({
        range: structuredClone(currentTable().getRange()),
        columns: columns().map((column) => ({
            ...column,
            // Newly allocated IDs need not be identical after undo + redo.
            id: originalColumnIds.has(column.id) ? column.id : '<new-column>',
        })),
        cells: Array.from({ length: 10 }, (_, row) => Array.from({ length: 10 }, (_, col) => cell(row, col))),
    });
    return { commands, undo, get table() { return currentTable(); }, cell, columns, state, executedMutations };
}

const operations = [
    { name: 'row insertion', kind: 'row', command: tableAPI.SheetTableInsertRowAtCommand },
    { name: 'column insertion', kind: 'insert-column', command: tableAPI.SheetTableInsertColumnAtCommand },
    { name: 'column removal', kind: 'remove-column', command: tableAPI.SheetTableRemoveColumnAtCommand },
] as const;

function assertEffect(f: ReturnType<typeof fixture>, kind: string, count: number, oldColumns: ReturnType<typeof f.columns>) {
    if (kind === 'row') {
        expect(f.table.getRange(), 'row insertion changes the table range').toEqual({ ...initialRange, endRow: 4 + count });
        expect(f.columns(), 'row insertion preserves column metadata').toEqual(oldColumns);
        expect(f.cell(1, 2), 'preceding table row is unchanged').toBe('r1c2');
        for (let i = 0; i < count; i++) expect(f.cell(2 + i, 2), 'new row slot is empty').toBeNull();
        expect(f.cell(2 + count, 2), 'in-table cells move down at the requested index').toBe('r2c2');
        expect(f.cell(6 + count, 3), 'trailing cells below the table move down').toBe('r6c3');
        expect(f.cell(2, 0), 'cells left of the table are unaffected').toBe('r2c0');
        expect(f.cell(2, 5), 'cells right of the table are unaffected').toBe('r2c5');
    } else if (kind === 'insert-column') {
        expect(f.table.getRange(), 'column insertion changes the table range').toEqual({ ...initialRange, endColumn: 3 + count });
        const columns = f.columns();
        expect(columns.length, 'column metadata grows by count').toBe(3 + count);
        expect(columns.slice(0, 1), 'metadata before the insertion is preserved').toEqual(oldColumns.slice(0, 1));
        expect(columns.slice(1 + count), 'existing columns shift without metadata loss').toEqual(oldColumns.slice(1));
        expect(f.cell(2, 1), 'preceding table column is unchanged').toBe('r2c1');
        for (let i = 0; i < count; i++) expect(f.cell(2, 2 + i), 'new column slot is empty').toBeNull();
        expect(f.cell(2, 2 + count), 'in-table cells move right at the requested index').toBe('r2c2');
        expect(f.cell(4, 5 + count), 'trailing cells right of the table move right').toBe('r4c5');
        expect(f.cell(6, 2), 'cells below the table are unaffected').toBe('r6c2');
    } else {
        expect(f.table.getRange(), 'column removal changes the table range').toEqual({ ...initialRange, endColumn: 3 - count });
        expect(f.columns(), 'only the requested column metadata is removed').toEqual([
            ...oldColumns.slice(0, 1), ...oldColumns.slice(1 + count),
        ]);
        expect(f.cell(2, 1), 'preceding table column is unchanged').toBe('r2c1');
        expect(f.cell(2, 2), 'successor cells move into the removed column').toBe(`r2c${2 + count}`);
        expect(f.cell(4, 5 - count), 'trailing cells right of the table move left').toBe('r4c5');
        for (let i = 0; i < count; i++) expect(f.cell(2, 5 - i), 'vacated trailing slots are empty').toBeNull();
        expect(f.cell(6, 2), 'cells below the table are unaffected').toBe('r6c2');
    }
}

describe('direct table commands through real state and history', () => {
    for (const { name, kind, command } of operations) {
        it.each([1, 2])(`${name} with count %i changes state, undoes and redoes`, (count) => {
            const f = fixture();
            const before = f.state();
            const oldColumns = f.columns();
            expect(f.commands.syncExecuteCommand(command.id, { unitId: UNIT, subUnitId: SHEET, tableId: TABLE, index: 2, count })).toBe(true);
            assertEffect(f, kind, count, oldColumns);
            expect(f.executedMutations.length, 'successful operation executes real mutations through command service').toBeGreaterThan(0);
            expect(f.undo.pitchTopUndoElement()?.unitID, 'history belongs to the requested workbook').toBe(UNIT);
            const after = f.state();
            expect(f.commands.syncExecuteCommand(UndoCommand.id), 'public undo succeeds').toBe(true);
            expect(f.state(), 'undo restores cells, range and original column metadata').toEqual(before);
            expect(f.commands.syncExecuteCommand(RedoCommand.id), 'public redo succeeds').toBe(true);
            expect(f.state(), 'redo reproduces the observable operation').toEqual(after);
        });

        const invalid = [
            ['missing params', undefined],
            ['zero count', { count: 0 }],
            ['negative count', { count: -1 }],
            ['missing workbook target', { unitId: 'missing-workbook' }],
            ['missing worksheet target', { subUnitId: 'missing-sheet' }],
            ['missing table', { tableId: 'missing-table' }],
            ['table belongs to another worksheet', { tableId: 'other-table' }],
            ['index before table', { index: -1 }],
            ['index after table', { index: 1000 }],
        ] as const;
        it.each(invalid)(`${name} rejects %s without changing state`, (_label, overrides) => {
            const f = fixture();
            const before = f.state();
            const params = overrides === undefined ? undefined : {
                unitId: UNIT, subUnitId: SHEET, tableId: TABLE, index: 2, count: 1, ...overrides,
            };
            expect(f.commands.syncExecuteCommand((command as ICommand).id, params), 'invalid request returns false').toBe(false);
            expect(f.state(), 'invalid request leaves all observable table and cell state intact').toEqual(before);
            expect(f.undo.pitchTopUndoElement(), 'invalid request adds no undo item').toBeNull();
        });
    }
});

// The three original legacy-command assertions are retained. Local fixtures
// replace the old module-wide mock so direct commands use the real sheet API.
function createAccessor(pairs: Array<[unknown, unknown]>) {
    const map = new Map<unknown, unknown>(pairs);
    return {
        get(token: unknown) {
            if (!map.has(token)) throw new Error(`Unknown token: ${String(token)}`);
            return map.get(token);
        },
    } as any;
}

const {
    SheetTableInsertRowCommand, SheetTableInsertColCommand,
    SheetTableRemoveRowCommand, SheetTableRemoveColCommand,
} = tableAPI;

describe('sheet-table-row-col commands', () => {
    it('insert commands should return false when there is no sheet target', () => {
        const accessor = createAccessor([
            [IUniverInstanceService, { getCurrentUnitOfType: () => null }],
        ]);
        expect(SheetTableInsertRowCommand.handler(accessor)).toBe(false);
        expect(SheetTableInsertColCommand.handler(accessor)).toBe(false);
    });

    it('remove commands should return false for invalid params', () => {
        const accessor = createAccessor([[IUniverInstanceService, {}]]);
        expect(SheetTableRemoveRowCommand.handler(accessor, undefined as any)).toBe(false);
        expect(SheetTableRemoveColCommand.handler(accessor, undefined as any)).toBe(false);
    });

    it('commands should stop when current selection is invalid or table is missing', () => {
        const worksheet = {
            getSheetId: () => 's1',
            getRowCount: () => 100,
            getColumnCount: () => 100,
            getCellMatrix: () => ({ getDataRange: () => ({ endRow: 10, endColumn: 10 }) }),
        };
        const workbook = {
            getUnitId: () => 'u1',
            getActiveSheet: () => worksheet,
            getSheetBySheetId: () => worksheet,
        };
        const accessor = createAccessor([
            [IUniverInstanceService, { getUnit: () => workbook, getCurrentUnitOfType: () => workbook }],
            [sheetAPI.SheetsSelectionsService, { getCurrentSelections: () => [] }],
            [tableAPI.SheetsTableController, { getContainerTableWithRange: () => null }],
            [tableAPI.TableManager, {}],
            [ICommandService, { syncExecuteCommand: vi.fn(() => true) }],
            [IUndoRedoService, { pushUndoRedo: vi.fn() }],
        ]);
        expect(SheetTableInsertRowCommand.handler(accessor)).toBe(false);
        expect(SheetTableInsertColCommand.handler(accessor)).toBe(false);
        expect(SheetTableRemoveRowCommand.handler(accessor, { unitId: 'u1', subUnitId: 's1', tableId: 't1' } as any)).toBe(false);
        expect(SheetTableRemoveColCommand.handler(accessor, { unitId: 'u1', subUnitId: 's1', tableId: 't1' } as any)).toBe(false);
    });
});

// Public range-growth contract: localized prefix, with no prescribed numbering,
// separator, generated identifier, insertion algorithm or private lookup method.
describe('table range growth uses the active localized column prefix', () => {
    it.each([
        ['leading', { startRow: 0, endRow: 4, startColumn: 0, endColumn: 3 }, 1],
        ['trailing', { startRow: 0, endRow: 4, startColumn: 1, endColumn: 5 }, 2],
    ] as const)('uses the locale prefix for %s growth and preserves existing columns', (_side, newRange, addedCount) => {
        const expectedPrefix = '独特列名前缀Ω';
        const univer = new Univer({ locale: LocaleType.EN_US, logLevel: LogLevel.SILENT });
        disposables.push(univer);
        const injector = univer.__getInjector();
        injector.get(LocaleService).load({ enUS: { 'sheets-table': { columnPrefix: expectedPrefix } } });
        injector.add([tableAPI.TableManager]);
        const manager = injector.get(tableAPI.TableManager);
        manager.addTable(UNIT, SHEET, 'LocalizedGrowth', { ...initialRange }, ['Left', 'Middle', 'Right'], TABLE);
        manager.getTable(UNIT, TABLE)!.getTableColumnByIndex(1)!.setMeta({ note: 'keep-existing-metadata' });
        const before = structuredClone(manager.getTable(UNIT, TABLE)!.getTableInfo().columns);
        const oldIds = new Set(before.map(column => column.id));

        manager.updateTableRange(UNIT, TABLE, { newRange: { ...newRange } });

        const after = structuredClone(manager.getTable(UNIT, TABLE)!.getTableInfo().columns);
        expect(manager.getTable(UNIT, TABLE)!.getRange(), 'requested expanded range is observable').toEqual(newRange);
        expect(after.filter(column => oldIds.has(column.id)), 'range growth preserves existing ordered column metadata').toEqual(before);
        const added = after.filter(column => !oldIds.has(column.id));
        expect(added.length, 'range growth creates the required number of columns').toBe(addedCount);
        for (const column of added) {
            expect(column.displayName, 'new column display name includes the active localized prefix').toContain(expectedPrefix);
        }
    });
});

// Observe ordinary public plugin startup. The probe only receives a service;
// it does not register commands or manually install candidate dependencies.
import { Inject, Injector, Plugin } from '@univerjs/core';

describe('table plugin registers direct commands at normal startup', () => {
    it.each([
        ['row insertion', tableAPI.SheetTableInsertRowAtCommand],
        ['column insertion', tableAPI.SheetTableInsertColumnAtCommand],
        ['column removal', tableAPI.SheetTableRemoveColumnAtCommand],
    ] as const)('registers %s through the public command service', (_label, command) => {
        let commands: ICommandService | undefined;
        class CommandServiceProbe extends Plugin {
            static override pluginName = 'test-passive-command-service-probe';
            static override type = UniverInstanceType.UNIVER_SHEET;

            constructor(
                _options: undefined,
                @Inject(Injector) protected override _injector: Injector,
                @ICommandService commandService: ICommandService
            ) {
                super();
                commands = commandService;
            }
        }

        const univer = new Univer({ locale: LocaleType.EN_US, logLevel: LogLevel.SILENT });
        disposables.push(univer);
        univer.registerPlugin(sheetAPI.UniverSheetsPlugin);
        univer.registerPlugin(tableAPI.UniverSheetsTablePlugin);
        univer.registerPlugin(CommandServiceProbe);
        univer.createUnit<IWorkbookData, Workbook>(UniverInstanceType.UNIVER_SHEET, {
            id: 'native-registration-workbook',
            name: 'Native registration',
            locale: LocaleType.EN_US,
            appVersion: '3.0.0-alpha',
            styles: {},
            sheetOrder: ['native-registration-sheet'],
            sheets: {
                'native-registration-sheet': {
                    id: 'native-registration-sheet', name: 'Sheet', rowCount: 20, columnCount: 20,
                },
            },
        });

        expect(commands, 'passive plugin receives the actual command service').toBeDefined();
        expect(commands!.hasCommand(command.id), 'native plugin command registration').toBe(true);
        expect(commands!.syncExecuteCommand(command.id)).toBe(false);
    });
});
