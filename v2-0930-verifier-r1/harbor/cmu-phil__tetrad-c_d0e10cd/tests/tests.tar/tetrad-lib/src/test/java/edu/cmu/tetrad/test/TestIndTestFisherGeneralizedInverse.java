///////////////////////////////////////////////////////////////////////////////
// For information as to what this class does, see the Javadoc, below.       //
//                                                                           //
// Copyright (C) 2025 by Joseph Ramsey, Peter Spirtes, Clark Glymour,        //
// and Richard Scheines.                                                     //
//                                                                           //
// This program is free software: you can redistribute it and/or modify      //
// it under the terms of the GNU General Public License as published by      //
// the Free Software Foundation, either version 3 of the License, or         //
// (at your option) any later version.                                       //
//                                                                           //
// This program is distributed in the hope that it will be useful,           //
// but WITHOUT ANY WARRANTY; without even the implied warranty of            //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             //
// GNU General Public License for more details.                              //
//                                                                           //
// You should have received a copy of the GNU General Public License         //
// along with this program.  If not, see <https://www.gnu.org/licenses/>.    //
///////////////////////////////////////////////////////////////////////////////

package edu.cmu.tetrad.test;

import edu.cmu.tetrad.data.DataSet;
import edu.cmu.tetrad.graph.*;
import edu.cmu.tetrad.search.test.IndTestFisherZ;
import edu.cmu.tetrad.search.test.IndependenceResult;
import edu.cmu.tetrad.sem.SemIm;
import edu.cmu.tetrad.sem.SemPm;
import edu.cmu.tetrad.util.RandomUtil;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Tests the IndTestTimeSeries class.
 *
 * @author josephramsey
 */
public class TestIndTestFisherGeneralizedInverse {

    @Test
    public void testDirections() {
        RandomUtil.getInstance().setSeed(48285934L);

        Graph graph1 = new EdgeListGraph();
        Graph graph2 = new EdgeListGraph();

        Node x = new GraphNode("X");
        Node y = new GraphNode("Y");
        Node z = new GraphNode("Z");

        graph1.addNode(x);
        graph1.addNode(y);
        graph1.addNode(z);

        graph2.addNode(x);
        graph2.addNode(y);
        graph2.addNode(z);

        graph1.addEdge(Edges.directedEdge(x, y));
        graph1.addEdge(Edges.directedEdge(y, z));

        graph2.addEdge(Edges.directedEdge(x, y));
        graph2.addEdge(Edges.directedEdge(z, y));

        SemPm pm1 = new SemPm(graph1);
        SemPm pm2 = new SemPm(graph2);

        SemIm im1 = new SemIm(pm1);
        SemIm im2 = new SemIm(pm2);

        im2.setEdgeCoef(x, y, im1.getEdgeCoef(x, y));
        im2.setEdgeCoef(z, y, im1.getEdgeCoef(y, z));

        DataSet data1 = im1.simulateData(500, false);
        DataSet data2 = im2.simulateData(500, false);

        IndTestFisherZ test1 = new IndTestFisherZ(data1, 0.05);
        IndTestFisherZ test2 = new IndTestFisherZ(data2, 0.05);

        double lambda = 0.0;

        test1.setLambda(lambda);
        test2.setLambda(lambda);

        double p1 = 0;
        double p2 = 0;
        double p3 = 0;
        try {
            IndependenceResult result1 = test1.checkIndependence(data1.getVariable(x.getName()), data1.getVariable(y.getName()));
            p1 = result1.getPValue();

            IndependenceResult result2 = test2.checkIndependence(data2.getVariable(x.getName()), data2.getVariable(z.getName()),
                    data2.getVariable(y.getName()));
            p2 = result2.getPValue();

            IndependenceResult result3 = test2.checkIndependence(data2.getVariable(x.getName()), data2.getVariable(z.getName()));
            p3 = result3.getPValue();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        assertEquals(0, p1, 0.01);
        assertEquals(0, p2, 0.01);
        assertEquals(0.86, p3, 0.01);
    }
}






