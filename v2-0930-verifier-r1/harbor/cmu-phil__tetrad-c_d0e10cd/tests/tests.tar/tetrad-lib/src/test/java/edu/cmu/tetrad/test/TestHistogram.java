///////////////////////////////////////////////////////////////////////////////
// For information as to what this class does, see the Javadoc, below.       //
//                                                                           //
// Copyright (C) 2025 by Joseph Ramsey, Peter Spirtes, Clark Glymour,        //
// and Richard Scheines.                                                     //
//                                                                           //
// This program is free software: you can redistribute it and/or modify      //
// it under the terms of the GNU General Public License as published by      //
// the Free Software Foundation, either version 3 of the License, or         //
// (at your option) any later version.                                       //
//                                                                           //
// This program is distributed in the hope that it will be useful,           //
// but WITHOUT ANY WARRANTY; without even the implied warranty of            //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             //
// GNU General Public License for more details.                              //
//                                                                           //
// You should have received a copy of the GNU General Public License         //
// along with this program.  If not, see <https://www.gnu.org/licenses/>.    //
///////////////////////////////////////////////////////////////////////////////

package edu.cmu.tetrad.test;

import edu.cmu.tetrad.bayes.BayesIm;
import edu.cmu.tetrad.bayes.BayesPm;
import edu.cmu.tetrad.bayes.MlBayesIm;
import edu.cmu.tetrad.data.ContinuousVariable;
import edu.cmu.tetrad.data.DataSet;
import edu.cmu.tetrad.data.Histogram;
import edu.cmu.tetrad.graph.Dag;
import edu.cmu.tetrad.graph.Node;
import edu.cmu.tetrad.graph.RandomGraph;
import edu.cmu.tetrad.sem.SemIm;
import edu.cmu.tetrad.sem.SemPm;
import edu.cmu.tetrad.util.StatUtils;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Tests the Knowledge class.
 *
 * @author josephramsey
 */
public final class TestHistogram {

    @Test
    public void testHistogram() {
//        RandomUtil.getInstance().setSeed(4829384L);

        List<Node> nodes = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            nodes.add(new ContinuousVariable("X" + (i + 1)));
        }

        Dag trueGraph = new Dag(RandomGraph.randomGraph(nodes, 0, 5, 30,
                15, 15, false, 4829384L));
        final int sampleSize = 1000;

        // Continuous
        SemPm semPm = new SemPm(trueGraph);
        SemIm semIm = new SemIm(semPm);
        DataSet data = semIm.simulateData(sampleSize, false);

        Histogram histogram = new Histogram(data, "X1", false);
//        histogram.setTarget("X1");
        histogram.setNumBins(20);

        assertEquals(4.709, histogram.getMax(), 0.01);
        assertEquals(-6.78, histogram.getMin(), 0.01);
        assertEquals(1000, histogram.getN());

//        histogram.setTarget("X1");
        histogram.setNumBins(10);
        histogram.addConditioningVariable("X3", 0, 1);
        histogram.addConditioningVariable("X4", 0, 1);

        histogram.removeConditioningVariable("X3");

        assertEquals(4.709, histogram.getMax(), 0.01);
        assertEquals(-6.78, histogram.getMin(), 0.01);
//        assertEquals( 142, histogram.getN());

        double[] arr = histogram.getContinuousData("X2");
        histogram.addConditioningVariable("X2", StatUtils.min(arr), StatUtils.mean(arr));

        // Discrete
        BayesPm bayesPm = new BayesPm(trueGraph);
        BayesIm bayesIm = new MlBayesIm(bayesPm, MlBayesIm.InitializationMethod.RANDOM);
        DataSet data2 = bayesIm.simulateData(sampleSize, false);

        // For some reason these are giving different
        // values when all of the unit tests are run are
        // once. TODO They produce stable values when
        // this particular test is run repeatedly.
        Histogram histogram2 = new Histogram(data2, "X1", false);
//        histogram2.setTarget("X1");
        histogram2.getFrequencies();

//        histogram2.setTarget("X1");
        histogram2.addConditioningVariable("X2", 0);
        histogram2.addConditioningVariable("X3", 1);
        histogram2.getFrequencies();
    }
}






