///////////////////////////////////////////////////////////////////////////////
// For information as to what this class does, see the Javadoc, below.       //
//                                                                           //
// Copyright (C) 2025 by Joseph Ramsey, Peter Spirtes, Clark Glymour,        //
// and Richard Scheines.                                                     //
//                                                                           //
// This program is free software: you can redistribute it and/or modify      //
// it under the terms of the GNU General Public License as published by      //
// the Free Software Foundation, either version 3 of the License, or         //
// (at your option) any later version.                                       //
//                                                                           //
// This program is distributed in the hope that it will be useful,           //
// but WITHOUT ANY WARRANTY; without even the implied warranty of            //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             //
// GNU General Public License for more details.                              //
//                                                                           //
// You should have received a copy of the GNU General Public License         //
// along with this program.  If not, see <https://www.gnu.org/licenses/>.    //
///////////////////////////////////////////////////////////////////////////////

package edu.cmu.tetrad.test;

import edu.cmu.tetrad.data.*;
import edu.cmu.tetrad.graph.Node;
import edu.cmu.tetrad.util.RandomUtil;
import org.junit.Test;

import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Tests CovarianceMatrix.
 *
 * @author josephramsey
 */
public final class TestCovarianceMatrix {

    /**
     * Tests construction.
     */
    @Test
    public void testConstruction() {
        RandomUtil.getInstance().setSeed(4828384834L);

        List<Node> variables = new LinkedList<>();

        for (int i = 0; i < 5; i++) {
            ContinuousVariable var = new ContinuousVariable("X" + i);
            variables.add(var);
        }

        DataSet dataSet = new BoxDataSet(new DoubleDataBox(10, variables.size()), variables);

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 5; j++) {
                dataSet.setDouble(i, j, RandomUtil.getInstance().nextDouble());
            }
        }

        DataSet _dataSet = dataSet.copy();

        ICovarianceMatrix c1 = new CovarianceMatrix(dataSet);
        ICovarianceMatrix c2 = new CovarianceMatrix(dataSet);
        CorrelationMatrix c3 = new CorrelationMatrix(c1);

        System.out.println(c3);

        assertEquals(.065, c1.getValue(0, 0), 0.001);
        assertEquals(.064, c2.getValue(0, 0), 0.001);
        assertEquals(1.0, c3.getValue(0, 0), 0.001);

        // In place should modify the original covariance matrix.
        CorrelationMatrix c4 = new CorrelationMatrix(c1);
//        assertEquals(1, c1.getValue(0, 0), 0.001);

        c1 = new CovarianceMatrix(_dataSet);
        c2 = new CovarianceMatrix(_dataSet);
        c3 = new CorrelationMatrix(c1);

        assertEquals(0.03, c1.getValue(0, 1), 0.001);
        assertEquals(0.03, c2.getValue(0, 1), 0.001);
        assertEquals(0.443, c3.getValue(0, 1), 0.001);
    }
}






