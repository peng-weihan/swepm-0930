"""Tests for provider error mapping and core error formatting."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import openai
import pytest
from httpx import HTTPStatusError, ReadTimeout, Request, Response

from config.constants import PROVIDER_ERROR_BODY_DISPLAY_CAP_BYTES
from core.anthropic import (
    append_request_id,
    format_user_error_preview,
    get_user_facing_error_message,
)
from providers.error_mapping import (
    attach_provider_error_body,
    extract_provider_error_detail,
    format_provider_error_message,
    map_error,
    user_visible_message_for_mapped_provider_error,
)
from providers.exceptions import (
    APIError,
    AuthenticationError,
    InvalidRequestError,
    OverloadedError,
    RateLimitError,
)


def _make_openai_error(cls, message="test error", status_code=None):
    """Helper to create openai exceptions with required httpx objects."""
    response = Response(
        status_code=status_code or 500, request=Request("POST", "http://test")
    )
    body = {"error": {"message": message}}
    # openai.APIError base class has a different constructor signature
    if cls is openai.APIError:
        return cls(message, request=Request("POST", "http://test"), body=body)
    return cls(message, response=response, body=body)


class TestMapError:
    """Tests for map_error function."""

    def test_authentication_error(self):
        """openai.AuthenticationError -> AuthenticationError."""
        exc = _make_openai_error(openai.AuthenticationError, status_code=401)
        result = map_error(exc)
        assert isinstance(result, AuthenticationError)
        assert result.status_code == 401

    def test_rate_limit_error(self):
        """openai.RateLimitError -> RateLimitError and triggers global block."""
        exc = _make_openai_error(openai.RateLimitError, status_code=429)
        with patch("providers.error_mapping.GlobalRateLimiter") as mock_rl:
            mock_instance = MagicMock()
            mock_rl.get_instance.return_value = mock_instance
            result = map_error(exc)
            assert isinstance(result, RateLimitError)
            assert result.status_code == 429
            mock_instance.set_blocked.assert_called_once_with(60)

    def test_bad_request_error(self):
        """openai.BadRequestError -> InvalidRequestError."""
        exc = _make_openai_error(openai.BadRequestError, status_code=400)
        result = map_error(exc)
        assert isinstance(result, InvalidRequestError)
        assert result.status_code == 400

    @pytest.mark.parametrize(
        "message",
        ["Server overloaded", "No capacity available"],
        ids=["overloaded", "capacity"],
    )
    def test_internal_server_error_overloaded(self, message):
        """InternalServerError with overloaded/capacity keywords -> OverloadedError."""
        exc = _make_openai_error(
            openai.InternalServerError, message=message, status_code=500
        )
        result = map_error(exc)
        assert isinstance(result, OverloadedError)
        assert result.status_code == 529

    def test_internal_server_error_generic(self):
        """InternalServerError without keywords maps to APIError preserving 5xx."""
        exc = _make_openai_error(
            openai.InternalServerError, message="Unknown error", status_code=500
        )
        result = map_error(exc)
        assert isinstance(result, APIError)
        assert result.status_code == 500

    @pytest.mark.parametrize(
        ("status_code", "expect_substr"),
        [
            (500, "provider api request failed"),
            (502, "temporarily unavailable"),
            (503, "temporarily unavailable"),
            (504, "temporarily unavailable"),
            (599, "provider api request failed"),
        ],
    )
    def test_internal_server_error_preserves_5xx_status_for_messaging(
        self, status_code, expect_substr
    ):
        """InternalServerError carrying HTTP 5xx retains status for stable user messaging."""
        exc = _make_openai_error(
            openai.InternalServerError,
            message=f"upstream {status_code}",
            status_code=status_code,
        )
        result = map_error(exc)
        assert isinstance(result, APIError)
        assert result.status_code == status_code
        assert expect_substr in result.message.lower()

    def test_generic_api_error(self):
        """openai.APIError -> APIError with original status_code."""
        exc = _make_openai_error(
            openai.APIError, message="Bad gateway", status_code=502
        )
        result = map_error(exc)
        assert isinstance(result, APIError)

    def test_unmapped_exception_passthrough(self):
        """Non-openai exceptions are returned as-is."""
        exc = RuntimeError("unexpected")
        result = map_error(exc)
        assert result is exc
        assert isinstance(result, RuntimeError)

    def test_value_error_passthrough(self):
        """ValueError passes through unchanged."""
        exc = ValueError("bad value")
        result = map_error(exc)
        assert result is exc


def test_user_facing_message_read_timeout_empty_string():
    """ReadTimeout wrapping TimeoutError should still produce readable text."""
    timeout_exc = ReadTimeout("")
    message = get_user_facing_error_message(timeout_exc, read_timeout_s=60)
    assert message == "Provider request timed out after 60s."


def test_append_request_id_suffix():
    """Request id suffix should be appended deterministically."""
    message = append_request_id("Provider request failed.", "req_abc123")
    assert message == "Provider request failed. (request_id=req_abc123)"


def test_user_facing_message_bad_request_prefers_mapped_text_over_sdk_string():
    """BadRequestError should map to stable wording even when str(exc) is non-empty."""
    exc = _make_openai_error(
        openai.BadRequestError, message="leaky-upstream-detail", status_code=400
    )
    assert get_user_facing_error_message(exc) == "Invalid request sent to provider."


def test_format_user_error_preview_truncates():
    exc = ValueError("x" * 500)
    preview = format_user_error_preview(exc, max_len=20)
    assert len(preview) == 20
    assert preview == "x" * 20


def test_user_visible_message_for_mapped_provider_error_405():
    mapped = APIError("ignored", status_code=405, raw_error="")
    msg = user_visible_message_for_mapped_provider_error(
        mapped, provider_name="ACME", read_timeout_s=30.0
    )
    assert "ACME" in msg and "405" in msg


def test_openai_bad_request_body_is_user_visible():
    exc = _make_openai_error(
        openai.BadRequestError,
        message="Thinking mode does not support this tool_choice",
        status_code=400,
    )
    mapped = map_error(exc)
    msg = format_provider_error_message(
        mapped,
        extract_provider_error_detail(exc),
        provider_name="NIM",
        read_timeout_s=60.0,
        request_id="req_body",
    )

    assert "Upstream provider NIM returned HTTP 400." in msg
    assert "Category: invalid_request_error" in msg
    assert "Thinking mode does not support this tool_choice" in msg
    assert (
        '{"error":{"message":"Thinking mode does not support this tool_choice"}}' in msg
    )
    assert "Request ID: req_body" in msg


def test_auth_status_with_model_error_body_is_not_only_check_api_key():
    body = {
        "type": "error",
        "error": {
            "type": "ModelError",
            "message": "Model qwen3.7-max is not supported for format oa-compat",
        },
    }
    exc = openai.AuthenticationError(
        "Unauthorized",
        response=Response(status_code=401, request=Request("POST", "http://test")),
        body=body,
    )
    mapped = map_error(exc)
    msg = format_provider_error_message(
        mapped,
        extract_provider_error_detail(exc),
        provider_name="OPENCODE_GO",
        read_timeout_s=60.0,
        request_id="req_model",
    )

    assert "Upstream provider OPENCODE_GO returned HTTP 401." in msg
    assert "Category: ModelError" in msg
    assert "Provider authentication failed. Check API key." in msg
    assert "Model qwen3.7-max is not supported for format oa-compat" in msg
    assert msg != "Provider authentication failed. Check API key."


def test_http_status_error_json_body_is_compact_and_visible():
    response = Response(
        status_code=400,
        request=Request("POST", "http://test"),
        json={"error": {"type": "BadRequest", "message": "bad field"}},
    )
    exc = HTTPStatusError("Bad Request", request=response.request, response=response)
    mapped = map_error(exc)
    msg = user_visible_message_for_mapped_provider_error(
        mapped,
        provider_name="LOCAL",
        read_timeout_s=30.0,
        detail=extract_provider_error_detail(exc),
        request_id="req_json",
    )

    assert "Upstream provider LOCAL returned HTTP 400." in msg
    assert "Category: BadRequest" in msg
    assert '{"error":{"type":"BadRequest","message":"bad field"}}' in msg
    assert "Request ID: req_json" in msg


def test_empty_http_error_body_is_explicitly_reported():
    response = Response(
        status_code=500,
        request=Request("POST", "http://test"),
        content=b"",
    )
    exc = HTTPStatusError("Server Error", request=response.request, response=response)
    mapped = map_error(exc)
    msg = format_provider_error_message(
        mapped,
        extract_provider_error_detail(exc),
        provider_name="EMPTY",
        read_timeout_s=30.0,
    )

    assert "Upstream provider EMPTY returned HTTP 500." in msg
    assert "(empty upstream error body)" in msg


def test_attached_provider_error_body_is_capped_for_display():
    response = Response(
        status_code=500,
        request=Request("POST", "http://test"),
        content=b"",
    )
    exc = HTTPStatusError("Server Error", request=response.request, response=response)
    attach_provider_error_body(exc, "x" * (PROVIDER_ERROR_BODY_DISPLAY_CAP_BYTES + 10))
    mapped = map_error(exc)
    msg = format_provider_error_message(
        mapped,
        extract_provider_error_detail(exc),
        provider_name="LONG",
        read_timeout_s=30.0,
    )

    assert f"truncated after {PROVIDER_ERROR_BODY_DISPLAY_CAP_BYTES} bytes" in msg
    assert "x" * 100 in msg


"""Diagnostic replacement for one source-spelling assertion.
Real provider streams and retry/blocking implementation remain active; only fake
HTTP/client responses and the existing limiter clock/sleep boundary are controlled.
No scope-name, mapper path, local identifier, or blocking-helper call is graded.
"""

import asyncio
import time
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import openai
import pytest

from providers.base import ProviderConfig
from providers.rate_limit import GlobalRateLimiter
from providers.transports.anthropic_messages import AnthropicMessagesTransport
from providers.transports.openai_chat import OpenAIChatTransport
from tests.stream_contract import assert_canonical_stream_error_envelope


class Scoped429Request:
    model = "scoped-control-model"
    thinking = None
    tools = []

    def model_dump(self, exclude_none=True):
        return {
            "model": self.model,
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 32,
        }


class Scoped429OpenAIProvider(OpenAIChatTransport):
    def _build_request_body(self, request, thinking_enabled=None):
        return request.model_dump()


def _sse_events(text):
    """Independent wire parsing: no production formatter/parser in expected data."""
    result = []
    for block in text.split("\n\n"):
        data = [line[5:].strip() for line in block.splitlines() if line.startswith("data:")]
        if data:
            result.append(json.loads("\n".join(data)))
    return result


@pytest.mark.parametrize("transport_family", ["openai_chat", "anthropic_messages"])
@pytest.mark.asyncio
async def test_streaming_transports_scope_reactive_429_without_blocking_other_provider(
    monkeypatch, transport_family
):
    # Keep the real retry implementation. Only its clock/sleep boundary is
    # controlled; the score never requires error mapping at a particular site.
    GlobalRateLimiter.reset_instance()
    from providers import rate_limit as limiter_module
    clock = [time.monotonic()]
    monkeypatch.setattr(limiter_module, "time", SimpleNamespace(monotonic=lambda: clock[0]))
    phase = ["construct"]
    sleep_observations = []
    request = Scoped429Request()
    actual_calls = {"a": 0, "b": 0}
    providers = []
    names = {"a": "SCOPED_CONTROL_A", "b": "SCOPED_CONTROL_B"}
    config = ProviderConfig(api_key="local-fixture", rate_limit=100, rate_window=60)

    async def success_stream():
        yield SimpleNamespace(
            choices=[SimpleNamespace(
                delta=SimpleNamespace(content="provider-b-ready", reasoning_content=None, tool_calls=None),
                finish_reason="stop",
            )],
            usage=SimpleNamespace(prompt_tokens=1, completion_tokens=1),
        )

    def make_openai_client(**kwargs):
        side = "a" if "provider-a.test" in kwargs["base_url"] else "b"

        async def create(**body):
            actual_calls[side] += 1
            if side == "a":
                response = httpx.Response(429, request=httpx.Request("POST", kwargs["base_url"]))
                raise openai.RateLimitError("fixture429", response=response, body={"error": {"message": "fixture429"}})
            return success_stream()

        return SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)), close=AsyncMock())

    real_async_client = httpx.AsyncClient

    def native_http(request):
        side = "a" if request.url.host == "provider-a.test" else "b"
        actual_calls[side] += 1
        if side == "a":
            return httpx.Response(429, json={"error": {"message": "fixture429"}})
        # A complete native response with an observable payload, no recovery.
        events = [
            {"type": "message_start", "message": {"id": "local", "type": "message", "role": "assistant", "content": [], "model": "scoped-control-model", "usage": {"input_tokens": 1, "output_tokens": 0}}},
            {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
            {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "provider-b-ready"}},
            {"type": "content_block_stop", "index": 0},
            {"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 1}},
            {"type": "message_stop"},
        ]
        wire = "".join("event: " + event["type"] + "\ndata: " + json.dumps(event) + "\n\n" for event in events)
        return httpx.Response(200, content=wire.encode(), headers={"content-type": "text/event-stream"})

    def make_native_client(**kwargs):
        return real_async_client(**kwargs, transport=httpx.MockTransport(native_http))

    try:
        if transport_family == "openai_chat":
            monkeypatch.setattr("providers.transports.openai_chat.transport.AsyncOpenAI", make_openai_client)
            for side in ("a", "b"):
                providers.append(Scoped429OpenAIProvider(
                    config, provider_name=names[side], base_url=f"https://provider-{side}.test/v1", api_key="local-fixture"
                ))
        else:
            monkeypatch.setattr("providers.transports.anthropic_messages.transport.httpx.AsyncClient", make_native_client)
            for side in ("a", "b"):
                providers.append(AnthropicMessagesTransport(
                    config, provider_name=names[side], default_base_url=f"https://provider-{side}.test/v1"
                ))

        # Do not assume a provider-name case conversion or private scope key.
        # Exercise B while A is inside a real reactive backoff, not only after A
        # has finished and a buggy shared block may have expired.
        unrelated = GlobalRateLimiter.get_instance()
        assert not unrelated.is_blocked()
        healthy_events = []
        b_started = [False]

        async def advance_sleep(delay, result=None):
            active = phase[0]
            delay = float(delay)
            sleep_observations.append((active, delay))
            if active == "a" and delay > 0 and not b_started[0]:
                b_started[0] = True
                phase[0] = "b"
                try:
                    healthy_events.extend([event async for event in providers[1].stream_response(request)])
                finally:
                    phase[0] = "a"
            clock[0] += max(0.0, delay)
            return result

        monkeypatch.setattr(asyncio, "sleep", advance_sleep)
        phase[0] = "a"
        failed_events = [event async for event in providers[0].stream_response(request)]
        assert actual_calls["a"] > 0, "429 boundary was never reached"
        assert_canonical_stream_error_envelope(failed_events, user_message_substr="429")
        assert any(who == "a" and delay > 0 for who, delay in sleep_observations), "A's real 429 retry/backoff path was not reached"
        assert b_started[0] and actual_calls["b"] > 0, "B was not exercised during A's reactive backoff"
        assert not any(who == "b" and delay > 0 for who, delay in sleep_observations), "A's 429 blocked otherwise healthy B"
        assert not unrelated.is_blocked(), "A's 429 blocked the unrelated global fallback"
        parsed = _sse_events("".join(healthy_events))
        assert any(event.get("delta", {}).get("text") == "provider-b-ready" for event in parsed)
        assert parsed[-1]["type"] == "message_stop"
        assert not any(event.get("type") == "error" for event in parsed)
    finally:
        for provider in providers:
            await provider.cleanup()
        GlobalRateLimiter.reset_instance()
