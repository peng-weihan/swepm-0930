//! Test-only module included by a single #[cfg(test)] module declaration.
//! It does not replace any production code or add a crate dependency.

use std::rc::Rc;

use crate::{
    common::options::OptionsBuilder,
    runtime::{
        ContextBuilder, Realm,
        abstract_operations::ordinary_has_instance,
        array_object::{ArrayCreateShape, array_create_in_realm},
        eval_result::EvalError,
        get,
        intrinsics::intrinsics::Intrinsic,
    },
};

#[test]
fn explicit_default_array_mode_uses_each_realms_array_prototype() {
    // The core crate can construct its own initial heap. Importing the
    // serialized-heap crate here would introduce an unnecessary dependency
    // cycle, because that crate itself depends on brimstone_core.
    let options = OptionsBuilder::new().serialized_heap(None).build().unwrap();
    let cx = ContextBuilder::new().set_options(Rc::new(options)).build().unwrap();
    cx.execute_then_drop(|mut cx| {
        // RangeError construction below consults cx.current_realm(). The raw
        // object API must therefore run with a real VM initial realm frame,
        // just like Context::run_script establishes for host script execution.
        let initial_realm = cx.initial_realm_ptr();
        cx.with_initial_realm_stack_frame(initial_realm, |cx| {
            crate::handle_scope!(cx, {
                let first_realm = cx.initial_realm();
                let second_realm = Realm::new(cx).unwrap();
                let first = array_create_in_realm(cx, first_realm, 3, ArrayCreateShape::Default)
                    .ok().expect("default array creation");
                let second = array_create_in_realm(cx, second_realm, 7, ArrayCreateShape::Default)
                    .ok().expect("array creation in a different realm");
                assert_eq!(first.as_object().array_properties_length(), 3);
                assert_eq!(second.as_object().array_properties_length(), 7);
                assert!(first.as_object().prototype().expect("first prototype").ptr_eq(&*first_realm.get_intrinsic(Intrinsic::ArrayPrototype)));
                assert!(second.as_object().prototype().expect("second prototype").ptr_eq(&*second_realm.get_intrinsic(Intrinsic::ArrayPrototype)));
                assert!(!first.as_object().prototype().unwrap().ptr_eq(&second.as_object().prototype().unwrap()));
                // The specified exact message belongs to ArrayCreate's u64
                // length guard. JS `new Array(number)` has its own, unchanged
                // numeric validation and a different existing error message.
                let length_error = match array_create_in_realm(
                    cx, first_realm, 1_u64 << 32, ArrayCreateShape::Default,
                ) {
                    Err(EvalError::Value(error)) => error,
                    #[cfg(feature = "alloc_error")]
                    Err(EvalError::Alloc(_)) => panic!("out-of-range length must be a RangeError, not an allocation error"),
                    Ok(_) => panic!("ArrayCreate must reject a length of 2^32"),
                };
                assert!(length_error.is_object(), "ArrayCreate must throw an error object");
                let error_object = length_error.as_object();
                assert!(ordinary_has_instance(
                    cx, first_realm.get_intrinsic(Intrinsic::RangeErrorConstructor).into(), length_error,
                )?, "ArrayCreate must throw the realm's RangeError");
                let message = get(cx, error_object, cx.names.message())?;
                assert!(message.is_string(), "RangeError.message must be a string");
                assert_eq!(message.as_string().format()?, "array length out of range");
                Ok(())
            })
        }).ok().expect("default array contract with an active realm");
    });
}
