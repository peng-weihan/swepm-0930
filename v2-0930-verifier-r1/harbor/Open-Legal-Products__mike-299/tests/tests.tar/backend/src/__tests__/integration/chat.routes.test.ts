import { describe, it, expect, vi, beforeEach } from "vitest";
import request from "supertest";

// Hoisted mock fn so the vi.mock factory below (which is itself hoisted above
// the imports) can reference it. Lets each test drive the stream outcome.
const { runLLMStream, dbInserts, dbUpdates, dbControl } = vi.hoisted(() => ({
    runLLMStream: vi.fn(),
    dbInserts: [] as { table: string; value: unknown }[],
    dbUpdates: [] as {
        table: string;
        value: unknown;
        filters: { column: string; value: unknown }[];
    }[],
    dbControl: {
        failAssistantReservation: false,
        terminalUpdateFailures: 0,
        terminalUpdateAttempts: 0,
        terminalUpdateGate: null as Promise<void> | null,
    },
}));

// A permissive, chainable Supabase stub. Every query-builder method returns the
// same object (so arbitrary chains work), the object is awaitable (thenable),
// and the terminal single()/maybeSingle() resolve to a chat row. The chat
// routes only read `.id`/`.title` and check `.error`, so this is enough to let
// a request flow through chat creation and message inserts without real IO.
function makeQuery(table: string) {
    let result: { data: unknown; error: { message: string } | null } = {
        data: {
            id: "chat-1",
            title: null,
            user_id: "u1",
            project_id: null,
        },
        error: null,
    };
    const q: Record<string, unknown> = {};
    let activeUpdate:
        | {
              table: string;
              value: unknown;
              filters: { column: string; value: unknown }[];
          }
        | undefined;
    const chain = [
        "select",
        "delete",
        "upsert",
        "neq",
        "in",
        "is",
        "or",
        "lt",
        "gt",
        "gte",
        "lte",
        "filter",
        "order",
        "limit",
        "range",
        "contains",
    ];
    for (const m of chain) q[m] = vi.fn(() => q);
    q.insert = vi.fn((value: unknown) => {
        dbInserts.push({ table, value });
        if (
            dbControl.failAssistantReservation &&
            table === "chat_messages" &&
            (value as { role?: unknown }).role === "assistant"
        ) {
            result = {
                data: null,
                error: { message: "assistant reservation failed" },
            };
        }
        return q;
    });
    q.update = vi.fn((value: unknown) => {
        activeUpdate = { table, value, filters: [] };
        dbUpdates.push(activeUpdate);
        return q;
    });
    q.eq = vi.fn((column: string, value: unknown) => {
        activeUpdate?.filters.push({ column, value });
        return q;
    });
    q.single = vi.fn(() => Promise.resolve(result));
    q.maybeSingle = vi.fn(() => Promise.resolve(result));
    q.then = (
        resolve: (v: unknown) => unknown,
        reject?: (e: unknown) => unknown,
    ) => {
        const resolveQuery = async () => {
            if (activeUpdate?.table === "chat_messages") {
                dbControl.terminalUpdateAttempts += 1;
                if (dbControl.terminalUpdateGate) {
                    await dbControl.terminalUpdateGate;
                }
                if (
                    dbControl.terminalUpdateAttempts <=
                    dbControl.terminalUpdateFailures
                ) {
                    return {
                        data: null,
                        error: {
                            message: `terminal update failed (attempt ${dbControl.terminalUpdateAttempts})`,
                        },
                    };
                }
            }
            return result;
        };
        return resolveQuery().then(resolve, reject);
    };
    return q;
}

function mockSupabase() {
    return {
        from: vi.fn((table: string) => makeQuery(table)),
        rpc: vi.fn(() => Promise.resolve({ data: null, error: null })),
        auth: {
            getUser: () =>
                Promise.resolve({ data: { user: { id: "u1" } }, error: null }),
        },
    };
}

vi.mock("../../lib/supabase", () => ({
    createServerSupabase: vi.fn(() => mockSupabase()),
}));

// Authenticate every request as user "u1" without exercising the real Supabase
// JWT path. requireMfaIfEnrolled must be exported too — userRouter (mounted by
// the app) imports it at module load.
vi.mock("../../middleware/auth", () => ({
    requireAuth: (
        _req: unknown,
        res: { locals: Record<string, unknown> },
        next: () => void,
    ) => {
        res.locals.userId = "u1";
        res.locals.userEmail = "u1@test.local";
        next();
    },
    requireMfaIfEnrolled: (_req: unknown, _res: unknown, next: () => void) =>
        next(),
}));

// Keep the real error helpers (the failure-path test relies on genuine
// isAbortError + AssistantStreamError behavior) but stub the functions that
// would otherwise hit the DB or the LLM.
vi.mock("../../lib/chat", async (importOriginal) => {
    const actual = await importOriginal<typeof import("../../lib/chat")>();
    return {
        ...actual,
        buildDocContext: vi.fn(async () => ({
            docIndex: {},
            docStore: new Map(),
        })),
        enrichWithPriorEvents: vi.fn(async (messages: unknown) => messages),
        buildWorkflowStore: vi.fn(async () => new Map()),
        buildMessages: vi.fn(() => []),
        runLLMStream: (...args: unknown[]) => runLLMStream(...args),
    };
});

vi.mock("../../lib/userSettings", () => ({
    getUserModelSettings: vi.fn(async () => ({
        legal_research_us: false,
        title_model: "test-model",
        tabular_model: "test-model",
        api_keys: {},
    })),
    getUserApiKeys: vi.fn(async () => ({})),
}));

import { app } from "../../app";

const VALID_BODY = { messages: [{ role: "user", content: "hello" }] };

function findAssistantReservation() {
    return dbInserts.find(
        ({ table, value }) =>
            table === "chat_messages" &&
            (value as { role?: unknown }).role === "assistant",
    );
}

function findAssistantUpdate() {
    return dbUpdates.find(({ table }) => table === "chat_messages");
}

describe("POST /chat — streaming endpoint", () => {
    beforeEach(() => {
        vi.clearAllMocks();
        dbInserts.length = 0;
        dbUpdates.length = 0;
        dbControl.failAssistantReservation = false;
        dbControl.terminalUpdateFailures = 0;
        dbControl.terminalUpdateAttempts = 0;
        dbControl.terminalUpdateGate = null;
        runLLMStream.mockResolvedValue({
            fullText: "hi there",
            events: [],
            citations: [],
        });
    });

    it("streams SSE with a chat_id event on the happy path", async () => {
        let reservationExistedBeforeStreaming = false;
        runLLMStream.mockImplementation(async () => {
            reservationExistedBeforeStreaming = !!findAssistantReservation();
            return {
                fullText: "hi there",
                events: [{ type: "content", text: "hi there" }],
                citations: [],
            };
        });

        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(VALID_BODY);

        expect(res.status).toBe(200);
        expect(res.headers["content-type"]).toContain("text/event-stream");
        expect(res.text).toContain('"type":"chat_id"');
        expect(runLLMStream).toHaveBeenCalledTimes(1);
        expect(runLLMStream).toHaveBeenCalledWith(
            expect.objectContaining({ emitDone: false }),
        );

        const metadata = JSON.parse(
            res.text
                .split("\n")
                .find((line) => line.includes('"type":"chat_id"'))!
                .replace(/^data:\s*/, ""),
        ) as { chatId: string; assistantMessageId: string };
        const assistantInsert = findAssistantReservation();
        const assistantUpdate = findAssistantUpdate();
        expect(reservationExistedBeforeStreaming).toBe(true);
        expect(metadata.assistantMessageId).toMatch(
            /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
        );
        expect(assistantInsert?.value).toMatchObject({
            id: metadata.assistantMessageId,
            chat_id: metadata.chatId,
            role: "assistant",
            content: null,
            citations: null,
        });
        expect(assistantUpdate?.value).toMatchObject({
            content: [{ type: "content", text: "hi there" }],
            citations: null,
        });
        expect(assistantUpdate?.filters).toEqual(
            expect.arrayContaining([
                { column: "id", value: metadata.assistantMessageId },
                { column: "chat_id", value: metadata.chatId },
            ]),
        );
    });

    it("stores cloud Word chats only in the document-scoped Word tables", async () => {
        const chatLib = await import("../../lib/chat");
        const res = await request(app)
            .post("/word-chat")
            .set("Authorization", "Bearer test")
            .send({
                messages: [{ role: "user", content: "Visible prompt" }],
                document_id: "6f783e59-35c4-4ddc-896a-94aa4d05a767",
                storage: "cloud",
                document_context: "GOVERNED BY DELAWARE LAW",
            });

        expect(res.status).toBe(200);
        expect(dbInserts.some(({ table }) => table === "chats")).toBe(false);
        expect(dbInserts.some(({ table }) => table === "chat_messages")).toBe(
            false,
        );
        expect(dbInserts).toEqual(
            expect.arrayContaining([
                expect.objectContaining({
                    table: "word_chats",
                    value: expect.objectContaining({
                        user_id: "u1",
                        word_document_id: "chat-1",
                    }),
                }),
                expect.objectContaining({
                    table: "word_chat_messages",
                    value: expect.objectContaining({
                        role: "user",
                        content: "Visible prompt",
                    }),
                }),
                expect.objectContaining({
                    table: "word_chat_messages",
                    value: expect.objectContaining({ role: "assistant" }),
                }),
            ]),
        );
        const call = vi.mocked(chatLib.buildMessages).mock.calls[0];
        const docAvailability = call[1] as {
            doc_id: string;
            filename: string;
        }[];
        const systemPromptExtra = call[2] as string;
        const streamArgs = runLLMStream.mock.calls[0]?.[0] as {
            docStore: Map<
                string,
                {
                    filename: string;
                    inline_text?: string;
                }
            >;
        };
        expect(systemPromptExtra).toContain("WORD ADD-IN MODE");
        expect(systemPromptExtra).toContain(
            "<original>exact text copied from the active Word document</original>",
        );
        expect(systemPromptExtra).not.toContain("GOVERNED BY DELAWARE LAW");
        expect(docAvailability).toContainEqual({
            doc_id: "active-word-document",
            filename: "Active Word document",
        });
        expect(streamArgs.docStore.get("active-word-document")).toMatchObject({
            filename: "Active Word document",
            inline_text: "GOVERNED BY DELAWARE LAW",
        });
        expect(
            dbInserts.find(
                ({ table, value }) =>
                    table === "word_chat_messages" &&
                    (value as { role?: unknown }).role === "user",
            )?.value,
        ).toMatchObject({ content: "Visible prompt" });
    });

    it("streams local Word chats without inserting any chat rows", async () => {
        const res = await request(app)
            .post("/word-chat")
            .set("Authorization", "Bearer test")
            .send({
                ...VALID_BODY,
                chat_id: "96fdeaa1-af40-475e-9834-703004783f21",
                document_id: "6f783e59-35c4-4ddc-896a-94aa4d05a767",
                storage: "local",
            });

        expect(res.status).toBe(200);
        expect(res.text).toContain('"chatId":"96fdeaa1-af40-475e-9834-703004783f21"');
        expect(dbInserts).toEqual([]);
        expect(dbUpdates).toEqual([]);
        expect(runLLMStream).toHaveBeenCalledTimes(1);
    });

    it("does not finish the SSE response until the terminal assistant update succeeds", async () => {
        let releaseTerminalUpdate!: () => void;
        dbControl.terminalUpdateGate = new Promise<void>((resolve) => {
            releaseTerminalUpdate = resolve;
        });

        let requestSettled = false;
        const responsePromise = request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(VALID_BODY)
            .then((response) => {
                requestSettled = true;
                return response;
            });

        await vi.waitFor(() => {
            expect(dbControl.terminalUpdateAttempts).toBe(1);
        });
        expect(runLLMStream).toHaveBeenCalledWith(
            expect.objectContaining({ emitDone: false }),
        );
        expect(requestSettled).toBe(false);

        releaseTerminalUpdate();
        const res = await responsePromise;

        expect(requestSettled).toBe(true);
        expect(res.text).toContain("data: [DONE]");
        expect(res.text).not.toContain(
            "The response was generated but could not be saved",
        );
    });

    it("retries a failed terminal assistant update up to success", async () => {
        dbControl.terminalUpdateFailures = 2;

        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(VALID_BODY);

        expect(res.status).toBe(200);
        expect(dbControl.terminalUpdateAttempts).toBe(3);
        expect(
            dbUpdates.filter(({ table }) => table === "chat_messages"),
        ).toHaveLength(3);
        expect(res.text).toContain("data: [DONE]");
        expect(res.text).not.toContain(
            "The response was generated but could not be saved",
        );
    });

    it("reports a terminal persistence failure before ending the SSE stream", async () => {
        dbControl.terminalUpdateFailures = 3;
        const errorSpy = vi
            .spyOn(console, "error")
            .mockImplementation(() => {});

        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(VALID_BODY);

        expect(res.status).toBe(200);
        expect(dbControl.terminalUpdateAttempts).toBe(3);
        expect(
            dbUpdates.filter(({ table }) => table === "chat_messages"),
        ).toHaveLength(3);

        const errorIndex = res.text.indexOf(
            "The response was generated but could not be saved",
        );
        const doneIndex = res.text.indexOf("data: [DONE]");
        expect(errorIndex).toBeGreaterThanOrEqual(0);
        expect(doneIndex).toBeGreaterThan(errorIndex);
        expect(errorSpy).toHaveBeenCalledWith(
            "[chat/stream] failed to save assistant response",
            expect.objectContaining({
                message: "terminal update failed (attempt 3)",
            }),
        );
        errorSpy.mockRestore();
    });

    it("fails before advertising SSE metadata when the assistant row cannot be reserved", async () => {
        dbControl.failAssistantReservation = true;
        const errorSpy = vi
            .spyOn(console, "error")
            .mockImplementation(() => {});

        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(VALID_BODY);

        expect(res.status).toBe(500);
        expect(res.headers["content-type"]).not.toContain("text/event-stream");
        expect(res.body.detail).toBe("Failed to start assistant response");
        expect(res.text).not.toContain('"type":"chat_id"');
        expect(findAssistantReservation()).toBeDefined();
        expect(runLLMStream).not.toHaveBeenCalled();
        expect(findAssistantUpdate()).toBeUndefined();
        expect(errorSpy).toHaveBeenCalledWith(
            "[chat/stream] failed to reserve assistant message",
            expect.objectContaining({
                message: "assistant reservation failed",
            }),
        );
        errorSpy.mockRestore();
    });

    it("surfaces a stream failure as an in-stream error event, not an HTTP error", async () => {
        runLLMStream.mockRejectedValue(new Error("upstream LLM failure"));

        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(VALID_BODY);

        // Headers were already flushed (200) before the stream threw, so the
        // failure surfaces as an in-stream error event + [DONE].
        expect(res.status).toBe(200);
        expect(res.text).toContain('"type":"error"');
        expect(res.text).toContain("[DONE]");

        const metadata = JSON.parse(
            res.text
                .split("\n")
                .find((line) => line.includes('"type":"chat_id"'))!
                .replace(/^data:\s*/, ""),
        ) as { assistantMessageId: string };
        const assistantInsert = findAssistantReservation();
        const assistantUpdate = findAssistantUpdate();
        expect(assistantInsert?.value).toMatchObject({
            id: metadata.assistantMessageId,
            role: "assistant",
        });
        expect(assistantUpdate?.filters).toContainEqual({
            column: "id",
            value: metadata.assistantMessageId,
        });
        expect(assistantUpdate?.value).toMatchObject({
            content: [
                expect.objectContaining({
                    type: "error",
                    message: "upstream LLM failure",
                }),
            ],
        });
    });

    it("uses the streamed assistant message id when persisting a cancelled partial response", async () => {
        const { AssistantStreamAbortError } = await import("../../lib/chat");
        runLLMStream.mockRejectedValue(
            new AssistantStreamAbortError("partial", [
                { type: "content", text: "partial" },
            ]),
        );

        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(VALID_BODY);

        expect(res.status).toBe(200);
        const metadata = JSON.parse(
            res.text
                .split("\n")
                .find((line) => line.includes('"type":"chat_id"'))!
                .replace(/^data:\s*/, ""),
        ) as { assistantMessageId: string };
        const assistantInsert = findAssistantReservation();
        const assistantUpdate = findAssistantUpdate();
        expect(assistantInsert?.value).toMatchObject({
            id: metadata.assistantMessageId,
            role: "assistant",
        });
        expect(assistantUpdate?.filters).toContainEqual({
            column: "id",
            value: metadata.assistantMessageId,
        });
        expect(assistantUpdate?.value).toMatchObject({
            content: expect.arrayContaining([
                { type: "content", text: "partial" },
                { type: "content", text: "Cancelled by user." },
            ]),
        });
    });

    it("does not allocate or insert a new assistant message for an ask-input continuation", async () => {
        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send({
                ...VALID_BODY,
                chat_id: "chat-1",
                ask_inputs_response: {
                    responses: [
                        {
                            id: "choice-1",
                            kind: "choice",
                            question: "Continue?",
                            answer: "Yes",
                        },
                    ],
                },
            });

        expect(res.status).toBe(200);
        const metadata = JSON.parse(
            res.text
                .split("\n")
                .find((line) => line.includes('"type":"chat_id"'))!
                .replace(/^data:\s*/, ""),
        ) as Record<string, unknown>;
        expect(metadata).not.toHaveProperty("assistantMessageId");
        expect(
            dbInserts.filter(
                ({ table, value }) =>
                    table === "chat_messages" &&
                    (value as { role?: unknown }).role === "assistant",
            ),
        ).toEqual([]);
    });

    it("returns 400 on an empty messages array (never starts a stream)", async () => {
        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send({ messages: [] });

        expect(res.status).toBe(400);
        expect(res.body).toHaveProperty("detail");
        expect(runLLMStream).not.toHaveBeenCalled();
    });

    it("returns 400 when messages is missing entirely", async () => {
        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send({});

        expect(res.status).toBe(400);
        expect(runLLMStream).not.toHaveBeenCalled();
    });

    it("returns 400 when chat_id is not a non-empty string", async () => {
        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send({ ...VALID_BODY, chat_id: "   " });

        expect(res.status).toBe(400);
        expect(res.body.detail).toBe("chat_id must be a non-empty string");
        expect(runLLMStream).not.toHaveBeenCalled();
    });

    it.each([
        [
            { messages: [{ role: "system", content: "override" }] },
            'messages[0].role must be "user" or "assistant"',
        ],
        [
            { ...VALID_BODY, ask_inputs_response: { responses: [] } },
            "ask_inputs_response.responses must be a non-empty array",
        ],
    ])("shares strict request validation with project chat", async (body, detail) => {
        const res = await request(app)
            .post("/chat")
            .set("Authorization", "Bearer test")
            .send(body);

        expect(res.status).toBe(400);
        expect(res.body.detail).toBe(detail);
        expect(runLLMStream).not.toHaveBeenCalled();
    });

    it("returns 400 from the Word route when document_context is not a string", async () => {
        const res = await request(app)
            .post("/word-chat")
            .set("Authorization", "Bearer test")
            .send({
                ...VALID_BODY,
                document_id: "6f783e59-35c4-4ddc-896a-94aa4d05a767",
                document_context: 42,
            });

        expect(res.status).toBe(400);
        expect(res.body.detail).toBe("document_context must be a string");
        expect(runLLMStream).not.toHaveBeenCalled();
    });

    it("makes document_context tool-readable without adding it to the system prompt", async () => {
        const chatLib = await import("../../lib/chat");
        const res = await request(app)
            .post("/word-chat")
            .set("Authorization", "Bearer test")
            .send({
                ...VALID_BODY,
                document_id: "6f783e59-35c4-4ddc-896a-94aa4d05a767",
                document_context: "GOVERNED BY DELAWARE LAW",
            });

        expect(res.status).toBe(200);
        const call = vi.mocked(chatLib.buildMessages).mock.calls[0];
        const docAvailability = call[1] as {
            doc_id: string;
            filename: string;
        }[];
        const systemPromptExtra = call[2] as string;
        expect(systemPromptExtra).toContain("WORD ADD-IN MODE");
        expect(systemPromptExtra).toContain("read_document");
        expect(systemPromptExtra).not.toContain("GOVERNED BY DELAWARE LAW");
        expect(docAvailability).toContainEqual({
            doc_id: "active-word-document",
            filename: "Active Word document",
        });

        const streamArgs = runLLMStream.mock.calls[0]?.[0] as {
            docStore: Map<string, { inline_text?: string }>;
        };
        expect(streamArgs.docStore.get("active-word-document")?.inline_text).toBe(
            "GOVERNED BY DELAWARE LAW",
        );
    });

    it("keeps CourtListener disabled for Word chats even when legal research is enabled", async () => {
        const chatLib = await import("../../lib/chat");
        const userSettings = await import("../../lib/userSettings");
        vi.mocked(userSettings.getUserModelSettings).mockResolvedValueOnce({
            title_model: "test-model",
            tabular_model: "test-model",
            legal_research_us: true,
            api_keys: { courtlistener: "configured-but-unused" },
        });

        const res = await request(app)
            .post("/word-chat")
            .set("Authorization", "Bearer test")
            .send({
                ...VALID_BODY,
                document_id: "6f783e59-35c4-4ddc-896a-94aa4d05a767",
                document_context: "Contract text",
            });

        expect(res.status).toBe(200);
        const buildMessagesCall = vi.mocked(chatLib.buildMessages).mock.calls[0];
        expect(buildMessagesCall[4]).toBe(false);
        expect(runLLMStream).toHaveBeenCalledWith(
            expect.objectContaining({ includeResearchTools: false }),
        );
        const streamArgs = runLLMStream.mock.calls[0]?.[0] as {
            apiKeys?: { courtlistener?: string };
        };
        expect(streamArgs.apiKeys?.courtlistener).toBeUndefined();
    });

});

describe("PATCH /chat/:chatId", () => {
    it("returns 400 when title is missing", async () => {
        const res = await request(app)
            .patch("/chat/chat-1")
            .set("Authorization", "Bearer test")
            .send({});

        expect(res.status).toBe(400);
        expect(res.body.detail).toBe("title is required");
    });
});
