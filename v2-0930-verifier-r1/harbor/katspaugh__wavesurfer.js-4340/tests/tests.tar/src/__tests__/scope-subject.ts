/** Resolve the candidate's real Scope, without prescribing its source filename. */
import * as fs from 'node:fs'
import * as path from 'node:path'
import * as ts from 'typescript'

const root = path.resolve(__dirname, '..')
const sources = new Map<string, ts.SourceFile>()
const scan = (directory: string) => {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === '__tests__' || entry.name === 'node_modules') continue
    const file = path.join(directory, entry.name)
    if (entry.isDirectory()) scan(file)
    else if (entry.isFile() && /\.tsx?$/.test(file) && !/\.(?:test|spec)\.tsx?$/.test(file)) {
      sources.set(file, ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true))
    }
  }
}
scan(root)

const resolveImport = (file: string, specifier: string) => {
  if (!specifier.startsWith('.')) return undefined
  const base = path.resolve(path.dirname(file), specifier.replace(/\.js$/, ''))
  return [base + '.ts', base + '.tsx', path.join(base, 'index.ts')].find((candidate) => sources.has(candidate))
}

// Existing production entry points, not permitted Scope implementation paths.
const pending = ['wavesurfer.ts', 'player.ts', 'renderer.ts', 'base-plugin.ts']
  .map((name) => path.join(root, name)).filter((file) => sources.has(file))
const visited = new Set<string>()
while (pending.length) {
  const file = pending.pop()!
  if (visited.has(file)) continue
  visited.add(file)
  const source = sources.get(file)!
  for (const statement of source.statements) {
    if ((ts.isImportDeclaration(statement) || ts.isExportDeclaration(statement)) &&
        statement.moduleSpecifier && ts.isStringLiteral(statement.moduleSpecifier)) {
      const target = resolveImport(file, statement.moduleSpecifier.text)
      if (target) pending.push(target)
    }
  }
}
const candidates = [...visited].filter((file) => sources.get(file)!.statements.some(
  (node) => ts.isClassDeclaration(node) && node.name?.text === 'Scope',
))
if (candidates.length !== 1) {
  throw new Error(`Cannot resolve one production-owned Scope without guessing: ${candidates.join(', ')}`)
}
// Jest transforms this actual candidate source. No class/method fallback exists.
const subjectExports = require(candidates[0])
const actual = subjectExports.Scope ?? (subjectExports.default?.name === 'Scope' ? subjectExports.default : undefined)
if (typeof actual !== 'function') throw new Error(`Candidate module does not export Scope: ${candidates[0]}`)
export const Scope = actual
