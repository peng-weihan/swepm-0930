/*
 * Integration tests for the full denoising pipeline
 */

#include "../src/shared/configurations.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Include internal headers for testing

// Include the public API
#include "specbleach_2d_denoiser.h"

#define ROLLING_MEAN 1

#include "specbleach_denoiser.h"

// Function prototypes
void test_spectral_denoiser(void);
void test_adaptive_denoiser(void);
void test_2d_denoiser(void);
void test_different_noise_levels(void);
void test_library_info(void);
float calculate_rms(const float* buffer, int length);

#define TEST_ASSERT(condition, message)                                        \
  do {                                                                         \
    if (!(condition)) {                                                        \
      fprintf(stderr, "TEST FAILED: %s\n", message);                           \
      exit(1);                                                                 \
    }                                                                          \
  } while (0)

#define TEST_FLOAT_CLOSE(a, b, tolerance)                                      \
  TEST_ASSERT(fabsf((a) - (b)) < (tolerance), "Float values not close enough")

#define SAMPLE_RATE 44100
#define FRAME_SIZE 512
#define NUM_FRAMES 100
#define BLOCK_SIZE (FRAME_SIZE * NUM_FRAMES)

// Generate synthetic audio with noise
void generate_test_audio(float* buffer, int length, float signal_freq,
                         float noise_level) {
  for (int i = 0; i < length; i++) {
    // Generate a sine wave signal
    float signal = 0.5f * sinf(2.0f * (float)M_PI * (float)signal_freq *
                               (float)i / (float)SAMPLE_RATE);

    // Add white noise
    float noise = noise_level * ((float)rand() / RAND_MAX - 0.5f) * 2.0f;

    buffer[i] = signal + noise;
  }
}

// Calculate RMS of audio buffer
float calculate_rms(const float* buffer, int length) {
  double sum = 0.0;
  for (int i = 0; i < length; i++) {
    sum += buffer[i] * buffer[i];
  }
  return (float)sqrt((double)sum / (double)length);
}

// Test spectral denoiser with synthetic audio
void test_spectral_denoiser(void) {
  printf("Testing spectral denoiser integration...\n");

  // Create test audio with signal + noise
  float* input_buffer = calloc((size_t)BLOCK_SIZE, sizeof(float));
  float* output_buffer = calloc((size_t)BLOCK_SIZE, sizeof(float));
  TEST_ASSERT(input_buffer && output_buffer, "Failed to allocate test buffers");

  generate_test_audio(input_buffer, BLOCK_SIZE, 1000.0f,
                      0.5f); // 1kHz signal + noise (higher noise for RMS check)

  // Calculate input RMS
  float input_rms = calculate_rms(input_buffer, BLOCK_SIZE);
  printf("  Input RMS: %.4f\n", input_rms);

  // Initialize denoiser
  float frame_size_ms = 20.0f;
  SpectralBleachHandle handle =
      specbleach_initialize(SAMPLE_RATE, frame_size_ms);
  TEST_ASSERT(handle != NULL, "Failed to initialize spectral denoiser");

  SpectralBleachDenoiserParameters parameters =
      (SpectralBleachDenoiserParameters){.learn_noise = 1, // Learn all modes
                                         .reduction_amount = 20.0f,
                                         .smoothing_factor = 0.0f,
                                         .masking_depth = 0.5f,
                                         .masking_elasticity = 0.1f,

                                         .residual_listen = false,
                                         .whitening_factor = 0.0f};

  specbleach_load_parameters(handle, parameters);

  // Process first blocks in learn mode (at least 10 frames)
  specbleach_process(handle, FRAME_SIZE * 10, input_buffer, output_buffer);

  // Switch to reduction mode
  parameters.learn_noise = 0;
  specbleach_load_parameters(handle, parameters);

  // Process remaining blocks
  int processed_samples = FRAME_SIZE * 10;
  while (processed_samples < BLOCK_SIZE) {
    int block_size = FRAME_SIZE;
    if (processed_samples + block_size > BLOCK_SIZE) {
      block_size = BLOCK_SIZE - processed_samples;
    }

    bool result =
        specbleach_process(handle, block_size, input_buffer + processed_samples,
                           output_buffer + processed_samples);
    TEST_ASSERT(result == true, "Processing failed");

    processed_samples += block_size;
  }

  // Calculate output RMS
  float output_rms = calculate_rms(output_buffer, BLOCK_SIZE);
  printf("  Output RMS: %.4f\n", output_rms);

  // Verify noise reduction (output should be quieter than input)
  TEST_ASSERT(output_rms < input_rms * 0.8f,
              "Noise reduction should reduce RMS significantly");

  // Verify signal preservation (output shouldn't be too quiet)
  TEST_ASSERT(output_rms > input_rms * 0.1f,
              "Signal should be reasonably preserved");

  // Cleanup
  specbleach_free(handle);
  free(input_buffer);
  free(output_buffer);

  printf("✓ Spectral denoiser integration test passed\n");
}

// Test denoiser with different noise levels
void test_different_noise_levels(void) {
  printf("Testing denoiser with different noise levels...\n");

  // Test with low noise
  float* input_buffer = calloc(BLOCK_SIZE, sizeof(float));
  float* output_buffer = calloc(BLOCK_SIZE, sizeof(float));
  TEST_ASSERT(input_buffer && output_buffer, "Failed to allocate test buffers");

  generate_test_audio(input_buffer, BLOCK_SIZE, 1000.0f, 0.05f); // Low noise

  float frame_size_ms = 20.0f;
  SpectralBleachHandle handle =
      specbleach_initialize(SAMPLE_RATE, frame_size_ms);
  TEST_ASSERT(handle != NULL, "Failed to initialize denoiser");

  SpectralBleachDenoiserParameters parameters =
      (SpectralBleachDenoiserParameters){.learn_noise = 1, // Average
                                         .reduction_amount = 20.0f,
                                         .smoothing_factor = 0.0f,
                                         .masking_depth = 0.5f,
                                         .masking_elasticity = 0.1f,

                                         .residual_listen = false,
                                         .whitening_factor = 0.0f};

  specbleach_load_parameters(handle, parameters);

  // Learn a bit (at least 10 frames)
  specbleach_process(handle, 5000, input_buffer, output_buffer);

  // Process remaining with reduction
  parameters.learn_noise = 0;
  specbleach_load_parameters(handle, parameters);

  // Process all at once for simplicity
  bool result = specbleach_process(handle, BLOCK_SIZE - 5000,
                                   input_buffer + 5000, output_buffer + 5000);
  TEST_ASSERT(result == true, "Processing failed");

  float input_rms = calculate_rms(input_buffer, BLOCK_SIZE);
  float output_rms = calculate_rms(output_buffer, BLOCK_SIZE);

  printf("  Low noise - Input RMS: %.4f, Output RMS: %.4f\n", input_rms,
         output_rms);

  specbleach_free(handle);
  free(input_buffer);
  free(output_buffer);

  printf("✓ Different noise levels test passed\n");
}

// Test library information functions
void test_library_info(void) {
  printf("Testing library information functions...\n");

  // Test spectral denoiser info
  int latency = specbleach_get_latency(NULL); // Should return 0 for NULL handle
  TEST_ASSERT(latency == 0, "NULL handle should return 0 latency");

  int profile_size = specbleach_get_noise_profile_size(NULL);
  TEST_ASSERT(profile_size == 0, "NULL handle should return 0 profile size");

  // Test that we can get valid information after initialization
  float frame_size_ms = 20.0f;
  SpectralBleachHandle handle =
      specbleach_initialize(SAMPLE_RATE, frame_size_ms);
  TEST_ASSERT(handle != NULL, "Failed to initialize for info test");

  latency = specbleach_get_latency(handle);
  TEST_ASSERT(latency >= 0, "Latency should be non-negative");

  profile_size = specbleach_get_noise_profile_size(handle);
  TEST_ASSERT(profile_size > 0, "Profile size should be positive");

  specbleach_free(handle);

  printf("✓ Library information tests passed\n");
}

int main(void) {
  printf("Running integration tests...\n\n");

  // Seed random number generator for reproducible tests
  srand(42);

  test_spectral_denoiser();
  test_different_noise_levels();
  test_adaptive_denoiser();

  test_2d_denoiser();
  test_library_info();

  printf("\n✅ All integration tests passed!\n");
  return 0;
}

// Test adaptive functionality enabled in standard denoiser
void test_adaptive_denoiser(void) {
  printf("Testing adaptive denoiser integration...\n");

  float* input_buffer = calloc(BLOCK_SIZE, sizeof(float));
  float* output_buffer = calloc(BLOCK_SIZE, sizeof(float));
  TEST_ASSERT(input_buffer && output_buffer, "Failed to allocate test buffers");

  generate_test_audio(input_buffer, BLOCK_SIZE, 1000.0f, 0.1f);

  float frame_size_ms = 40.0f;
  SpectralBleachHandle handle =
      specbleach_initialize(SAMPLE_RATE, frame_size_ms);
  TEST_ASSERT(handle != NULL, "Failed to initialize denoiser");

  SpectralBleachDenoiserParameters parameters =
      (SpectralBleachDenoiserParameters){
          .learn_noise = 0,
          .reduction_amount = 20.0f,
          .smoothing_factor = 50.0f,
          .masking_depth = 0.5f,
          .masking_elasticity = 0.1f,

          .residual_listen = false,
          .whitening_factor = 50.0f,
          .adaptive_noise = 1,         // Enable adaptive mode
          .noise_estimation_method = 0 // Default method
      };

  specbleach_load_parameters(handle, parameters);

  // Process all samples
  bool result =
      specbleach_process(handle, BLOCK_SIZE, input_buffer, output_buffer);
  TEST_ASSERT(result == true, "Processing failed");

  float input_rms = calculate_rms(input_buffer, BLOCK_SIZE);
  float output_rms = calculate_rms(output_buffer, BLOCK_SIZE);
  printf("  Adaptive - Input RMS: %.4f, Output RMS: %.4f\n", input_rms,
         output_rms);

  specbleach_free(handle);
  free(input_buffer);
  free(output_buffer);

  printf("✓ Adaptive denoiser integration test passed\n");
}

void test_2d_denoiser(void) {
  printf("Testing 2D NLM denoiser integration...\n");

  float* input_buffer = calloc(BLOCK_SIZE, sizeof(float));
  float* output_buffer = calloc(BLOCK_SIZE, sizeof(float));
  TEST_ASSERT(input_buffer && output_buffer, "Failed to allocate test buffers");

  generate_test_audio(input_buffer, BLOCK_SIZE, 1000.0f, 0.1f);

  float frame_size_ms = 20.0f;
  SpectralBleachHandle handle =
      specbleach_2d_initialize(SAMPLE_RATE, frame_size_ms);
  TEST_ASSERT(handle != NULL, "Failed to initialize 2D denoiser");

  // Test latency reporting (should include NLM look-ahead)
  uint32_t latency = specbleach_2d_get_latency(handle);
  printf("  2D Denoiser latency: %u samples\n", latency);
  TEST_ASSERT(latency > 0, "2D denoiser should report latency");

  // Configure for noise learning
  SpectralBleach2DDenoiserParameters parameters = {
      .learn_noise = 1, // Learn mode
      .reduction_amount = 20.0f,
      .smoothing_factor = 1.5f, // NLM h parameter
      .whitening_factor = 0.0f,
      .residual_listen = false,
  };

  specbleach_2d_load_parameters(handle, parameters);

  // Process first blocks in learn mode
  specbleach_2d_process(handle, FRAME_SIZE * 10, input_buffer, output_buffer);

  // Check that noise profile is available
  TEST_ASSERT(
      specbleach_2d_noise_profile_available_for_mode(handle, ROLLING_MEAN),
      "Noise profile should be available after learning");

  // Switch to reduction mode
  parameters.learn_noise = 0;
  specbleach_2d_load_parameters(handle, parameters);

  // Process remaining blocks
  int processed_samples = FRAME_SIZE * 10;
  while (processed_samples < BLOCK_SIZE) {
    int block_size = FRAME_SIZE;
    if (processed_samples + block_size > BLOCK_SIZE) {
      block_size = BLOCK_SIZE - processed_samples;
    }

    bool result = specbleach_2d_process(handle, block_size,
                                        input_buffer + processed_samples,
                                        output_buffer + processed_samples);
    TEST_ASSERT(result == true, "Processing failed");

    processed_samples += block_size;
  }

  // Calculate RMS values
  float input_rms = calculate_rms(input_buffer, BLOCK_SIZE);
  float output_rms = calculate_rms(output_buffer, BLOCK_SIZE);
  printf("  2D Denoiser - Input RMS: %.4f, Output RMS: %.4f\n", input_rms,
         output_rms);

  // Test noise profile API
  uint32_t profile_size = specbleach_2d_get_noise_profile_size(handle);
  TEST_ASSERT(profile_size > 0, "Profile size should be positive");

  float* profile =
      specbleach_2d_get_noise_profile_for_mode(handle, ROLLING_MEAN);
  TEST_ASSERT(profile != NULL, "Should be able to get noise profile");

  // Test reset
  TEST_ASSERT(specbleach_2d_reset_noise_profile(handle),
              "Reset should succeed");
  TEST_ASSERT(
      !specbleach_2d_noise_profile_available_for_mode(handle, ROLLING_MEAN),
      "Profile should not be available after reset");

  specbleach_2d_free(handle);
  free(input_buffer);
  free(output_buffer);

  printf("✓ 2D NLM denoiser integration test passed\n");
}
