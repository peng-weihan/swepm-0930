import { describe, expect, it } from 'vitest'

import { CreatePromptSchema, UpdatePromptSchema } from '../prompts'

describe('prompt DTO schemas', () => {
  it('accepts create with title and content', () => {
    const result = CreatePromptSchema.parse({
      title: 'Test',
      content: 'Hello'
    })

    expect(result).toEqual({ title: 'Test', content: 'Hello' })
  })

  it('rejects create with empty title or content', () => {
    expect(() => CreatePromptSchema.parse({ title: '', content: 'Hello' })).toThrow()
    expect(() => CreatePromptSchema.parse({ title: 'Test', content: '' })).toThrow()
  })

  it('rejects create values over schema limits', () => {
    expect(() => CreatePromptSchema.parse({ title: 'x'.repeat(257), content: 'Hello' })).toThrow()
    expect(() => CreatePromptSchema.parse({ title: 'Test', content: 'x'.repeat(100_001) })).toThrow()
  })

  it('rejects create with unknown prompt fields', () => {
    expect(() =>
      CreatePromptSchema.parse({
        title: 'Test',
        content: 'Hello',
        scope: 'global'
      })
    ).toThrow()

    expect(() =>
      CreatePromptSchema.parse({
        title: 'Test',
        content: 'Hello',
        variables: []
      })
    ).toThrow()
  })

  it('rejects empty update payloads', () => {
    expect(() => UpdatePromptSchema.parse({})).toThrow('At least one field is required')
  })

  it('accepts partial title/content updates', () => {
    expect(UpdatePromptSchema.parse({ title: 'renamed' })).toEqual({ title: 'renamed' })
    expect(UpdatePromptSchema.parse({ content: 'updated' })).toEqual({ content: 'updated' })
  })

  it('rejects update with empty title or content', () => {
    expect(() => UpdatePromptSchema.parse({ title: '' })).toThrow()
    expect(() => UpdatePromptSchema.parse({ content: '' })).toThrow()
  })

  it('rejects removed version, scope, and variable fields', () => {
    expect(() => UpdatePromptSchema.parse({ currentVersion: 2 })).toThrow()
    expect(() => UpdatePromptSchema.parse({ assistantId: 'assistant-1' })).toThrow()
    expect(() => UpdatePromptSchema.parse({ variables: [] })).toThrow()
  })
})

// Bounds come from instruction.md, independently of the candidate constants.
describe('prompt public size boundaries', () => {
  it('accepts create at the stated title and content maximums', () => {
    const body = { title: 't'.repeat(256), content: 'c'.repeat(100_000) }
    expect(CreatePromptSchema.parse(body)).toEqual(body)
  })
  it('enforces the same stated bounds on partial updates', () => {
    for (const body of [{ title: 't'.repeat(256) }, { content: 'c'.repeat(100_000) }]) {
      expect(UpdatePromptSchema.parse(body)).toEqual(body)
    }
    expect(() => UpdatePromptSchema.parse({ title: 't'.repeat(257) })).toThrow()
    expect(() => UpdatePromptSchema.parse({ content: 'c'.repeat(100_001) })).toThrow()
  })
})
