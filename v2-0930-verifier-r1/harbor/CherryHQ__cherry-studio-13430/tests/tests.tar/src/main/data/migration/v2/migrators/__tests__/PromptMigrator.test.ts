import { promptTable } from '@data/db/schemas/prompt'
import { setupTestDatabase } from '@test-helpers/db'
import { asc } from 'drizzle-orm'
import { describe, expect, it, vi } from 'vitest'

import type { MigrationContext } from '../../core/MigrationContext'
import { getAllMigrators } from '../index'
import { PromptMigrator } from '../PromptMigrator'

/** Helper: build a minimal MigrationContext mock */
function createMockContext(
  overrides: { tableExists?: boolean; tableData?: unknown[]; promptCount?: number } = {}
): MigrationContext {
  const { tableExists = true, tableData = [], promptCount = 0 } = overrides

  const insertFn = vi.fn().mockImplementation(() => ({
    values: vi.fn().mockResolvedValue(undefined)
  }))

  const selectFn = vi.fn().mockImplementation(() => ({
    from: vi.fn().mockImplementation(() => ({
      get: vi.fn().mockResolvedValue({ count: promptCount })
    }))
  }))

  const txProxy = new Proxy(
    { insert: insertFn },
    {
      get(_target, prop) {
        if (prop === 'insert') return insertFn
        return undefined
      }
    }
  )

  const db = {
    transaction: vi.fn().mockImplementation(async (fn: (tx: unknown) => Promise<void>) => {
      await fn(txProxy)
    }),
    select: selectFn
  }

  return {
    sources: {
      electronStore: { get: vi.fn() },
      reduxState: {
        getCategory: vi.fn(),
        getAllCategories: vi.fn()
      } as unknown as MigrationContext['sources']['reduxState'],
      dexieExport: {
        tableExists: vi.fn().mockResolvedValue(tableExists),
        readTable: vi.fn().mockResolvedValue(tableData),
        getExportPath: vi.fn().mockReturnValue('/tmp/export'),
        createStreamReader: vi.fn(),
        getTableFileSize: vi.fn()
      } as unknown as MigrationContext['sources']['dexieExport'],
      dexieSettings: {
        get: vi.fn(),
        getAll: vi.fn()
      } as unknown as MigrationContext['sources']['dexieSettings'],
      localStorage: {
        get: vi.fn(),
        getAll: vi.fn()
      } as unknown as MigrationContext['sources']['localStorage'],
      knowledgeVectorSource: {} as unknown as MigrationContext['sources']['knowledgeVectorSource'],
      legacyHomeConfig: {} as unknown as MigrationContext['sources']['legacyHomeConfig']
    },
    db: db as unknown as MigrationContext['db'],
    sharedData: new Map(),
    logger: {
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
      debug: vi.fn()
    } as unknown as MigrationContext['logger'],
    paths: {} as unknown as MigrationContext['paths']
  }
}

/** Helper: build a legacy QuickPhrase record */
function makePhrase(overrides: Record<string, unknown> = {}) {
  return {
    id: '550e8400-e29b-41d4-a716-446655440100',
    title: 'Hello',
    content: 'Hello ${name}!',
    createdAt: 1700000000000,
    updatedAt: 1700000000000,
    order: 0,
    ...overrides
  }
}

// ─── Tests ───────────────────────────────────────────────────────────

describe('PromptMigrator', () => {
  describe('metadata', () => {
    it('should have correct metadata', () => {
      const registered = getAllMigrators()
      const prompts = registered.filter((migrator) => migrator instanceof PromptMigrator)
      expect(prompts).toHaveLength(1)
      const migrator = prompts[0]
      for (const value of [migrator.id, migrator.name, migrator.description]) {
        expect(typeof value).toBe('string')
        expect(value.trim().length).toBeGreaterThan(0)
      }
      expect(Number.isFinite(migrator.order)).toBe(true)
      expect(new Set(registered.map((entry) => entry.id)).size).toBe(registered.length)
    })
  })

  // ── prepare ──────────────────────────────────────────────────────

  describe('prepare', () => {
    it('should return success with 0 items when table does not exist', async () => {
      const ctx = createMockContext({ tableExists: false })
      const migrator = new PromptMigrator()

      const result = await migrator.prepare(ctx)

      expect(result.success).toBe(true)
      expect(result.itemCount).toBe(0)
      expect((result.warnings ?? []).every((warning) => typeof warning === 'string' && warning.trim().length > 0)).toBe(true)
    })

    it('should count phrases with content and finite timestamps', async () => {
      const ctx = createMockContext({
        tableData: [
          makePhrase({ id: '550e8400-e29b-41d4-a716-446655440101', content: 'valid' }),
          makePhrase({ id: '550e8400-e29b-41d4-a716-446655440110', content: 'another valid phrase' }),
          makePhrase({ id: '550e8400-e29b-41d4-a716-446655440102', content: '' }), // invalid: empty content
          makePhrase({ id: '550e8400-e29b-41d4-a716-446655440103', content: 'bad timestamp', createdAt: Number.NaN }),
          makePhrase({ id: '550e8400-e29b-41d4-a716-446655440104', content: 'bad timestamp', updatedAt: Number.POSITIVE_INFINITY }),
          makePhrase({ id: '550e8400-e29b-41d4-a716-446655440105', content: 'also valid' })
        ]
      })
      const migrator = new PromptMigrator()

      const result = await migrator.prepare(ctx)

      expect(result.success).toBe(true)
      expect(result.itemCount).toBe(3)
      expect(result.warnings?.some((warning) => typeof warning === 'string' && warning.trim().length > 0)).toBe(true)
    })

    it('should handle empty table', async () => {
      const ctx = createMockContext({ tableData: [] })
      const migrator = new PromptMigrator()

      const result = await migrator.prepare(ctx)

      expect(result.success).toBe(true)
      expect(result.itemCount).toBe(0)
    })

    it('should surface prepare failures via the error field (not warnings)', async () => {
      const ctx = createMockContext()
      ;(ctx.sources.dexieExport.tableExists as ReturnType<typeof vi.fn>).mockRejectedValue(new Error('read error'))
      const migrator = new PromptMigrator()

      const result = await migrator.prepare(ctx)

      expect(result.success).toBe(false)
      expect(result.error).toContain('read error')
      expect(result.warnings ?? []).toEqual([])
    })
  })

  // ── execute ──────────────────────────────────────────────────────

  describe('execute', () => {

    it('should surface a constraint violation mid-batch and reset processedCount', async () => {
      const phrases = [
        makePhrase({ id: '550e8400-e29b-41d4-a716-446655440106', content: 'first' }),
        makePhrase({ id: '550e8400-e29b-41d4-a716-446655440107', content: 'second' })
      ]
      const ctx = createMockContext({ tableData: phrases })
      const migrator = new PromptMigrator()
      await migrator.prepare(ctx)

      // Simulate a DB-level failure from the bulk insert path (any
      // SQLITE_CONSTRAINT, FK mismatch, etc.).
      const insertFn = vi.fn().mockImplementation(() => ({
        values: vi.fn().mockRejectedValue(new Error('UNIQUE constraint failed: prompt.id'))
      }))

      ;(ctx.db.transaction as ReturnType<typeof vi.fn>).mockImplementation(
        async (fn: (tx: unknown) => Promise<void>) => {
          await fn({ insert: insertFn })
        }
      )

      const result = await migrator.execute(ctx)

      expect(result.success).toBe(false)
      expect(result.error).toContain('UNIQUE')
      expect(result.processedCount).toBe(0)
    })

    it('should return failure and reset processedCount to 0 when transaction throws', async () => {
      const phrases = [makePhrase({ id: '550e8400-e29b-41d4-a716-446655440108', content: 'c1' })]
      const ctx = createMockContext({ tableData: phrases })
      const migrator = new PromptMigrator()
      await migrator.prepare(ctx)

      ;(ctx.db.transaction as ReturnType<typeof vi.fn>).mockRejectedValue(new Error('db error'))

      const result = await migrator.execute(ctx)

      expect(result.success).toBe(false)
      expect(result.error).toContain('db error')
      // Rolled-back transaction means zero rows committed — processedCount reflects persisted state.
      expect(result.processedCount).toBe(0)
    })

  })

  // ── end-to-end: execute failure then validate ───────────────────
  describe('execute failure → validate', () => {
    it('should report count mismatch in validate() when execute rolled back', async () => {
      const phrases = [makePhrase({ id: '550e8400-e29b-41d4-a716-446655440108', content: 'c1' })]
      const ctx = createMockContext({
        tableData: phrases,
        // DB reports zero rows because the execute transaction rolled back.
        promptCount: 0
      })
      const migrator = new PromptMigrator()
      await migrator.prepare(ctx)

      ;(ctx.db.transaction as ReturnType<typeof vi.fn>).mockRejectedValue(new Error('forced rollback'))
      const executeResult = await migrator.execute(ctx)
      expect(executeResult.success).toBe(false)
      expect(executeResult.processedCount).toBe(0)

      const validateResult = await migrator.validate(ctx)
      expect(validateResult.success).toBe(false)
      expect(validateResult.errors.some((error) => typeof error.message === 'string' && error.message.trim().length > 0)).toBe(true)
      expect(validateResult.stats.targetCount).toBe(0)
    })
  })

  // ── validate ─────────────────────────────────────────────────────

  describe('validate', () => {
    it('should succeed when counts match', async () => {
      const phrases = [makePhrase({ id: '550e8400-e29b-41d4-a716-446655440108', content: 'c1' })]
      const ctx = createMockContext({
        tableData: phrases,
        promptCount: 1
      })
      const migrator = new PromptMigrator()
      await migrator.prepare(ctx)

      const result = await migrator.validate(ctx)

      expect(result.success).toBe(true)
      expect(result.errors).toHaveLength(0)
      expect(result.stats.sourceCount).toBe(1)
      expect(result.stats.targetCount).toBe(1)
    })

    it('should report error when prompt count is less than expected', async () => {
      const phrases = [makePhrase({ id: '550e8400-e29b-41d4-a716-446655440108', content: 'c1' }), makePhrase({ id: '550e8400-e29b-41d4-a716-446655440109', content: 'c2' })]
      const ctx = createMockContext({
        tableData: phrases,
        promptCount: 1 // less than source
      })
      const migrator = new PromptMigrator()
      await migrator.prepare(ctx)

      const result = await migrator.validate(ctx)

      expect(result.success).toBe(false)
      expect(result.errors.some((error) => typeof error.message === 'string' && error.message.trim().length > 0)).toBe(true)
      expect(result.stats.targetCount).toBe(1)
    })

    it('should handle db query failure gracefully', async () => {
      const phrases = [makePhrase({ id: '550e8400-e29b-41d4-a716-446655440108', content: 'c1' })]
      const ctx = createMockContext({ tableData: phrases })
      const migrator = new PromptMigrator()
      await migrator.prepare(ctx)

      ;(ctx.db as unknown as { select: ReturnType<typeof vi.fn> }).select.mockImplementation(() => {
        throw new Error('query failed')
      })

      const result = await migrator.validate(ctx)

      expect(result.success).toBe(false)
      expect(result.errors.some((error) => error.message.includes('query failed'))).toBe(true)
    })

    it('should track skipped count in stats', async () => {
      const phrases = [
        makePhrase({ id: '550e8400-e29b-41d4-a716-446655440108', content: 'valid' }),
        makePhrase({ id: '550e8400-e29b-41d4-a716-446655440109', content: '' }) // skipped
      ]
      const ctx = createMockContext({
        tableData: phrases,
        promptCount: 1
      })
      const migrator = new PromptMigrator()
      await migrator.prepare(ctx)

      const result = await migrator.validate(ctx)

      expect(result.stats.skippedCount).toBe(1)
    })
  })
})

describe('PromptMigrator SQLite integration', () => {
  const dbh = setupTestDatabase()

  it('preserves valid legacy UUIDs without prescribing invalid ID repair strategy', async () => {
    const validA = makePhrase({
      id: '550e8400-e29b-41d4-a716-446655440120', title: 'Valid A', content: 'valid UUID A'
    })
    const validB = makePhrase({
      id: '550e8400-e29b-41d4-a716-446655440121', title: 'Valid B', content: 'valid UUID B'
    })
    const uncertain = [
      makePhrase({ id: undefined, title: 'Missing ID', content: 'missing UUID input' }),
      makePhrase({ id: 'not-a-uuid', title: 'Malformed ID', content: 'malformed UUID input' }),
      makePhrase({ id: '', title: 'Empty ID', content: 'empty UUID input' })
    ]
    const ctx = createMockContext({ tableData: [validA, ...uncertain, validB] })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()
    const prepared = await migrator.prepare(ctx)
    expect(prepared.success).toBe(true)
    const executed = await migrator.execute(ctx)
    expect(executed.success).toBe(true)
    const rows = await dbh.db.select().from(promptTable)
    const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
    for (const row of rows) expect(row.id).toMatch(uuid)
    expect(executed.processedCount).toBe(rows.length)
    for (const original of [validA, validB]) {
      const matches = rows.filter((row) => row.content === original.content)
      expect(matches).toHaveLength(1)
      expect(matches[0]).toMatchObject({ id: original.id, title: original.title, content: original.content })
    }
    const legalContents = new Set([validA, validB, ...uncertain].map((row) => row.content))
    for (const row of rows) expect(legalContents.has(row.content)).toBe(true)
    for (const original of uncertain) {
      const matches = rows.filter((row) => row.content === original.content)
      expect(matches.length).toBeLessThanOrEqual(1)
      if (matches.length) expect(matches[0]).toMatchObject({ title: original.title, content: original.content })
    }
    // Skipping invalid records requires diagnostics; assigning a new UUID instead
    // is allowed, but it must preserve the valid records and final UUID contract.
    if (rows.length < 2 + uncertain.length) {
      expect(prepared.warnings?.some((warning) => typeof warning === 'string' && warning.trim().length > 0)).toBe(true)
    }
    expect((await migrator.validate(ctx)).success).toBe(true)
  })

  it('should return immediately when no phrases prepared', async () => {
    const ctx = createMockContext({ tableExists: false })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()
    expect((await migrator.prepare(ctx)).success).toBe(true)
    expect(await migrator.execute(ctx)).toMatchObject({ success: true, processedCount: 0 })
    expect(await dbh.db.select().from(promptTable)).toEqual([])
  })

  it('should insert one prompt for each valid phrase', async () => {
    const phrases = [
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440030', title: 'First', content: 'c1', order: 0 }),
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440031', title: 'Second', content: 'c2', order: 1 })
    ]
    const ctx = createMockContext({ tableData: phrases })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()
    expect((await migrator.prepare(ctx)).success).toBe(true)
    expect(await migrator.execute(ctx)).toMatchObject({ success: true, processedCount: 2 })
    const rows = await dbh.db.select().from(promptTable).orderBy(asc(promptTable.id))
    expect(rows.map(({ id, title, content }) => ({ id, title, content }))).toEqual(
      phrases.map(({ id, title, content }) => ({ id, title, content }))
    )
  })

  it('should preserve legacy quick phrase order', async () => {
    const ctx = createMockContext({ tableData: [
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440040', title: 'Older', content: 'old', order: 20 }),
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440041', title: 'Newer', content: 'new', order: 10 })
    ] })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()
    expect((await migrator.prepare(ctx)).success).toBe(true)
    expect((await migrator.execute(ctx)).success).toBe(true)
    const rows = await dbh.db.select().from(promptTable).orderBy(asc(promptTable.orderKey))
    expect(rows.map((row) => row.title)).toEqual(['Older', 'Newer'])
    expect(rows[0].orderKey < rows[1].orderKey).toBe(true)
  })

  it('should report progress', async () => {
    const phrases = Array.from({ length: 15 }, (_, i) => makePhrase({
      id: `550e8400-e29b-41d4-a716-${String(i).padStart(12, '0')}`, content: `c${i}`
    }))
    const ctx = createMockContext({ tableData: phrases })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()
    const progressFn = vi.fn()
    migrator.setProgressCallback(progressFn)
    expect((await migrator.prepare(ctx)).success).toBe(true)
    expect(await migrator.execute(ctx)).toMatchObject({ success: true, processedCount: 15 })
    const rows = await dbh.db.select().from(promptTable).orderBy(asc(promptTable.id))
    expect(rows.map(({ id, content }) => ({ id, content }))).toEqual(
      phrases.map(({ id, content }) => ({ id, content }))
    )
    // BaseMigrator permits optional callbacks. MigrationEngine publishes start/end
    // itself; intermediate cadence and wording are implementation choices.
    for (const [progress, progressMessage] of progressFn.mock.calls) {
      expect(Number.isFinite(progress)).toBe(true)
      expect(progress).toBeGreaterThanOrEqual(0)
      expect(progress).toBeLessThanOrEqual(100)
      expect(typeof progressMessage.message).toBe('string')
    }
  })

  it('should preserve the legacy quick phrase id', async () => {
    const legacyId = '550e8400-e29b-41d4-a716-446655440060'
    const ctx = createMockContext({ tableData: [makePhrase({ id: legacyId, content: 'c1' })] })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()
    expect((await migrator.prepare(ctx)).success).toBe(true)
    expect((await migrator.execute(ctx)).success).toBe(true)
    const rows = await dbh.db.select().from(promptTable)
    expect(rows).toHaveLength(1)
    expect(rows[0].id).toBe(legacyId)
  })

  it('migrates quick phrases into the real prompt table with order keys', async () => {
    const ctx = createMockContext({
      tableData: [
        makePhrase({ id: '550e8400-e29b-41d4-a716-446655440000', title: 'Older', content: 'old ${name}', order: 2 }),
        makePhrase({ id: '550e8400-e29b-41d4-a716-446655440001', title: 'Newer', content: 'new', order: 1 })
      ]
    })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()

    const prepareResult = await migrator.prepare(ctx)
    const executeResult = await migrator.execute(ctx)
    const validateResult = await migrator.validate(ctx)

    const rows = await dbh.db.select().from(promptTable).orderBy(asc(promptTable.orderKey))

    expect(prepareResult).toMatchObject({ success: true, itemCount: 2 })
    expect(executeResult).toMatchObject({ success: true, processedCount: 2 })
    expect(validateResult.success).toBe(true)
    expect(rows.map((row) => row.title)).toEqual(['Older', 'Newer'])
    expect(rows.map((row) => row.id)).toEqual([
      '550e8400-e29b-41d4-a716-446655440000',
      '550e8400-e29b-41d4-a716-446655440001'
    ])
    expect(rows[0].orderKey < rows[1].orderKey).toBe(true)
  })
  it('skips missing or empty titles with warnings and preserves valid records', async () => {
    const validA = '550e8400-e29b-41d4-a716-446655440010'
    const validB = '550e8400-e29b-41d4-a716-446655440011'
    const tooLongId = '550e8400-e29b-41d4-a716-446655440015'
    const boundaryId = '550e8400-e29b-41d4-a716-446655440016'
    const paddedId = '550e8400-e29b-41d4-a716-446655440017'
    const ctx = createMockContext({ tableData: [
      makePhrase({ id: validA, title: 'Keep A', content: 'first', order: 10 }),
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440012', title: '', content: 'empty title' }),
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440013', title: undefined, content: 'missing title' }),
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440014', title: '   ', content: 'blank title' }),
      makePhrase({ id: validB, title: 'Keep B', content: 'second', order: 20 }),
      makePhrase({ id: tooLongId, title: 'x'.repeat(257), content: 'too long' }),
      makePhrase({ id: boundaryId, title: 'y'.repeat(256), content: 'valid boundary' }),
      makePhrase({ id: paddedId, title: '  Padded title  ', content: 'padded input' })
    ] })
    ctx.db = dbh.db
    const migrator = new PromptMigrator()
    const prepared = await migrator.prepare(ctx)
    expect(prepared.success).toBe(true)
    expect(Array.isArray(prepared.warnings) && prepared.warnings.length > 0).toBe(true)
    expect((await migrator.execute(ctx)).success).toBe(true)
    const rows = await dbh.db.select().from(promptTable)
    expect(rows.find((row) => row.id === tooLongId)).toBeUndefined()
    expect(rows.find((row) => row.id === boundaryId)).toMatchObject({ title: 'y'.repeat(256), content: 'valid boundary' })
    // The public contract requires persisted titles to be trimmed. It does not
    // choose between normalizing a legacy padded title and skipping it as invalid.
    const padded = rows.find((row) => row.id === paddedId)
    if (padded) expect(padded).toMatchObject({ title: 'Padded title', content: 'padded input' })
    for (const row of rows) {
      expect(row.title).toBe(row.title.trim())
      expect(row.title.length).toBeGreaterThan(0)
      expect(row.title.length).toBeLessThanOrEqual(256)
    }
    expect(rows.filter((row) => row.id !== paddedId)
      .map((row) => ({ id: row.id, title: row.title, content: row.content }))
      .sort((a, b) => a.id.localeCompare(b.id))).toEqual([
        { id: validA, title: 'Keep A', content: 'first' },
        { id: validB, title: 'Keep B', content: 'second' },
        { id: boundaryId, title: 'y'.repeat(256), content: 'valid boundary' }
      ])
  })

  it('reset discards prepared phrases and allows a fresh migration', async () => {
    const oldId = '550e8400-e29b-41d4-a716-446655440020'
    const newId = '550e8400-e29b-41d4-a716-446655440021'
    const before = createMockContext({ tableData: [
      makePhrase({ id: oldId, title: 'Discard this batch', content: 'old' }),
      makePhrase({ id: '550e8400-e29b-41d4-a716-446655440022', content: '' })
    ] })
    before.db = dbh.db
    const migrator = new PromptMigrator()
    expect((await migrator.prepare(before)).success).toBe(true)
    migrator.reset()
    const empty = await migrator.execute(before)
    expect(empty).toMatchObject({ success: true, processedCount: 0 })
    expect(await dbh.db.select().from(promptTable)).toEqual([])

    const after = createMockContext({ tableData: [
      makePhrase({ id: newId, title: 'Fresh batch', content: 'new' })
    ] })
    after.db = dbh.db
    const prepared = await migrator.prepare(after)
    expect(prepared.success).toBe(true)
    expect(prepared.warnings ?? []).toEqual([])
    expect((await migrator.execute(after)).success).toBe(true)
    expect((await migrator.validate(after)).success).toBe(true)
    const rows = await dbh.db.select().from(promptTable)
    expect(rows.map((row) => ({ id: row.id, title: row.title, content: row.content }))).toEqual([
      { id: newId, title: 'Fresh batch', content: 'new' }
    ])
  })

})
