"""Source decode parity through pre-existing public helpers and SourcesAPI.

Protocol fixtures/reference walks preserve legacy semantics; new row-adapter
names and private method signatures are not acceptance requirements.
"""
from __future__ import annotations
from unittest.mock import AsyncMock, MagicMock
import pytest
from notebooklm._sources import SourcesAPI
from datetime import datetime, timezone
from notebooklm.types import SourceNotFoundError, SourceType, _extract_source_url, _extract_source_created_at

def _legacy_extract_source_url(metadata, *, allow_bare_http=True):
    """Pre-drain ``_extract_source_url`` body, copied verbatim."""
    if not isinstance(metadata, list):
        return None
    url = None
    if len(metadata) > 7:
        url_list = metadata[7]
        if isinstance(url_list, list) and len(url_list) > 0:
            url = url_list[0]
    if not url and len(metadata) > 5:
        yt_data = metadata[5]
        if isinstance(yt_data, list) and len(yt_data) > 0 and isinstance(yt_data[0], str):
            url = yt_data[0]
    if not url and allow_bare_http and len(metadata) > 0:
        candidate = metadata[0]
        if isinstance(candidate, str) and candidate.startswith("http"):
            url = candidate
    return url


def _legacy_extract_source_created_at(metadata):
    """Freeze base conversion semantics without calling candidate helpers.

    The cached base explicitly uses aware UTC, not process-local time.
    Equality checks the datetime value, not the timezone object's identity.
    """
    if not isinstance(metadata, list) or len(metadata) <= 2:
        return None
    timestamp_list = metadata[2]
    if not isinstance(timestamp_list, list) or not timestamp_list:
        return None
    try:
        return datetime.fromtimestamp(timestamp_list[0], tz=timezone.utc)
    except (TypeError, ValueError, OSError, OverflowError):
        return None


def _legacy_guide(result):
    """Pre-drain ``get_guide`` decode body, copied verbatim."""
    summary = ""
    keywords: list = []
    if result and isinstance(result, list) and len(result) > 0:
        outer = result[0]
        if isinstance(outer, list) and len(outer) > 0:
            inner = outer[0]
            if isinstance(inner, list):
                summary_block = inner[1] if len(inner) > 1 and isinstance(inner[1], list) else None
                if summary_block:
                    summary = summary_block[0] if isinstance(summary_block[0], str) else ""
                keyword_block = inner[2] if len(inner) > 2 and isinstance(inner[2], list) else None
                if keyword_block:
                    keywords = keyword_block[0] if isinstance(keyword_block[0], list) else []
    return summary, keywords


def _legacy_fulltext(result):
    """Pre-drain ``get_fulltext`` title/metadata/html/text decode, verbatim.

    Returns ``(title, metadata, html_content, text_content_blocks)`` — the
    four positional values the adapter now owns.
    """
    title = ""
    metadata = None
    html = None
    text_blocks = None
    descriptor = result[0]
    if isinstance(descriptor, list) and len(descriptor) > 1:
        title = descriptor[1] if isinstance(descriptor[1], str) else ""
        if len(descriptor) > 2 and isinstance(descriptor[2], list):
            metadata = descriptor[2]
    html_block = result[4] if len(result) > 4 and isinstance(result[4], list) else None
    if html_block is not None and len(html_block) > 1:
        candidate = html_block[1]
        if isinstance(candidate, str):
            html = candidate
    text_block = result[3] if len(result) > 3 and isinstance(result[3], list) else None
    if text_block:
        content_blocks = text_block[0]
        if isinstance(content_blocks, list):
            text_blocks = content_blocks
    return title, metadata, html, text_blocks


_URL_CASES = [
    # (metadata, allow_bare_http)
    ([0, 1, 2, 3, 4, 5, 6, ["https://canonical/"]], True),  # present canonical
    ([0, 1, 2, 3, 4, 5, 6, [""]], True),  # falsy canonical -> raw "" (legacy quirk)
    ([0, 1, 2, 3, 4, 5, 6, [0]], True),  # falsy zero canonical -> raw 0
    ([0, 1, 2, 3, 4, 5, 6, [42]], True),  # non-str truthy -> raw int 42, no coercion
    ([0, 1, 2, 3, 4, 5, 6, []], True),  # empty canonical block
    ([0, 1, 2, 3, 4, 5, 6, "notlist"], True),  # non-list canonical block
    ([0, 1, 2, 3, 4, ["https://yt/"]], True),  # youtube string fallback
    ([0, 1, 2, 3, 4, [42]], True),  # youtube non-string ignored
    ([0, 1, 2, 3, 4, []], True),  # empty youtube block
    (["https://bare/"], True),  # bare http honored
    (["https://bare/"], False),  # bare http suppressed
    (["ftp://bare/"], True),  # bare non-http ignored
    ([42], True),  # bare non-string ignored
    ([], True),  # empty metadata
    ("notalist", True),  # non-list metadata
    (None, True),  # None metadata
    ([0, 1, 2, 3, 4, 5, 6, ["a", "b"]], True),  # canonical multi -> first
]


_CREATED_CASES = [
    [0, 1, [1_700_000_000]],  # present numeric
    [0, 1, [1_700_000_000.5]],  # float
    [0, 1, [True]],  # bool subclass of int -> 1s
    [0, 1, []],  # empty timestamp block
    [0, 1, None],  # None timestamp block
    [0, 1, ["abc"]],  # non-numeric string inner
    [0, 1, [None]],  # None inner
    [0, 1, "notlist"],  # non-list timestamp block
    [0, 1],  # too short (no idx 2)
    [],  # empty metadata
    "notalist",  # non-list metadata
    None,  # None metadata
    [0, 1, [1_700_000_000, 99]],  # multi -> first
]


_GUIDE_CASES = [
    [[["id", ["the summary"], [["kw1", "kw2"]]]]],  # present, full
    [[["id", [42], [["kw"]]]]],  # summary[0] non-str -> ""
    [[["id", ["s"], ["notlist"]]]],  # keyword[0] non-list -> []
    [[["id", [], []]]],  # empty blocks
    [[["id", "notlist", "notlist"]]],  # blocks non-list
    [[["id"]]],  # inner too short
    [[["id", ["s"]]]],  # no keyword block
    [[None]],  # inner None
    [None],  # outer None
    [[]],  # empty outer
    [],  # empty result
    None,  # None result
    "x",  # scalar result
    [[["id", ["s", "extra"], [["kw"], "extra"]]]],  # multi-elem blocks -> first
]


_FULLTEXT_CASES = [
    [["id"]],  # descriptor too short
    [[["id"], "Title", [0, 1, 2, 3, 4]]],  # descriptor present, metadata present
    [[["id"], 42, [0, 1, 2, 3, 4]]],  # title non-str -> ""
    [[["id"], "T", "notmeta"]],  # metadata non-list
    [[["id"], "T"]],  # no metadata slot
    [[["id"], "T", [0, 1, 2, 3, 9]], None, None, [["a", "b"]], [None, "<html>"]],  # full
    [[["id"], "T", []], None, None, [], []],  # empty text & html blocks
    [[["id"], "T", []], None, None, ["notlist"], [None, 42]],  # text[0] non-list, html non-str
    [[["id"], "T", []], None, None, [["txt"]], [None]],  # html block too short
    ["notdesc"],  # descriptor non-list
]


@pytest.mark.parametrize("metadata,allow", _URL_CASES + [
    ([0, 1, 2, 3, 4, ["https://fallback/"], 6, ["https://canonical/"]], True),
    ([0, 1, 2, 3, 4, ["https://fallback/"], 6, [""]], True),
])
def test_public_url_helper_keeps_legacy_precedence_and_types(metadata, allow):
    expected = _legacy_extract_source_url(metadata, allow_bare_http=allow)
    actual = _extract_source_url(metadata, allow_bare_http=allow)
    assert actual == expected
    assert type(actual) is type(expected)


@pytest.mark.parametrize("metadata", _CREATED_CASES)
def test_public_created_at_helper_keeps_legacy_conversion(metadata):
    assert _extract_source_created_at(metadata) == _legacy_extract_source_created_at(metadata)


def make_sources(payload):
    # Upload is not exercised; fake only the pre-existing collaborators.
    rpc = MagicMock(rpc_call=AsyncMock(return_value=payload))
    return SourcesAPI(rpc, uploader=MagicMock())


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", _GUIDE_CASES)
async def test_public_source_guide_preserves_soft_decode(payload):
    expected_summary, expected_keywords = _legacy_guide(payload)
    result = await make_sources(payload).get_guide("notebook-marker", "source-marker")
    assert result.summary == expected_summary
    assert tuple(result.keywords) == tuple(expected_keywords)


def legacy_text_strings(items):
    for item in items:
        if isinstance(item, str) and item:
            yield item
        elif isinstance(item, list):
            yield from legacy_text_strings(item)


_FULLTEXT_PUBLIC_CASES = _FULLTEXT_CASES + [
    [[["id"], "Doc title", [None, None, None, None, 5]], None, None,
     [["chunk-a", "chunk-b"]], [None, "<p>html</p>"]],
    [[["id"], "Type and URL", [0, 1, 2, 3, 5, ["https://fallback/"], 6, ["https://canonical/"]]],
     None, None, [[["first", "", 42], ["second"]]], [None, "<p>HTML marker</p>"]],
    [[["id"], "Malformed type", [0, 1, 2, 3, "five"]], None, None, [["diagnostic content marker"]]],
]


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", _FULLTEXT_PUBLIC_CASES)
async def test_public_fulltext_preserves_title_metadata_and_text(payload):
    title, metadata, _, blocks = _legacy_fulltext(payload)
    result = await make_sources(payload).get_fulltext("notebook-marker", "source-marker")
    assert result.source_id == "source-marker"
    assert result.title == title
    expected_text = "\n".join(legacy_text_strings(blocks)) if blocks is not None else ""
    assert result.content == expected_text
    assert result.char_count == len(expected_text)
    assert result.url == _legacy_extract_source_url(metadata, allow_bare_http=False)
    code = metadata[4] if isinstance(metadata, list) and len(metadata) > 4 else None
    # These fixtures cover existing public kinds, never new private row fields.
    assert result.kind == {4: SourceType.PASTED_TEXT, 5: SourceType.WEB_PAGE, 9: SourceType.YOUTUBE}.get(code, SourceType.UNKNOWN)


@pytest.mark.asyncio
@pytest.mark.parametrize("payload,expected", [
    (_FULLTEXT_PUBLIC_CASES[10], "html"),
    (_FULLTEXT_PUBLIC_CASES[11], "HTML marker"),
    ([[["id"], "No HTML"]], ""),
    ([[["id"], "Short HTML"], None, None, [], [None]], ""),
    ([[["id"], "Non-string HTML"], None, None, [], [None, 42]], ""),
    ([[["id"], "Non-list HTML"], None, None, [], "not-a-block"], ""),
])
async def test_public_fulltext_html_slot_and_soft_absence(payload, expected):
    result = await make_sources(payload).get_fulltext("notebook-marker", "source-marker", output_format="markdown")
    assert result.content.strip() == expected
    assert result.char_count == len(result.content)


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", [None, [], "not-a-list", {"wrong": "shape"}])
async def test_public_fulltext_preserves_missing_source_error(payload):
    # The public API already raises before attempting its soft descriptor walk.
    # A new private helper's return value is not a public requirement here.
    with pytest.raises(SourceNotFoundError):
        await make_sources(payload).get_fulltext("notebook-marker", "source-marker")


@pytest.mark.asyncio
async def test_public_fulltext_malformed_type_keeps_diagnostic(caplog):
    with caplog.at_level("WARNING"):
        result = await make_sources(_FULLTEXT_PUBLIC_CASES[12]).get_fulltext("notebook-marker", "source-marker")
    assert result.kind == SourceType.UNKNOWN
    assert any(record.levelno >= 30 for record in caplog.records)
