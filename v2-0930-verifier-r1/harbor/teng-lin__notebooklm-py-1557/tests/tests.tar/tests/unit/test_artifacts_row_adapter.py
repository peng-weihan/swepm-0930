"""Behavioral replacement for new artifact-envelope helper ABI checks.

Use pre-existing ArtifactsAPI + real note service and a fake wire RPC only.
No new row-adapter symbol or sentinel identity is part of this acceptance.
The unrelated adapter and LOC-ratchet issues are outside this draft's scope.
"""
from __future__ import annotations

import json
from copy import deepcopy
from unittest.mock import AsyncMock, MagicMock

import pytest

from notebooklm._artifacts import ArtifactsAPI
from notebooklm._mind_map import NoteBackedMindMapService
from notebooklm._note_service import NoteService
from notebooklm.exceptions import DecodingError
from notebooklm.rpc import ArtifactTypeCode
from notebooklm.types import ArtifactType
from tests._fixtures.fake_core import make_fake_core


class Wire:
    def __init__(self, responses):
        self.responses = responses
        self.calls = []

    async def call(self, method, params, **kwargs):
        name = getattr(method, "name", str(method))
        self.calls.append((name, deepcopy(params)))
        if name in self.responses:
            return deepcopy(self.responses[name])
        if name == "CREATE_NOTE":
            return [["created-note-marker"]]
        if name == "UPDATE_NOTE":
            return None
        if name == "GET_NOTES_AND_MIND_MAPS":
            return []
        raise AssertionError(f"Unexpected wire method in this fixture: {name}")


def make_api(responses):
    wire = Wire(responses)
    core = make_fake_core(rpc_call=AsyncMock(side_effect=wire.call))
    notebooks = MagicMock(get_source_ids=AsyncMock(return_value=["source-marker"]))
    note_service = NoteService(core)
    api = ArtifactsAPI(
        rpc=core,
        drain=core,
        lifecycle=core,
        notebooks=notebooks,
        mind_maps=NoteBackedMindMapService(note_service),
        note_service=note_service,
    )
    return api, wire


def strings_in(value):
    """Observe serialized wire content without requiring new internal fields."""
    if isinstance(value, str):
        yield value
    elif isinstance(value, (tuple, list)):
        for item in value:
            yield from strings_in(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from strings_in(item)


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", [None, [], [[]], [None], "scalar", 0, ["inner"], [0]])
async def test_absent_mind_map_leaf_has_no_note_side_effect(payload):
    api, wire = make_api({"GENERATE_MIND_MAP": payload})
    result = await api.generate_mind_map("notebook-marker", source_ids=["source-marker"])
    assert result.mind_map is None
    assert result.note_id is None
    assert not any(name in {"CREATE_NOTE", "UPDATE_NOTE"} for name, _ in wire.calls)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "leaf, expected_tree, expected_title",
    [
        (None, None, "Mind Map"),
        ("", "", "Mind Map"),
        (123, 123, "Mind Map"),
        ('{"name":"Tree marker","children":[]}', {"name": "Tree marker", "children": []}, "Tree marker"),
        ({"name": "Dictionary marker", "children": []}, {"name": "Dictionary marker", "children": []}, "Dictionary marker"),
        ({"name": None}, {"name": None}, "Mind Map"),
        ("not-json-marker", "not-json-marker", "Mind Map"),
    ],
)
async def test_present_mind_map_leaf_is_persisted(leaf, expected_tree, expected_title):
    api, wire = make_api({"GENERATE_MIND_MAP": [[leaf]]})
    result = await api.generate_mind_map("notebook-marker", source_ids=["source-marker"])
    assert result.mind_map == expected_tree
    assert result.note_id == "created-note-marker"
    assert any(name == "CREATE_NOTE" for name, _ in wire.calls)
    updates = [params for name, params in wire.calls if name == "UPDATE_NOTE"]
    assert updates, "Present leaves must reach the existing note persistence path"
    values = [s for params in updates for s in strings_in(params)]
    assert expected_title in values
    if isinstance(leaf, str):
        assert leaf in values
    else:
        # Compare parsed JSON content rather than its whitespace/key ordering.
        decoded = []
        for value in values:
            try:
                decoded.append(json.loads(value))
            except (TypeError, ValueError):
                continue
        assert leaf in decoded, "The leaf must be serialized as the note content"
        if leaf is None:
            assert "null" in values, "A present None is JSON null, not an absent leaf"


def artifact_rows():
    return [
        ["artifact-a", "Title A", ArtifactTypeCode.REPORT.value, None, 3],
        ["artifact-b", "Title B", ArtifactTypeCode.REPORT.value, None, 3],
    ]


@pytest.mark.asyncio
@pytest.mark.parametrize("shape", ["wrapped", "flat", "single-flat"])
async def test_artifact_list_wrapped_and_flat_rows_have_same_public_meaning(shape):
    rows = artifact_rows()
    if shape == "wrapped":
        payload, expected = [rows], rows
    elif shape == "single-flat":
        payload, expected = rows[:1], rows[:1]
    else:
        payload, expected = rows, rows
    api, _ = make_api({"LIST_ARTIFACTS": payload})
    result = await api.list("notebook-marker", artifact_type=ArtifactType.REPORT)
    assert [(item.id, item.title) for item in result] == [(row[0], row[1]) for row in expected]


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", [None, [], [[]], 0, ""])
async def test_artifact_list_soft_empty_payloads(payload):
    api, _ = make_api({"LIST_ARTIFACTS": payload})
    assert await api.list("notebook-marker", artifact_type=ArtifactType.REPORT) == []


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", ["truthy-schema-drift", {"unexpected": 1}])
async def test_artifact_list_keeps_existing_strict_drift_policy(payload):
    api, _ = make_api({"LIST_ARTIFACTS": payload})
    with pytest.raises(DecodingError):
        await api.list("notebook-marker", artifact_type=ArtifactType.REPORT)


@pytest.mark.asyncio
@pytest.mark.parametrize("shape", ["wrapped", "flat", "single-flat"])
async def test_report_suggestions_preserve_wrapped_and_flat_meaning(shape):
    rows = [
        ["Title A", "Description A", None, None, "Prompt A", 1],
        ["Title B", "Description B", None, None, "Prompt B"],
    ]
    if shape == "wrapped":
        payload, expected = [rows], rows
    elif shape == "single-flat":
        payload, expected = rows[:1], rows[:1]
    else:
        payload, expected = rows, rows
    api, _ = make_api({"GET_SUGGESTED_REPORTS": payload})
    result = await api.suggest_reports("notebook-marker")
    assert [(v.title, v.description, v.prompt, v.audience_level) for v in result] == [
        (row[0], row[1], row[4], row[5] if len(row) > 5 else 2) for row in expected
    ]


@pytest.mark.asyncio
@pytest.mark.parametrize("payload", [None, [], [[]], "scalar", 0, ["scalar-row"]])
async def test_report_suggestions_soft_empty_and_malformed_inputs(payload):
    api, _ = make_api({"GET_SUGGESTED_REPORTS": payload})
    assert await api.suggest_reports("notebook-marker") == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "payload",
    [
        [["first-leaf-marker", "ignored-inner-marker"]],
        [["first-leaf-marker"], ["ignored-outer-marker"]],
    ],
)
async def test_mind_map_uses_first_leaf_with_extra_envelope_slots(payload):
    api, wire = make_api({"GENERATE_MIND_MAP": payload})
    result = await api.generate_mind_map("notebook-marker", source_ids=["source-marker"])
    assert result.mind_map == "first-leaf-marker"
    assert result.note_id == "created-note-marker"
    values = [s for name, params in wire.calls if name == "UPDATE_NOTE" for s in strings_in(params)]
    assert "first-leaf-marker" in values
    assert "ignored-inner-marker" not in values
    assert "ignored-outer-marker" not in values
