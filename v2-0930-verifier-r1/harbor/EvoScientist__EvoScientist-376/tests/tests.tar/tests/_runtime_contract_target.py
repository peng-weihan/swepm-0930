"""Find the candidate's real runtime without prescribing its module filename.

This file supplies no runtime implementation, compatibility methods, or errors.
Every exported object comes from a production module in the candidate checkout.
Missing symbols and ambiguous runtime ownership remain explicit collection errors.
"""
from __future__ import annotations

import ast
import importlib
import importlib.util
import inspect
from pathlib import Path


_PACKAGE = "EvoScientist"
# These are existing production entry points exercised by the original tests,
# not a list of permitted implementation filenames.
_CONSUMERS = (
    "EvoScientist.stream.display",
    "EvoScientist.cli.tui_runtime",
    "EvoScientist.mcp.client",
    "EvoScientist.backends",
    "EvoScientist.channels.base",
)


def _production_sources():
    spec = importlib.util.find_spec(_PACKAGE)
    if spec is None or spec.submodule_search_locations is None:
        raise ImportError("Candidate EvoScientist package is unavailable")
    result = {}
    for directory in spec.submodule_search_locations:
        root = Path(directory).resolve()
        for path in root.rglob("*.py"):
            if not path.is_file() or not path.resolve().is_relative_to(root):
                continue
            parts = path.relative_to(root).with_suffix("").parts
            if any(part in {"tests", "test", "__pycache__"} for part in parts):
                continue
            if parts[-1] == "__init__":
                parts = parts[:-1]
            name = ".".join((_PACKAGE, *parts))
            try:
                tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            except (UnicodeError, SyntaxError):
                # An unrelated optional module is not imported by this helper.
                # Importing a selected module still exposes its actual error.
                continue
            result[name] = (path.resolve(), tree, path.name == "__init__.py")
    return result


def _imports(name, tree, is_package):
    """Resolve production import edges, including function-local imports."""
    package = name if is_package else name.rpartition(".")[0]
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                try:
                    target = importlib.util.resolve_name(
                        "." * node.level + (node.module or ""), package
                    )
                except (ImportError, ValueError):
                    continue
            else:
                target = node.module or ""
            if target:
                found.add(target)
                found.update(target + "." + alias.name for alias in node.names)
    return {target for target in found if target == _PACKAGE or target.startswith(_PACKAGE + ".")}


def _reachable(sources):
    pending = [name for name in _CONSUMERS if name in sources]
    seen = set()
    while pending:
        name = pending.pop()
        if name in seen or name not in sources:
            continue
        seen.add(name)
        _, tree, is_package = sources[name]
        pending.extend(_imports(name, tree, is_package) - seen)
    return seen


def _real_module(cls, sources):
    name = getattr(cls, "__module__", "")
    if name not in sources:
        raise ImportError("AsyncRuntime is not defined in candidate production sources: " + name)
    module = importlib.import_module(name)
    actual = Path(getattr(module, "__file__", "")).resolve()
    if actual != sources[name][0]:
        raise ImportError("Runtime module import did not resolve to the candidate source: " + name)
    if getattr(module, "AsyncRuntime", None) is not cls:
        raise ImportError("Runtime module does not export the production-bound AsyncRuntime: " + name)
    return module


def _resolve_runtime_module():
    sources = _production_sources()
    bound = {}
    import_errors = []
    for name in _CONSUMERS:
        if name not in sources:
            continue
        try:
            consumer = importlib.import_module(name)
        except ImportError as error:
            import_errors.append(name + ": " + str(error))
            continue
        for label, value in vars(consumer).items():
            if inspect.isclass(value) and (
                label == "AsyncRuntime" or value.__name__ == "AsyncRuntime"
            ):
                bound[id(value)] = value
    if len(bound) > 1:
        owners = sorted(cls.__module__ for cls in bound.values())
        raise ImportError("Production consumers bind multiple AsyncRuntime classes: " + repr(owners))
    if bound:
        return _real_module(next(iter(bound.values())), sources)

    # Lazy imports need not have created a module-level binding. In that case,
    # inspect the existing consumers' import graph instead of guessing filenames.
    candidates = []
    for name in sorted(_reachable(sources)):
        _, tree, _ = sources[name]
        if any(isinstance(node, ast.ClassDef) and node.name == "AsyncRuntime" for node in tree.body):
            candidates.append(name)
    if len(candidates) != 1:
        raise ImportError(
            "Cannot identify one production-owned AsyncRuntime without guessing: "
            + repr(candidates) + "; consumer import errors: " + repr(import_errors)
        )
    module = importlib.import_module(candidates[0])
    cls = getattr(module, "AsyncRuntime", None)
    if not inspect.isclass(cls):
        raise ImportError("Candidate AsyncRuntime is not a class: " + candidates[0])
    return _real_module(cls, sources)


runtime_module = _resolve_runtime_module()


def __getattr__(name):
    # Crucially, do not supply fallbacks for RuntimeHandle, closed errors, or any
    # methods. Those separate contract questions must remain visible for review.
    return getattr(runtime_module, name)
