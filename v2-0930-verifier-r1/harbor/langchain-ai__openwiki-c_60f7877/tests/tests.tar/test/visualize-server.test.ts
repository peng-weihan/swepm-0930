// Draft replacement for the original one-test fake server: build the candidate
// through its package script, then exercise its public openwiki CLI entry.
import { readFile, mkdtemp, writeFile, mkdir, chmod, symlink } from 'node:fs/promises';
import { createServer } from 'node:net';
import { request } from 'node:http';
import { spawn, type ChildProcess } from 'node:child_process';
import path from 'node:path';
import { tmpdir } from 'node:os';
import { expect, test } from 'vitest';

const pause = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));

async function unusedPort() {
  const probe = createServer(); // Allocates a port only; never handles HTTP.
  await new Promise<void>((resolve, reject) => {
    probe.once('error', reject);
    probe.listen(0, '127.0.0.1', resolve);
  });
  const bound = probe.address();
  if (!bound || typeof bound === 'string') throw new Error('port allocation failed');
  const port = bound.port;
  await new Promise<void>((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  if (port < 1024 || port > 65535) throw new Error('ephemeral port outside CLI contract');
  return port;
}

function get(port: number, rawPath: string): Promise<{status: number; body: string}> {
  return new Promise((resolve, reject) => {
    // Preserve traversal spelling; URL normalization must not erase the probe.
    const req = request({host: '127.0.0.1', port, path: rawPath, method: 'GET'}, res => {
      let size = 0;
      const chunks: Buffer[] = [];
      res.on('data', chunk => {
        const b = Buffer.from(chunk); size += b.length;
        if (size > 1024 * 1024) { res.destroy(new Error('response limit')); return; }
        chunks.push(b);
      });
      res.once('error', reject);
      res.once('end', () => resolve({status: res.statusCode ?? 0, body: Buffer.concat(chunks).toString('utf8')}));
    });
    req.setTimeout(1000, () => req.destroy(new Error('HTTP timeout')));
    req.once('error', reject);
    req.end();
  });
}

async function stop(child: ChildProcess) {
  for (const signal of ['SIGINT', 'SIGTERM', 'SIGKILL'] as const) {
    if (child.exitCode !== null || child.signalCode !== null) return;
    child.kill(signal);
    const until = Date.now() + 2000;
    while (child.exitCode === null && child.signalCode === null && Date.now() < until) await pause(20);
  }
  if (child.exitCode === null && child.signalCode === null) throw new Error('CLI child not reaped');
}


async function buildCandidate(root: string, evidence: string) {
  // Keep a failed build in this one test; unrelated target tests still collect.
  const child = spawn('pnpm', ['run', 'build'], {
    cwd: root, detached: true, stdio: ['ignore', 'pipe', 'pipe'],
    env: {...process.env, COREPACK_ENABLE_NETWORK: '0'},
  });
  let failure: Error | undefined;
  const chunks: Buffer[][] = [[], []];
  const bytes = [0, 0];
  const killGroup = () => {
    if (!child.pid) return;
    try { process.kill(-child.pid, 'SIGKILL'); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ESRCH') throw error; }
  };
  child.once('error', error => { failure = error; });
  [child.stdout!, child.stderr!].forEach((stream, index) => stream.on('data', chunk => {
    const b = Buffer.from(chunk); bytes[index] += b.length;
    if (bytes[index] > 1024 * 1024) {
      failure = new Error('candidate build output exceeded 1 MiB per stream');
      killGroup();
    } else chunks[index].push(b);
  }));
  const timer = setTimeout(() => {
    failure = new Error('candidate package build timed out after 120s');
    killGroup();
  }, 120000);
  let code: number | null = null;
  try {
    code = await new Promise<number | null>(resolve => child.once('close', resolve));
  } finally {
    clearTimeout(timer);
    // Kill the created process group even if its leader has already exited.
    try { killGroup(); }
    finally {
      await writeFile(path.join(evidence, 'build.stdout'), Buffer.concat(chunks[0]));
      await writeFile(path.join(evidence, 'build.stderr'), Buffer.concat(chunks[1]));
    }
  }
  if (failure || code !== 0) {
    throw new Error(`candidate package build failed (${code}): ${failure?.message ?? ''}\n${Buffer.concat(chunks[0]).toString('utf8')}\n${Buffer.concat(chunks[1]).toString('utf8')}`);
  }
}

async function publicOpenwikiBin(root: string): Promise<string> {
  const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
  // Support both standard package.json bin forms; do not require dist/cli.js.
  const bin = typeof pkg.bin === 'string' && typeof pkg.name === 'string'
    && pkg.name.split('/').pop() === 'openwiki' ? pkg.bin : pkg.bin?.openwiki;
  if (typeof bin !== 'string' || bin.length === 0) throw new Error('package.json must expose the public openwiki bin');
  return path.resolve(root, bin);
}

// All runtime cases live in this one sequential test file, and share one
// successful current-candidate native build. No source changes between cases.
// No second suite may run pnpm clean concurrently against the same dist tree.
let candidateBuild: Promise<void> | undefined;
async function ensureCandidateBuilt(evidence: string) {
  candidateBuild ??= buildCandidate(process.cwd(), evidence);
  await candidateBuild;
}

test('actual visualize CLI binds loopback and serves only fixed routes', async () => {
  const wiki = await mkdtemp(path.join(tmpdir(), 'swepm-openwiki-real-server-'));
  await writeFile(path.join(wiki, 'index.md'), '# Diagnostic home\n');
  await ensureCandidateBuilt(wiki);
  const cli = await publicOpenwikiBin(process.cwd());
  const port = await unusedPort();
  const child = spawn(process.execPath, [cli, 'visualize', wiki, '--port', String(port), '--no-open'], {
    cwd: process.cwd(), stdio: ['ignore', 'pipe', 'pipe'],
    env: {...process.env, OPENWIKI_TELEMETRY_DISABLED: '1', CI: '1'},
  });
  let output = '';
  let launchError: Error | undefined;
  child.once('error', error => { launchError = error; });
  const receive = (chunk: Buffer) => {
    output += chunk.toString('utf8');
    if (Buffer.byteLength(output) > 128 * 1024) {
      launchError = new Error('CLI diagnostic output cap');
      child.kill('SIGKILL');
    }
  };
  child.stdout!.on('data', receive); child.stderr!.on('data', receive);
  try {
    let home: Awaited<ReturnType<typeof get>> | undefined;
    const deadline = Date.now() + 15000;
    while (Date.now() < deadline) {
      if (launchError || child.exitCode !== null || child.signalCode !== null) {
        throw new Error(`CLI startup failed: ${launchError?.message ?? child.exitCode ?? child.signalCode}\n${output}`);
      }
      try { home = await get(port, '/'); break; } catch { await pause(100); }
    }
    if (!home) throw new Error(`real CLI did not listen within 15s\n${output}`);
    expect(home.status, 'real app shell').toBe(200);
    expect(home.body.length, 'real app shell is nonempty').toBeGreaterThan(0);
    // Linux socket state observes the binding, without coupling to HOST or a
    // private server helper. A wildcard listener still answers localhost HTTP.
    const tcp = await readFile('/proc/net/tcp', 'utf8');
    const listeners = tcp.split('\n').slice(1).map(line => line.trim().split(/\s+/))
      .filter(fields => fields[3] === '0A' && fields[1]?.split(':')[1] === port.toString(16).toUpperCase().padStart(4, '0'));
    expect(new Set(listeners.map(fields => fields[1])), 'actual listening address').toEqual(new Set([`0100007F:${port.toString(16).toUpperCase().padStart(4, '0')}`]));
    const tcp6 = await readFile('/proc/net/tcp6', 'utf8');
    const samePort6 = tcp6.split('\n').slice(1).map(line => line.trim().split(/\s+/))
      .filter(fields => fields[3] === '0A' && fields[1]?.split(':')[1] === port.toString(16).toUpperCase().padStart(4, '0'));
    const loopback6 = new Set(['00000000000000000000000001000000', '0000000000000000FFFF00000100007F']);
    expect(samePort6.every(fields => loopback6.has(fields[1].split(':')[0])), 'no same-port non-loopback IPv6 listener').toBe(true);
    for (const route of ['/not-a-public-route', '/..%2f..%2fetc%2fpasswd']) {
      const res = await get(port, route);
      expect(res.status, `production rejects ${route}`).toBe(404);
      expect(['Not found', '404 Not found'], `production error body for ${route}`).toContain(res.body);
    }
  } finally {
    // Retain fixture files and output under persistent TMPDIR for diagnosis.
    await stop(child);
    await writeFile(path.join(wiki, 'cli-output.log'), output);
  }
}, 160000);

// UNEXECUTED PROTOTYPE: the browser sink needs its own controls before this
// complete replacement can be enabled. Existing formal tests are untouched.
const browserRecorder = "#!/usr/bin/env node\n// Test-only prototype. No browser is installed or launched by this recorder.\nconst fs = require('node:fs');\nconst path = require('node:path');\nconst entry = path.basename(process.argv[1]);\nconst args = process.argv.slice(2);\nconst urls = entry === 'gio' && args[0] === 'open' ? args.slice(1) : args;\nif (entry === 'gio' && args[0] !== 'open') process.exit(64);\nif (urls.length !== 1 || urls[0].length > 2048) process.exit(64);\nconst file = process.env.SWEPM_BROWSER_EVENTS;\nif (!file || !path.isAbsolute(file)) process.exit(64);\nfs.appendFileSync(file, JSON.stringify({entry, url: urls[0]}) + '\\n');\n";

type BrowserEvent = {entry: string; url: string};
type CliFixture = {root: string; cwd: string; browserBin: string; events: string};

async function cliFixture(label: string): Promise<CliFixture> {
  const root = await mkdtemp(path.join(tmpdir(), `swepm-openwiki-cli-${label}-`));
  const cwd = path.join(root, 'cwd');
  const browserBin = path.join(root, 'browser-bin');
  const events = path.join(root, 'browser-events.jsonl');
  await mkdir(cwd); await mkdir(browserBin); await writeFile(events, '');
  const recorder = path.join(browserBin, 'record-browser.cjs');
  await writeFile(recorder, browserRecorder); await chmod(recorder, 0o700);
  // Public OS entries, not candidate modules or child_process method names.
  // BROWSER covers handlers that delegate to a configured browser. PATH shims
  // cover ordinary Linux launchers irrespective of exec/execFile/spawn family.
  for (const name of ['xdg-open', 'gio', 'sensible-browser', 'x-www-browser', 'www-browser']) {
    await symlink('record-browser.cjs', path.join(browserBin, name));
  }
  return {root, cwd, browserBin, events};
}

function fixtureEnv(fixture: CliFixture): NodeJS.ProcessEnv {
  // Keep runtime/cache locations, not provider credentials from a solver env.
  // Do not change HOME or any existing system settings/default-browser config.
  const env: NodeJS.ProcessEnv = {};
  for (const key of ['PATH', 'TMPDIR', 'XDG_CACHE_HOME', 'NODE_COMPILE_CACHE', 'COREPACK_HOME', 'LANG', 'LC_ALL', 'TERM']) {
    if (process.env[key] !== undefined) env[key] = process.env[key];
  }
  return {...env, PATH: `${fixture.browserBin}:${env.PATH ?? ''}`,
    BROWSER: path.join(fixture.browserBin, 'record-browser.cjs'),
    SWEPM_BROWSER_EVENTS: fixture.events,
    OPENWIKI_TELEMETRY_DISABLED: '1', CI: '1', COREPACK_ENABLE_NETWORK: '0'};
}

async function browserEvents(fixture: CliFixture): Promise<BrowserEvent[]> {
  const contents = await readFile(fixture.events, 'utf8');
  if (Buffer.byteLength(contents) > 64 * 1024) throw new Error('browser event evidence cap');
  return contents.split('\n').filter(Boolean).map(line => {
    const row = JSON.parse(line);
    if (typeof row.entry !== 'string' || typeof row.url !== 'string') throw new Error('bad browser evidence');
    return row;
  });
}

async function portInitiallyFree(port: number) {
  const probe = createServer();
  try {
    await new Promise<void>((resolve, reject) => {
      probe.once('error', reject); probe.listen(port, '127.0.0.1', resolve);
    });
  } catch (error) {
    throw new Error(`fixture cannot reserve required initial port ${port}: ${String(error)}`);
  } finally {
    if (probe.listening) await new Promise<void>((resolve, reject) => probe.close(e => e ? reject(e) : resolve()));
  }
}

async function assertLoopbackSocket(port: number) {
  const hex = port.toString(16).toUpperCase().padStart(4, '0');
  const tcp = await readFile('/proc/net/tcp', 'utf8');
  const listeners = tcp.split('\n').slice(1).map(line => line.trim().split(/\s+/))
    .filter(fields => fields[3] === '0A' && fields[1]?.split(':')[1] === hex);
  expect(new Set(listeners.map(fields => fields[1]))).toEqual(new Set([`0100007F:${hex}`]));
  const tcp6 = await readFile('/proc/net/tcp6', 'utf8');
  const extra = tcp6.split('\n').slice(1).map(line => line.trim().split(/\s+/))
    .filter(fields => fields[3] === '0A' && fields[1]?.split(':')[1] === hex);
  const local6 = new Set(['00000000000000000000000001000000', '0000000000000000FFFF00000100007F']);
  expect(extra.every(fields => local6.has(fields[1].split(':')[0]))).toBe(true);
}

async function invokeCli(
  fixture: CliFixture, label: string, args: string[], port: number,
  expectLaunch: boolean, browser: 'open' | 'closed',
) {
  const cli = await publicOpenwikiBin(process.cwd());
  const before = (await browserEvents(fixture)).length;
  const child = spawn(process.execPath, [cli, 'visualize', ...args], {
    cwd: fixture.cwd, stdio: ['ignore', 'pipe', 'pipe'], env: fixtureEnv(fixture),
  });
  let output = ''; let launchError: Error | undefined;
  child.once('error', error => { launchError = error; });
  const receive = (chunk: Buffer) => {
    output += chunk.toString('utf8');
    if (Buffer.byteLength(output) > 128 * 1024) {
      launchError = new Error('CLI output evidence cap'); child.kill('SIGKILL');
    }
  };
  child.stdout!.on('data', receive); child.stderr!.on('data', receive);
  try {
    let home: Awaited<ReturnType<typeof get>> | undefined;
    const until = Date.now() + 15000;
    while (Date.now() < until) {
      if (launchError) throw launchError;
      if (child.exitCode !== null || child.signalCode !== null) break;
      try { home = await get(port, '/'); break; } catch { await pause(50); }
    }
    if (!expectLaunch) {
      expect(home, 'missing requested directory must not serve a fallback directory').toBeUndefined();
      expect(child.signalCode, 'missing directory must fail normally').toBeNull();
      expect(child.exitCode, `missing-directory CLI did not exit: ${output}`).not.toBeNull();
      expect(child.exitCode).not.toBe(0);
      expect(output.trim(), 'missing-directory diagnostic exists').not.toBe('');
      // Do not demand the gold diagnostic wording or exact absolute-path format.
      expect((await browserEvents(fixture)).slice(before)).toEqual([]);
      return;
    }
    expect(child.exitCode, output).toBeNull(); expect(child.signalCode, output).toBeNull();
    expect(home, `CLI did not serve the expected port: ${output}`).toBeDefined();
    expect(home!.status).toBe(200); expect(home!.body.length).toBeGreaterThan(0);
    await assertLoopbackSocket(port);
    // This is a finite startup observation, not a proof about arbitrary future
    // delayed side effects. No private banner or invented graph endpoint used.
    const browserUntil = Date.now() + 1500;
    let observed: BrowserEvent[] = [];
    do {
      observed = (await browserEvents(fixture)).slice(before);
      await pause(50);
    } while (Date.now() < browserUntil);
    observed = (await browserEvents(fixture)).slice(before);
    if (browser === 'closed') expect(observed, '--no-open must suppress browser requests').toEqual([]);
    else {
      let openedServedUrl = false;
      for (const event of observed) {
        try {
          const url = new URL(event.url);
          // Do not require the gold URL spelling or app-shell route spelling.
          // Other host aliases need fixture review before scoring, not a claim
          // that the implementation is invalid merely for choosing an alias.
          if (url.protocol !== 'http:' || Number(url.port) !== port
            || !['127.0.0.1', 'localhost'].includes(url.hostname)) continue;
          const opened = await get(port, `${url.pathname}${url.search}`);
          if (opened.status === 200 && opened.body.length > 0) openedServedUrl = true;
        } catch { /* malformed/wrong/dead URL is not successful browser dispatch */ }
      }
      expect(openedServedUrl, 'default command requests an actually served loopback URL').toBe(true);
    }
  } finally {
    await stop(child);
    await writeFile(path.join(fixture.root, `${label}.cli-output.log`), output);
  }
}

test('defaults: openwiki dir, port 4321, opens the browser', async () => {
  const fixture = await cliFixture('default');
  await ensureCandidateBuilt(fixture.root);
  await portInitiallyFree(4321);
  await invokeCli(fixture, 'missing-default', [], 4321, false, 'closed');
  const wiki = path.join(fixture.cwd, 'openwiki');
  await mkdir(wiki); await writeFile(path.join(wiki, 'index.md'), '# Default wiki\n');
  await invokeCli(fixture, 'present-default', [], 4321, true, 'open');
}, 160000);

test('accepts a positional dir, --port, and --no-open', async () => {
  const fixture = await cliFixture('explicit');
  await ensureCandidateBuilt(fixture.root);
  // A valid default decoy makes silently ignoring the explicit path observable.
  const decoy = path.join(fixture.cwd, 'openwiki');
  await mkdir(decoy); await writeFile(path.join(decoy, 'index.md'), '# Wrong decoy\n');
  const relativeRequested = path.join('docs', 'selected-wiki');
  const requested = path.join(fixture.cwd, relativeRequested);
  const port = await unusedPort();
  const args = [relativeRequested, '--port', String(port), '--no-open'];
  await invokeCli(fixture, 'missing-explicit', args, port, false, 'closed');
  await mkdir(requested, {recursive: true}); await writeFile(path.join(requested, 'index.md'), '# Selected wiki\n');
  await invokeCli(fixture, 'present-explicit', args, port, true, 'closed');
}, 160000);

test('supports --port=NNNN form', async () => {
  const fixture = await cliFixture('equals-port');
  await ensureCandidateBuilt(fixture.root);
  const requested = path.join(fixture.cwd, 'equals-wiki');
  await mkdir(requested); await writeFile(path.join(requested, 'index.md'), '# Equals option\n');
  // Keep the accepted range, explicit equals form, and next-available-port
  // behavior together. The blocker is a socket reservation, not a fake app.
  let port = 0;
  for (let attempt = 0; attempt < 10; attempt++) {
    const proposed = await unusedPort();
    if (proposed >= 65535) continue;
    try { await portInitiallyFree(proposed + 1); port = proposed; break; } catch { /* pick another pair */ }
  }
  if (!port) throw new Error('fixture could not find adjacent available ports');
  const args = [requested, `--port=${port}`, '--no-open'];
  await invokeCli(fixture, 'equals-port', args, port, true, 'closed');
  const blocker = createServer();
  try {
    await new Promise<void>((resolve, reject) => {
      blocker.once('error', reject); blocker.listen(port, '127.0.0.1', resolve);
    });
    await invokeCli(fixture, 'equals-port-conflict', args, port + 1, true, 'closed');
  } finally {
    if (blocker.listening) await new Promise<void>((resolve, reject) => blocker.close(e => e ? reject(e) : resolve()));
  }
}, 160000);
