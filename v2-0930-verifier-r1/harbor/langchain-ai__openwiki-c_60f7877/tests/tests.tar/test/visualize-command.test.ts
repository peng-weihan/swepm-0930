import { describe, expect, test } from "vitest";
import { parseCommand } from "../src/commands.ts";

describe("parseCommand visualize", () => {
  test("rejects an out-of-range port", () => {
    expect(parseCommand(["visualize", "--port", "80"])).toEqual({
      kind: "error",
      exitCode: 1,
      message: "--port must be between 1024 and 65535.",
    });
  });

  test("rejects a missing --port value", () => {
    expect(parseCommand(["visualize", "--port"])).toEqual({
      kind: "error",
      exitCode: 1,
      message: "--port requires a value.",
    });
  });

  test("rejects an unknown option", () => {
    const command = parseCommand(["visualize", "--nope"]);
    expect(command.kind).toBe("error");
  });
});
