# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     testConfig.py
   Description :   ConfigHandler环境变量测试
   Author :        JHao
   date：          2026/5/28
-------------------------------------------------
   Change Activity:
                   2026/05/28:
-------------------------------------------------
"""
__author__ = 'JHao'

import os
import pytest
import setting
from handler.configHandler import ConfigHandler


@pytest.fixture(autouse=True)
def clean_env():
    """测试前后清理可能设置的环境变量"""
    env_keys = ["DB_CONN", "PORT", "HOST", "TABLE_NAME", "HTTP_URL",
                "HTTPS_URL", "VERIFY_TIMEOUT", "MAX_FAIL_COUNT",
                "POOL_SIZE_MIN", "PROXY_REGION", "TIMEZONE"]
    saved = {k: os.environ.get(k) for k in env_keys}
    for k in env_keys:
        os.environ.pop(k, None)
    yield
    for k, v in saved.items():
        if v is not None:
            os.environ[k] = v
        else:
            os.environ.pop(k, None)


@pytest.fixture
def conf():
    return ConfigHandler()


class TestConfigHandlerDefaults:

    def test_db_conn_default(self, conf):
        assert conf.dbConn == setting.DB_CONN

    def test_server_host_default(self, conf):
        assert conf.serverHost == setting.HOST

    def test_server_port_default(self, conf):
        assert str(conf.serverPort) == str(setting.PORT)

    def test_table_name_default(self, conf):
        assert conf.tableName == setting.TABLE_NAME

    def test_http_url_default(self, conf):
        assert conf.httpUrl == setting.HTTP_URL

    def test_https_url_default(self, conf):
        assert conf.httpsUrl == setting.HTTPS_URL

    def test_verify_timeout_default(self, conf):
        assert conf.verifyTimeout == setting.VERIFY_TIMEOUT

    def test_max_fail_count_default(self, conf):
        assert conf.maxFailCount == setting.MAX_FAIL_COUNT

    def test_pool_size_min_default(self, conf):
        assert conf.poolSizeMin == setting.POOL_SIZE_MIN

    def test_timezone_default(self, conf):
        assert conf.timezone == setting.TIMEZONE

    def test_fetcher_exclude_is_list(self, conf):
        assert isinstance(conf.fetcherExclude, list)


class TestConfigHandlerEnvOverride:

    def test_db_conn_override(self):
        os.environ["DB_CONN"] = "redis://:newpwd@10.0.0.1:6380/3"
        conf = ConfigHandler()
        assert conf.dbConn == "redis://:newpwd@10.0.0.1:6380/3"

    def test_port_override(self):
        os.environ["PORT"] = "8080"
        conf = ConfigHandler()
        assert str(conf.serverPort) == "8080"

    def test_verify_timeout_override(self):
        os.environ["VERIFY_TIMEOUT"] = "30"
        conf = ConfigHandler()
        assert conf.verifyTimeout == 30

    def test_max_fail_count_override(self):
        os.environ["MAX_FAIL_COUNT"] = "5"
        conf = ConfigHandler()
        assert conf.maxFailCount == 5

"""Unexecuted draft: real CLI plus only new, test-owned public plugin files.

Execution is not authorized by this file. An outer, reviewed runner must provide
an isolated /data-backed writable source view, explicit logs/tmp/cache mounts,
network isolation and a complete source-before/source-after manifest check.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _has_token(output, name):
    return re.search(r"(?<!\w)" + re.escape(name) + r"(?!\w)", output) is not None


def test_show_discovers_new_enabled_plugin_and_omits_disabled_and_unnamed():
    # Explicit path from the future runner, never inferred from a private helper.
    repo = Path.cwd().resolve(strict=True)
    assert repo == Path("/testbed"), "Verifier must run from its fixed repository cwd"
    sources = repo / "fetcher" / "sources"
    assert sources.is_dir(), "The task explicitly requires fetcher/sources/"
    assert not sources.is_symlink(), "Outer runner must validate the source view"
    assert os.path.commonpath([str(repo), str(sources.resolve())]) == str(repo), (
        "Public plugin directory resolves outside the isolated repository"
    )
    entry = repo / "proxyPool.py"
    assert entry.is_file(), "The task explicitly requires proxyPool.py show"
    token = uuid.uuid4().hex
    names = {
        "active": "VerifierEnabled" + token,
        "disabled": "VerifierDisabled" + token,
        "unnamed": "VerifierUnnamed" + token,
    }
    owned = []
    cleanup_errors = []
    try:
        for kind, classname in names.items():
            path = sources / ("verifier_owned_" + kind + "_" + token + ".py")
            enabled = "    enabled = False\n" if kind == "disabled" else ""
            # The enabled case deliberately inherits the required default True.
            source_name = "" if kind == "unnamed" else "verifier_" + kind + "_" + token
            data = (
                "from fetcher.baseFetcher import BaseFetcher\n\n"
                + "class " + classname + "(BaseFetcher):\n"
                + "    name = " + repr(source_name) + "\n"
                + "    url = 'https://fixture.invalid/'\n"
                + enabled
                + "    def fetch(self):\n"
                + "        if False:\n"
                + "            yield '192.0.2.1:8080'\n"
            ).encode()
            # O_EXCL: a collision never overwrites a candidate file.
            with path.open("xb") as stream:
                owned.append((path, _sha(data)))
                receipt_name = os.environ.get("SWEPM_CLI_FIXTURE_RECEIPT")
                if receipt_name:
                    Path(receipt_name).write_text(json.dumps([{"path": str(p.relative_to(repo)), "sha256": h} for p, h in owned]) + "\n")
                stream.write(data)
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        proc = subprocess.run(
            [sys.executable, "-B", str(entry), "show"],
            cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, timeout=30, check=False,
        )
        # Preserve actual child output in pytest --capture=tee-sys native logs.
        print("CLI_SHOW_EXIT", proc.returncode)
        print("CLI_SHOW_STDOUT_BEGIN\n" + proc.stdout + "CLI_SHOW_STDOUT_END")
        print("CLI_SHOW_STDERR_BEGIN\n" + proc.stderr + "CLI_SHOW_STDERR_END")
        assert proc.returncode == 0, "Real CLI failed: " + proc.stderr
        assert _has_token(proc.stdout, names["active"]), (
            "CLI did not list the newly installed enabled public plugin: "
            + names["active"] + "\n" + proc.stdout
        )
        assert not _has_token(proc.stdout, names["disabled"]), (
            "CLI listed a disabled public plugin\n" + proc.stdout
        )
        assert not _has_token(proc.stdout, names["unnamed"]), (
            "CLI listed a public plugin whose name is empty\n" + proc.stdout
        )
        # No hard-coded heading, indentation, migrated class names or count.
        # Sorted discovery, exclusions and same-process reload are separate scope.
    finally:
        for path, expected_sha in reversed(owned):
            try:
                if path.is_symlink() or _sha(path.read_bytes()) != expected_sha:
                    cleanup_errors.append("Owned fixture changed; retained: " + str(path))
                else:
                    path.unlink()
            except OSError as exc:
                cleanup_errors.append("Owned fixture cleanup failed: " + str(exc))
        assert not cleanup_errors, "\n".join(cleanup_errors)
