# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     test_fetcher_sources.py
   Description :   各代理源 fetcher 测试
   Author :        JHao
   date：          2026/5/31
-------------------------------------------------
   Change Activity:
                   2026/05/31:
-------------------------------------------------
"""
__author__ = 'JHao'

import re
from unittest.mock import patch, MagicMock

from lxml import etree

from fetcher.baseFetcher import BaseFetcher


# Match preserved source websites, not implementation-specific filenames/classes.
# Multiple plugins may legitimately serve one website.
from contextlib import ExitStack
from functools import lru_cache
import importlib
import inspect
import pkgutil
from urllib.parse import urlsplit

_REQUIRED_SOURCE_HOSTS = {'ip66': '66ip.cn', 'kxdaili': 'kxdaili.com', 'binglx': 'binglx.cn', 'ip3366': 'ip3366.net', 'jiangxianli': 'jiangxianli.com', 'ip89': '89ip.cn', 'docip': 'docip.net', 'goodips': 'goodips.com', 'geonode': 'geonode.com', 'freeproxylist': 'freeproxylists.net', 'kuaidaili': 'kuaidaili.com', 'freevpnnode': 'freevpnnode.com', 'scdn': 'scdn.io', 'zdaye': 'zdaye.com', 'ihuan': 'ihuan.me'}
_SELECTED_SOURCE = {}


@lru_cache(maxsize=None)
def _source_classes(source_key):
    package = importlib.import_module("fetcher.sources")
    host = _REQUIRED_SOURCE_HOSTS[source_key]
    matches = set()
    for entry in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
        module = importlib.import_module(entry.name)
        for _, cls in inspect.getmembers(module, inspect.isclass):
            if cls is BaseFetcher or not issubclass(cls, BaseFetcher):
                continue
            if cls.__module__ != module.__name__:
                continue
            actual = (urlsplit(str(getattr(cls, "url", ""))).hostname or "").lower()
            if actual == host or actual.endswith("." + host):
                matches.add(cls)
    assert matches, f"Missing preserved proxy source for {host}"
    return tuple(sorted(matches, key=lambda cls: (cls.__module__, cls.__name__)))


def _source_class(source_key):
    if source_key in _SELECTED_SOURCE:
        return _SELECTED_SOURCE[source_key]
    candidates = _source_classes(source_key)
    # The interface tests below still execute their original assertions against
    # a real subclass. Additional same-site plugins do not hide a missing source.
    return next((cls for cls in candidates
                 if getattr(cls, "name", None) and getattr(cls, "url", None)
                 and hasattr(cls, "enabled") and hasattr(cls, "fetch")), candidates[0])


def _source_case(source_key, *mock_targets):
    def decorate(method):
        def run(self):
            failures = []
            for cls in _source_classes(source_key):
                module = importlib.import_module(cls.__module__)
                _SELECTED_SOURCE[source_key] = cls
                try:
                    with ExitStack() as stack:
                        # Original @patch decorators supply mock arguments from
                        # the innermost decorator outwards.
                        mocks = [stack.enter_context(patch.object(module, attr, **options))
                                 for attr, options in reversed(mock_targets)]
                        method(self, *mocks)
                    return
                except Exception as error:
                    failures.append((cls, error))
                finally:
                    _SELECTED_SOURCE.pop(source_key, None)
            # Keep every candidate failure in the final diagnosis. No successful
            # candidate means the actual original assertions have not passed.
            detail = "\n".join(
                f"{cls.__module__}.{cls.__name__}: {type(error).__name__}: {error}"
                for cls, error in failures
            )
            raise AssertionError(
                f"No {_REQUIRED_SOURCE_HOSTS[source_key]} plugin satisfied the preserved source test:\n{detail}"
            ) from failures[0][1]
        # Do not expose mock-only parameters to pytest fixture discovery.
        run.__name__ = method.__name__
        run.__doc__ = method.__doc__
        return run
    return decorate


# --------------- 辅助工具 ---------------

def _make_response(text="", tree=None, json_data=None):
    """构造 mock 的 WebRequest 返回对象"""
    resp = MagicMock()
    resp.text = text
    resp.tree = tree
    resp.json = json_data if json_data is not None else {}
    return resp


def _html_table(rows, has_header=False):
    """快速生成 HTML table 字符串"""
    html = "<table>"
    if has_header:
        html += "<tr><th>IP</th><th>Port</th></tr>"
    for ip, port in rows:
        html += "<tr><td>%s</td><td>%s</td></tr>" % (ip, port)
    html += "</table>"
    return html


def _assert_valid_proxies(proxies):
    """验证所有 proxy 符合 ip:port 格式"""
    pattern = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5}$')
    for p in proxies:
        assert pattern.match(p), f"Invalid proxy format: {p}"


# --------------- 接口约定测试 ---------------

class TestFetcherInterface(object):
    """所有 fetcher 的接口约定"""

    REQUIRED_SOURCES = ['ip66', 'kxdaili', 'binglx', 'ip3366', 'jiangxianli', 'ip89', 'docip', 'goodips', 'geonode', 'freeproxylist', 'kuaidaili', 'freevpnnode', 'scdn', 'zdaye', 'ihuan']

    def test_all_fetchers_have_name_url_enabled(self):
        for source_key in self.REQUIRED_SOURCES:
            cls = _source_class(source_key)
            class_name = cls.__name__
            assert cls.name, f"{class_name} missing name"
            assert cls.url, f"{class_name} missing url"
            assert hasattr(cls, 'enabled'), f"{class_name} missing enabled"

    def test_all_fetchers_subclass_base(self):
        for source_key in self.REQUIRED_SOURCES:
            cls = _source_class(source_key)
            class_name = cls.__name__
            assert issubclass(cls, BaseFetcher), f"{class_name} not subclass of BaseFetcher"

    def test_all_fetchers_have_fetch_method(self):
        for source_key in self.REQUIRED_SOURCES:
            cls = _source_class(source_key)
            class_name = cls.__name__
            assert hasattr(cls, 'fetch'), f"{class_name} missing fetch method"


# --------------- 各 fetcher 逻辑测试 ---------------

class TestIp66Fetcher(object):

    @_source_case('ip66')
    def test_fetch(self):
        Ip66Fetcher = _source_class('ip66')
        html = ("<table></table><table></table>"
                + _html_table([("IP", "Port"), ("1.2.3.4", "8080"), ("5.6.7.8", "3128")]))
        result = _fetch_http_body(Ip66Fetcher, html)
        assert "1.2.3.4:8080" in result
        assert "5.6.7.8:3128" in result


class TestKxdailiFetcher(object):

    @_source_case('kxdaili')
    def test_fetch(self):
        KxdailiFetcher = _source_class('kxdaili')
        html = '<table class="active"><tr><th>IP</th><th>Port</th></tr>' \
               '<tr><td>1.2.3.4</td><td>8080</td></tr></table>'
        result = _fetch_http_body(KxdailiFetcher, html)
        assert "1.2.3.4:8080" in result


class TestBinglxFetcher(object):

    @_source_case('binglx')
    def test_fetch(self):
        BinglxFetcher = _source_class('binglx')
        html = _html_table([("IP", "Port"), ("1.2.3.4", "8080")])
        result = _fetch_http_body(BinglxFetcher, html)
        assert "1.2.3.4:8080" in result


class TestIp3366Fetcher(object):

    @_source_case('ip3366')
    def test_fetch(self):
        Ip3366Fetcher = _source_class('ip3366')
        html = '<td>1.2.3.4</td><td>8080</td><td>5.6.7.8</td><td>3128</td>'
        result = _fetch_http_body(Ip3366Fetcher, html)
        assert "1.2.3.4:8080" in result
        assert "5.6.7.8:3128" in result


class TestJiangxianliFetcher(object):

    @_source_case('jiangxianli')
    def test_fetch(self):
        JiangxianliFetcher = _source_class('jiangxianli')
        html = _html_table([("IP", "Port"), ("1.2.3.4", "8080")])
        result = _fetch_http_body(JiangxianliFetcher, html)
        assert "1.2.3.4:8080" in result


class TestIp89Fetcher(object):

    @_source_case('ip89')
    def test_fetch(self):
        Ip89Fetcher = _source_class('ip89')
        html = '<td>1.2.3.4</td><td>8080</td>'
        result = _fetch_http_body(Ip89Fetcher, html)
        assert "1.2.3.4:8080" in result


class TestDocipFetcher(object):

    @_source_case('docip')
    def test_fetch(self):
        DocipFetcher = _source_class('docip')
        json_data = {"data": [{"ip": "1.2.3.4:8080"}, {"ip": "5.6.7.8:3128"}]}
        result = _fetch_http_body(DocipFetcher, json_data, json_response=True)
        assert "1.2.3.4:8080" in result
        assert "5.6.7.8:3128" in result


class TestGoodipsFetcher(object):

    @_source_case('goodips')
    def test_fetch(self):
        GoodipsFetcher = _source_class('goodips')
        html = '<div class="table-list"><ul><li>1.2.3.4</li><li>8080</li></ul></div>'
        result = _fetch_http_body(GoodipsFetcher, html)
        assert "1.2.3.4:8080" in result


class TestGeonodeFetcher(object):

    @_source_case('geonode')
    def test_fetch_json(self):
        GeonodeFetcher = _source_class('geonode')
        json_data = {"data": [{"ip": "1.2.3.4", "port": "8080"}]}
        result = _fetch_http_body(GeonodeFetcher, json_data, json_response=True)
        assert "1.2.3.4:8080" in result

    @_source_case('geonode')
    def test_fetch_text_fallback(self):
        GeonodeFetcher = _source_class('geonode')
        result = _fetch_http_body(GeonodeFetcher, "1.2.3.4:8080")
        assert "1.2.3.4:8080" in result


class TestFreeProxyListFetcher(object):

    @_source_case('freeproxylist')
    def test_fetch(self):
        FreeProxyListFetcher = _source_class('freeproxylist')
        script_content = "document.write('%31%2E%32%2E%33%2E%34')"
        html = '<table><tr class="Odd"><td><script>%s</script></td><td>8080</td></tr></table>' % script_content
        result = _fetch_http_body(FreeProxyListFetcher, html)
        assert isinstance(result, list)
        assert "1.2.3.4:8080" in result


class TestKuaidailiFetcher(object):

    @_source_case('kuaidaili')
    def test_fetch(self):
        KuaidailiFetcher = _source_class('kuaidaili')
        html = _html_table([("IP", "Port"), ("1.2.3.4", "8080")])
        result = _fetch_http_body(KuaidailiFetcher, html)
        assert "1.2.3.4:8080" in result


class TestFreeVPNNodeFetcher(object):

    @_source_case('freevpnnode')
    def test_fetch(self):
        FreeVPNNodeFetcher = _source_class('freevpnnode')
        html = _html_table([("1.2.3.4", "8080")])
        result = _fetch_http_body(FreeVPNNodeFetcher, html + "<p>1.2.3.4:8080 5.6.7.8:3128</p>")
        assert "1.2.3.4:8080" in result
        assert "5.6.7.8:3128" in result


class TestScdnFetcher(object):

    @_source_case('scdn')
    def test_fetch_json(self):
        ScdnFetcher = _source_class('scdn')
        json_data = {"data": [{"ip": "1.2.3.4", "port": "8080"}]}
        result = _fetch_http_body(ScdnFetcher, json_data, json_response=True)
        assert "1.2.3.4:8080" in result

    @_source_case('scdn')
    def test_fetch_table_html(self):
        ScdnFetcher = _source_class('scdn')
        table_html = '<tr><td>1.2.3.4</td><td>8080</td></tr>'
        json_data = {"table_html": table_html}
        result = _fetch_http_body(ScdnFetcher, json_data, json_response=True)
        assert "1.2.3.4:8080" in result


def _prepared_html_response(request, html):
    # Exercise the existing Requests -> WebRequest -> real lxml parser boundary.
    # This fixture does not inspect any candidate module's import bindings.
    from requests import Response
    response = Response()
    response.status_code = 200
    response.url = request.url
    response.request = request
    response.encoding = "utf-8"
    response.headers["Content-Type"] = "text/html; charset=utf-8"
    response._content = html.encode("utf-8")
    return response



def _fetch_http_body(fetcher_class, body, json_response=False):
    """Exercise the baseline HTTP transport and parser without module aliases."""
    import json
    from requests.sessions import Session

    if json_response:
        body = json.dumps(body)

    def send(session, request, **kwargs):
        response = _prepared_html_response(request, body)
        if json_response:
            response.headers["Content-Type"] = "application/json"
        return response

    with patch.object(Session, "send", autospec=True, side_effect=send):
        return list(fetcher_class().fetch())


def _zdaye_html_response(request, age_seconds):
    # Use the same local-wall-clock semantics as the unchanged baseline.
    # Generate the timestamp at request handling, away from the 300s boundary.
    from datetime import datetime, timedelta
    if request.url.rstrip("/").endswith("/detail/1"):
        return _prepared_html_response(
            request, _html_table([("1.2.3.4", "8080")]))
    posted_at = (datetime.now() - timedelta(seconds=age_seconds)).strftime(
        "%Y/%m/%d %H:%M:%S")
    # Keep a valid detail page even for the old post: ignoring age must reach
    # the existing empty-result assertion, rather than failing on malformed HTML.
    return _prepared_html_response(
        request,
        '<span class="thread_time_info">' + posted_at + '</span>'
        '<h3 class="thread_title"><a href="/detail/1">test</a></h3>')


class TestZdayeFetcher(object):

    @_source_case('zdaye')
    def test_fetch_recent(self):
        from requests.sessions import Session
        ZdayeFetcher = _source_class('zdaye')

        def send(session, request, **kwargs):
            return _zdaye_html_response(request, age_seconds=120)

        # No mocked datetime or sleep name. A one-page successful fetch may
        # retain its baseline five-second sleep; that is allowed behavior.
        with patch.object(Session, "send", autospec=True, side_effect=send):
            result = list(ZdayeFetcher().fetch())
        assert "1.2.3.4:8080" in result

    @_source_case('zdaye')
    def test_fetch_old_returns_empty(self):
        from requests.sessions import Session
        ZdayeFetcher = _source_class('zdaye')

        def send(session, request, **kwargs):
            return _zdaye_html_response(request, age_seconds=7200)

        with patch.object(Session, "send", autospec=True, side_effect=send):
            result = list(ZdayeFetcher().fetch())
        assert result == []


class TestIhuanFetcher(object):

    @_source_case('ihuan')
    def test_fetch(self):
        from requests.sessions import Session
        IhuanFetcher = _source_class('ihuan')

        def send(session, request, **kwargs):
            if request.method == "POST":
                # A single real HTTP body contains both representations that
                # the original fixture exposed independently as tree and text.
                body = (_html_table([("1.2.3.4", "8080")])
                        + "<p>1.2.3.4:8080</p>")
            else:
                body = '<form><input name="key" value="abc123def456789012345678"></form>'
            return _prepared_html_response(request, body)

        with patch.object(Session, "send", autospec=True, side_effect=send):
            result = list(IhuanFetcher().fetch())
        assert "1.2.3.4:8080" in result

    @_source_case('ihuan')
    def test_fetch_no_key_returns_empty(self):
        from requests.sessions import Session
        IhuanFetcher = _source_class('ihuan')

        def send(session, request, **kwargs):
            if request.method == "POST":
                body = _html_table([("1.2.3.4", "8080")])
            else:
                body = "<form></form>no key here"
            return _prepared_html_response(request, body)

        with patch.object(Session, "send", autospec=True, side_effect=send):
            result = list(IhuanFetcher().fetch())
        assert result == []
