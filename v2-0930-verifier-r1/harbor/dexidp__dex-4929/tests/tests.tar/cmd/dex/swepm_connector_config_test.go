package main

import (
	"encoding/json"
	"reflect"
	"testing"

	"github.com/dexidp/dex/connector/atlassiancrowd"
	"github.com/dexidp/dex/connector/authproxy"
	"github.com/dexidp/dex/connector/bitbucketcloud"
	"github.com/dexidp/dex/connector/gitea"
	"github.com/dexidp/dex/connector/github"
	"github.com/dexidp/dex/connector/gitlab"
	"github.com/dexidp/dex/connector/google"
	"github.com/dexidp/dex/connector/keystone"
	"github.com/dexidp/dex/connector/ldap"
	"github.com/dexidp/dex/connector/linkedin"
	"github.com/dexidp/dex/connector/microsoft"
	"github.com/dexidp/dex/connector/mock"
	"github.com/dexidp/dex/connector/oauth"
	"github.com/dexidp/dex/connector/oidc"
	"github.com/dexidp/dex/connector/openshift"
	"github.com/dexidp/dex/connector/saml"
)

// Exercise the public CLI configuration parser. Constructing a config value
// must not open the connector or require any external identity-provider server.
func TestSWEPMBuiltinConnectorConfigurationParsing(t *testing.T) {
	for _, test := range []struct {
		kind string
		want any
	}{
		{"ldap", &ldap.Config{}},
		{"github", &github.Config{}},
		{"gitlab", &gitlab.Config{}},
		{"google", &google.Config{}},
		{"oidc", &oidc.Config{}},
		{"oauth", &oauth.Config{}},
		{"saml", &saml.Config{}},
		{"authproxy", &authproxy.Config{}},
		{"linkedin", &linkedin.Config{}},
		{"microsoft", &microsoft.Config{}},
		{"bitbucket-cloud", &bitbucketcloud.Config{}},
		{"openshift", &openshift.Config{}},
		{"atlassian-crowd", &atlassiancrowd.Config{}},
		{"samlExperimental", &saml.Config{}},
		// These built-ins also exist before the refactor and must be preserved.
		{"gitea", &gitea.Config{}},
		{"keystone", &keystone.Config{}},
		{"mockCallback", &mock.CallbackConfig{}},
		{"mockPassword", &mock.PasswordConfig{}},
	} {
		t.Run(test.kind, func(t *testing.T) {
			data, err := json.Marshal(map[string]any{
				"connectors": []any{map[string]any{
					"type": test.kind, "id": "swepm-" + test.kind, "name": "SWEPM " + test.kind,
					"config": map[string]any{}, "grantTypes": []string{"authorization_code"},
				}},
			})
			if err != nil {
				t.Fatal(err)
			}
			var parsed Config
			if err := json.Unmarshal(data, &parsed); err != nil {
				t.Fatalf("parse built-in %q through Config: %v", test.kind, err)
			}
			if len(parsed.StaticConnectors) != 1 {
				t.Fatalf("Config lost the connector: %v", parsed.StaticConnectors)
			}
			connector := parsed.StaticConnectors[0]
			if connector.Type != test.kind || connector.ID != "swepm-"+test.kind || connector.Name != "SWEPM "+test.kind {
				t.Errorf("connector identity was not preserved: type=%q id=%q name=%q", connector.Type, connector.ID, connector.Name)
			}
			if reflect.TypeOf(connector.Config) != reflect.TypeOf(test.want) {
				t.Errorf("%s config decoded into %T, want existing public config type %T", test.kind, connector.Config, test.want)
			}
			if !reflect.DeepEqual(connector.GrantTypes, []string{"authorization_code"}) {
				t.Errorf("connector grant restrictions were lost: %v", connector.GrantTypes)
			}
		})
	}
}

func TestSWEPMUnknownConnectorConfigurationRejected(t *testing.T) {
	var parsed Config
	err := json.Unmarshal([]byte(`{"connectors":[{"type":"swepm-not-a-connector","id":"unknown","config":{}}]}`), &parsed)
	if err == nil {
		t.Fatal("unknown connector type was accepted by public Config parsing")
	}
}
