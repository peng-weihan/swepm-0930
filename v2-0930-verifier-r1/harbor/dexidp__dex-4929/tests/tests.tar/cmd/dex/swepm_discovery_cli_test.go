package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	"github.com/dexidp/dex/api/v2"
)

// The child is the already compiled test binary, not "go run" or a new build.
// Calling the language entrypoint exercises the real public `dex serve` command
// and lets production choose its API/discovery wiring, without test references
// to a particular Server getter, field, or constructor's dependency shape.
func TestSWEPMDiscoveryCLIHelperProcess(t *testing.T) {
	config := os.Getenv("SWEPM_DEX_DISCOVERY_CONFIG")
	if config == "" {
		return
	}
	os.Args = []string{"dex", "serve", config}
	main()
}

type swepmDiscoveryConfig struct {
	path          string
	responseTypes []string
	grants        []string
	pkce          []string
	sessions      bool
}

func TestSWEPMConfiguredDiscoveryMatchesHTTP(t *testing.T) {
	for _, configuration := range []swepmDiscoveryConfig{
		{
			path: "/swepm/code-only", responseTypes: []string{"code"},
			grants: []string{"authorization_code"}, pkce: []string{"S256"},
		},
		{
			path: "/swepm/implicit-and-refresh", responseTypes: []string{"code", "token"},
			grants: []string{"authorization_code", "implicit", "refresh_token"}, pkce: []string{"S256", "plain"},
		},
	} {
		t.Run(configuration.path, func(t *testing.T) {
			swepmCheckConfiguredDiscovery(t, configuration)
		})
	}
}

func TestSWEPMConfiguredDiscoveryWithSessionsMatchesHTTP(t *testing.T) {
	swepmCheckConfiguredDiscovery(t, swepmDiscoveryConfig{
		path: "/swepm/with-sessions", responseTypes: []string{"code"},
		grants: []string{"authorization_code", "refresh_token"}, pkce: []string{"S256"}, sessions: true,
	})
}

type swepmDiscoveryProcess struct {
	command *exec.Cmd
	done    chan struct{}
	err     error // Read only after done is closed.
	log     *os.File
	logPath string
	issuer  string
	grpc    string
	stop    sync.Once
}

func (process *swepmDiscoveryProcess) close() {
	process.stop.Do(func() {
		select {
		case <-process.done:
		default:
			_ = process.command.Process.Signal(os.Interrupt)
			select {
			case <-process.done:
			case <-time.After(5 * time.Second):
				_ = process.command.Process.Kill()
				<-process.done
			}
		}
		_ = process.log.Close()
	})
}

func (process *swepmDiscoveryProcess) diagnostic() string {
	file, err := os.Open(process.logPath)
	if err != nil {
		return fmt.Sprintf("cannot read %s: %v", process.logPath, err)
	}
	defer file.Close()
	data, _ := io.ReadAll(io.LimitReader(file, 32<<10))
	return string(data)
}

func swepmStartDiscoveryCLI(t *testing.T, configuration swepmDiscoveryConfig) (*swepmDiscoveryProcess, []byte) {
	t.Helper()
	temporaryRoot := os.Getenv("TMPDIR")
	if temporaryRoot == "" || temporaryRoot == "/tmp" {
		t.Fatal("set persistent TMPDIR (for example /logs/verifier/tmp) before running CLI tests")
	}
	directory, err := os.MkdirTemp(temporaryRoot, "swepm-dex-discovery-")
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("SWEPM_DISCOVERY_FIXTURE=%s", directory)
	webDirectory, err := filepath.Abs("../../web")
	if err != nil {
		t.Fatal(err)
	}

	// Reserve two distinct ports until immediately before child startup. A rare
	// bind race is retried only when the child's actual error says address in use;
	// assertion failures and other startup errors are never retried away.
	for attempt := 0; attempt < 3; attempt++ {
		httpReservation, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			t.Fatal(err)
		}
		grpcReservation, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			httpReservation.Close()
			t.Fatal(err)
		}
		httpAddress := httpReservation.Addr().String()
		grpcAddress := grpcReservation.Addr().String()
		issuer := "http://" + httpAddress + configuration.path
		config := map[string]any{
			"issuer":   issuer,
			"storage":  map[string]any{"type": "memory", "config": map[string]any{}},
			"web":      map[string]any{"http": httpAddress},
			"grpc":     map[string]any{"addr": grpcAddress},
			"frontend": map[string]any{"dir": webDirectory},
			"logger":   map[string]any{"level": "info", "format": "json"},
			"connectors": []any{map[string]any{
				"type": "mockCallback", "id": "swepm-mock", "name": "SWEPM Mock", "config": map[string]any{},
			}},
			"signer": map[string]any{"type": "local", "config": map[string]any{
				"keysRotationPeriod": "6h", "algorithm": "ES256",
			}},
			"oauth2": map[string]any{
				"responseTypes": configuration.responseTypes, "grantTypes": configuration.grants,
				"pkce": map[string]any{"codeChallengeMethodsSupported": configuration.pkce},
			},
		}
		if configuration.sessions {
			config["sessions"] = map[string]any{
				"cookieName": "swepm_session", "absoluteLifetime": "24h", "validIfNotUsedFor": "1h",
			}
		}
		data, err := json.Marshal(config)
		if err != nil {
			httpReservation.Close()
			grpcReservation.Close()
			t.Fatal(err)
		}
		configPath := filepath.Join(directory, fmt.Sprintf("config-%d.json", attempt))
		if err := os.WriteFile(configPath, data, 0600); err != nil {
			httpReservation.Close()
			grpcReservation.Close()
			t.Fatal(err)
		}
		logPath := filepath.Join(directory, fmt.Sprintf("cli-%d.log", attempt))
		log, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
		if err != nil {
			httpReservation.Close()
			grpcReservation.Close()
			t.Fatal(err)
		}
		command := exec.Command(os.Args[0], "-test.run=^TestSWEPMDiscoveryCLIHelperProcess$")
		command.Stdout, command.Stderr = log, log
		for _, value := range os.Environ() {
			key, _, _ := strings.Cut(value, "=")
			switch key {
			case "SWEPM_DEX_DISCOVERY_CONFIG", "DEX_SESSIONS_ENABLED", "DEX_CONFIG_DISALLOW_UNKNOWN_FIELDS", "DEX_EXPAND_ENV":
			default:
				command.Env = append(command.Env, value)
			}
		}
		command.Env = append(command.Env,
			"SWEPM_DEX_DISCOVERY_CONFIG="+configPath,
			"DEX_SESSIONS_ENABLED="+strconv.FormatBool(configuration.sessions),
			"DEX_CONFIG_DISALLOW_UNKNOWN_FIELDS=true", "DEX_EXPAND_ENV=false",
		)
		_ = httpReservation.Close()
		_ = grpcReservation.Close()
		if err := command.Start(); err != nil {
			log.Close()
			t.Fatalf("start existing test binary: %v", err)
		}
		process := &swepmDiscoveryProcess{
			command: command, done: make(chan struct{}), log: log, logPath: logPath, issuer: issuer, grpc: grpcAddress,
		}
		go func() {
			process.err = command.Wait()
			close(process.done)
		}()
		t.Cleanup(process.close)
		body, err := swepmWaitForHTTPDiscovery(process)
		if err == nil {
			return process, body
		}
		process.close()
		diagnostic := process.diagnostic()
		if strings.Contains(diagnostic, "address already in use") && attempt < 2 {
			t.Logf("retrying loopback bind race; log=%s", logPath)
			continue
		}
		t.Fatalf("CLI discovery did not become ready: %v\nlog=%s\n%s", err, logPath, diagnostic)
	}
	t.Fatal("loopback bind retries exhausted")
	return nil, nil
}

func swepmWaitForHTTPDiscovery(process *swepmDiscoveryProcess) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	transport := &http.Transport{Proxy: nil}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: time.Second}
	for {
		select {
		case <-process.done:
			return nil, fmt.Errorf("CLI exited: %v", process.err)
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}
		request, err := http.NewRequestWithContext(ctx, http.MethodGet, process.issuer+"/.well-known/openid-configuration", nil)
		if err != nil {
			return nil, err
		}
		response, err := client.Do(request)
		if err == nil {
			body, readError := io.ReadAll(io.LimitReader(response.Body, 1<<20))
			response.Body.Close()
			if response.StatusCode != http.StatusOK {
				return nil, fmt.Errorf("HTTP discovery status %d: %s", response.StatusCode, body)
			}
			return body, readError
		}
		select {
		case <-time.After(25 * time.Millisecond):
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	}
}

func swepmCheckConfiguredDiscovery(t *testing.T, configuration swepmDiscoveryConfig) {
	t.Helper()
	process, httpJSON := swepmStartDiscoveryCLI(t, configuration)
	httpDocument := swepmDiscoveryJSON(t, httpJSON)
	connection, err := grpc.NewClient("passthrough:///"+process.grpc,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
		grpc.WithContextDialer(func(ctx context.Context, address string) (net.Conn, error) {
			return (&net.Dialer{}).DialContext(ctx, "tcp", process.grpc)
		}),
	)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { connection.Close() })
	client := api.NewDexClient(connection)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	versionBefore, err := client.GetVersion(ctx, &api.VersionReq{}, grpc.WaitForReady(true))
	if err != nil || versionBefore == nil || versionBefore.Server == "" {
		t.Fatalf("real gRPC GetVersion: response=%v error=%v\n%s", versionBefore, err, process.diagnostic())
	}
	document, err := client.GetDiscovery(ctx, &api.DiscoveryReq{})
	if err != nil {
		t.Fatalf("configured gRPC GetDiscovery: %v", err)
	}
	if document == nil {
		t.Fatal("configured GetDiscovery returned a nil document")
	}
	apiJSON, err := json.Marshal(document)
	if err != nil {
		t.Fatalf("serialize actual RPC response: %v", err)
	}
	apiDocument := swepmDiscoveryJSON(t, apiJSON)
	for field, suffix := range map[string]string{
		"issuer": "", "authorization_endpoint": "/auth", "token_endpoint": "/token",
		"jwks_uri": "/keys", "userinfo_endpoint": "/userinfo", "device_authorization_endpoint": "/device/code",
		"introspection_endpoint": "/token/introspect",
	} {
		want := process.issuer + suffix
		if httpDocument[field] != want {
			t.Errorf("HTTP %s = %v, want configured %q", field, httpDocument[field], want)
		}
		if apiDocument[field] != want {
			t.Errorf("GetDiscovery %s = %v, want configured %q", field, apiDocument[field], want)
		}
	}
	for field, want := range map[string][]string{
		"response_types_supported": configuration.responseTypes, "grant_types_supported": configuration.grants,
		"code_challenge_methods_supported": configuration.pkce, "id_token_signing_alg_values_supported": {"ES256"},
	} {
		swepmAssertStringSet(t, "HTTP", field, httpDocument[field], want)
		swepmAssertStringSet(t, "GetDiscovery", field, apiDocument[field], want)
	}
	if configuration.sessions {
		want := process.issuer + "/logout"
		if httpDocument["end_session_endpoint"] != want {
			t.Errorf("HTTP discovery lost configured session endpoint: %v", httpDocument["end_session_endpoint"])
		}
		if apiDocument["end_session_endpoint"] != want {
			t.Errorf("GetDiscovery JSON lost HTTP end_session_endpoint: got %v, want %q", apiDocument["end_session_endpoint"], want)
		}
	}
	// Compare the entire HTTP object to the actual protobuf-roundtripped response.
	// Never project HTTP JSON into DiscoveryResp, which would hide unknown fields.
	if !reflect.DeepEqual(httpDocument, apiDocument) {
		t.Errorf("GetDiscovery JSON does not match HTTP discovery:\nHTTP: %s\nAPI: %s", httpJSON, apiJSON)
	}
	versionAfter, err := client.GetVersion(ctx, &api.VersionReq{})
	if err != nil || versionAfter == nil || versionAfter.Server != versionBefore.Server || versionAfter.Api != versionBefore.Api {
		t.Errorf("GetDiscovery changed GetVersion: before=%v after=%v error=%v", versionBefore, versionAfter, err)
	}
}

func swepmDiscoveryJSON(t *testing.T, data []byte) map[string]any {
	t.Helper()
	var result map[string]any
	if err := json.Unmarshal(data, &result); err != nil {
		t.Fatalf("invalid discovery JSON: %v", err)
	}
	if len(result) == 0 {
		t.Fatal("discovery document must not be empty")
	}
	return result
}

func swepmAssertStringSet(t *testing.T, channel, field string, raw any, expected []string) {
	t.Helper()
	values, ok := raw.([]any)
	if !ok {
		t.Errorf("%s %s is not a string array: %v", channel, field, raw)
		return
	}
	actual := make([]string, 0, len(values))
	for _, value := range values {
		text, ok := value.(string)
		if !ok {
			t.Errorf("%s %s contains a non-string: %v", channel, field, value)
			return
		}
		actual = append(actual, text)
	}
	want := append([]string(nil), expected...)
	sort.Strings(actual)
	sort.Strings(want)
	if !reflect.DeepEqual(actual, want) {
		t.Errorf("%s %s = %v, want configured %v", channel, field, actual, want)
	}
}
