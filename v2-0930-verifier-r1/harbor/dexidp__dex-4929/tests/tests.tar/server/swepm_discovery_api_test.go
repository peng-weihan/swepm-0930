package server

import (
	"context"
	"io"
	"log/slog"
	"strings"
	"testing"

	"github.com/dexidp/dex/api/v2"
	"github.com/dexidp/dex/server/apiserver"
	"github.com/dexidp/dex/storage/memory"
)

// The public API must remain usable when the optional discovery dependency is
// absent. This deliberately passes nil rather than choosing a concrete
// discovery implementation or accessing the private dexAPI fields.
func TestSWEPMGetDiscoveryWithoutConfiguration(t *testing.T) {
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	store := memory.New(logger)
	t.Cleanup(func() {
		if err := store.Close(); err != nil {
			t.Errorf("close in-memory storage: %v", err)
		}
	})

	apiServer := apiserver.NewAPI(store, logger, "swepm-discovery-test", nil, nil)
	ctx := context.Background()

	// A nil discovery dependency should not prevent unrelated API requests.
	version, err := apiServer.GetVersion(ctx, &api.VersionReq{})
	if err != nil {
		t.Fatalf("GetVersion without discovery: %v", err)
	}
	if version == nil || version.Server != "swepm-discovery-test" {
		t.Fatalf("GetVersion lost the configured server version: %v", version)
	}

	defer func() {
		if recovered := recover(); recovered != nil {
			t.Errorf("GetDiscovery must return a configuration error, not panic: %v", recovered)
		}
	}()
	_, err = apiServer.GetDiscovery(ctx, &api.DiscoveryReq{})
	if err == nil {
		t.Fatal("GetDiscovery must report that discovery is not configured")
	}
	message := strings.ToLower(err.Error())
	// The wording is not an API contract; the error should identify discovery
	// as the missing dependency without requiring the reference's exact text.
	if !strings.Contains(message, "discovery") {
		t.Errorf("GetDiscovery must identify missing discovery configuration; got %q", err)
	}
}
