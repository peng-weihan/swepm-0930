/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.openmemind.ai.memory.core.builder;

import static org.assertj.core.api.Assertions.assertThat;

import com.openmemind.ai.memory.core.buffer.InsightBuffer;
import com.openmemind.ai.memory.core.buffer.MemoryBuffer;
import com.openmemind.ai.memory.core.buffer.PendingConversationBuffer;
import com.openmemind.ai.memory.core.buffer.RecentConversationBuffer;
import com.openmemind.ai.memory.core.data.enums.MemoryCategory;
import com.openmemind.ai.memory.core.extraction.MemoryExtractor;
import com.openmemind.ai.memory.core.extraction.context.CommitDetectorConfig;
import com.openmemind.ai.memory.core.extraction.context.LlmContextCommitDetector;
import com.openmemind.ai.memory.core.extraction.insight.InsightLayer;
import com.openmemind.ai.memory.core.extraction.insight.generator.LlmInsightGenerator;
import com.openmemind.ai.memory.core.extraction.insight.group.LlmInsightGroupClassifier;
import com.openmemind.ai.memory.core.extraction.insight.scheduler.InsightBuildConfig;
import com.openmemind.ai.memory.core.extraction.insight.scheduler.InsightBuildScheduler;
import com.openmemind.ai.memory.core.extraction.item.MemoryItemLayer;
import com.openmemind.ai.memory.core.extraction.item.extractor.DefaultMemoryItemExtractor;
import com.openmemind.ai.memory.core.extraction.item.strategy.LlmItemExtractionStrategy;
import com.openmemind.ai.memory.core.extraction.item.strategy.LlmToolCallItemExtractionStrategy;
import com.openmemind.ai.memory.core.extraction.rawdata.RawDataLayer;
import com.openmemind.ai.memory.core.extraction.rawdata.caption.CaptionGenerator;
import com.openmemind.ai.memory.core.extraction.rawdata.caption.LlmConversationCaptionGenerator;
import com.openmemind.ai.memory.core.extraction.rawdata.chunk.ConversationChunkingConfig;
import com.openmemind.ai.memory.core.extraction.rawdata.chunk.LlmConversationChunker;
import com.openmemind.ai.memory.core.extraction.rawdata.content.ConversationContent;
import com.openmemind.ai.memory.core.extraction.rawdata.content.ToolCallContent;
import com.openmemind.ai.memory.core.extraction.rawdata.processor.ConversationContentProcessor;
import com.openmemind.ai.memory.core.extraction.rawdata.processor.ToolCallContentProcessor;
import com.openmemind.ai.memory.core.llm.ChatClientRegistry;
import com.openmemind.ai.memory.core.llm.ChatClientSlot;
import com.openmemind.ai.memory.core.llm.StructuredChatClient;
import com.openmemind.ai.memory.core.llm.rerank.NoopReranker;
import com.openmemind.ai.memory.core.prompt.PromptRegistry;
import com.openmemind.ai.memory.core.retrieval.DefaultMemoryRetriever;
import com.openmemind.ai.memory.core.retrieval.deep.LlmTypedQueryExpander;
import com.openmemind.ai.memory.core.retrieval.strategy.DeepRetrievalStrategy;
import com.openmemind.ai.memory.core.retrieval.strategy.RetrievalStrategies;
import com.openmemind.ai.memory.core.retrieval.sufficiency.LlmSufficiencyGate;
import com.openmemind.ai.memory.core.retrieval.tier.InsightTierRetriever;
import com.openmemind.ai.memory.core.retrieval.tier.LlmInsightTypeRouter;
import com.openmemind.ai.memory.core.store.MemoryStore;
import com.openmemind.ai.memory.core.store.insight.InsightOperations;
import com.openmemind.ai.memory.core.store.item.ItemOperations;
import com.openmemind.ai.memory.core.store.rawdata.RawDataOperations;
import com.openmemind.ai.memory.core.textsearch.MemoryTextSearch;
import com.openmemind.ai.memory.core.vector.MemoryVector;
import java.lang.reflect.Proxy;
import java.util.EnumSet;
import java.util.Map;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

class MemoryAssemblersTest {

    private static final StructuredChatClient CHAT_CLIENT = proxy(StructuredChatClient.class);
    private static final RawDataOperations RAW_DATA_OPERATIONS = proxy(RawDataOperations.class);
    private static final ItemOperations ITEM_OPERATIONS = proxy(ItemOperations.class);
    private static final InsightOperations INSIGHT_OPERATIONS = proxy(InsightOperations.class);
    private static final MemoryTextSearch TEXT_SEARCH = proxy(MemoryTextSearch.class);
    private static final InsightBuffer INSIGHT_BUFFER_STORE = proxy(InsightBuffer.class);
    private static final PendingConversationBuffer PENDING_CONVERSATION_BUFFER =
            proxy(PendingConversationBuffer.class);
    private static final RecentConversationBuffer RECENT_CONVERSATION_BUFFER =
            proxy(RecentConversationBuffer.class);
    private static final MemoryBuffer MEMORY_BUFFER =
            MemoryBuffer.of(
                    INSIGHT_BUFFER_STORE, PENDING_CONVERSATION_BUFFER, RECENT_CONVERSATION_BUFFER);
    private static final MemoryVector MEMORY_VECTOR = proxy(MemoryVector.class);
    private static final MemoryStore MEMORY_STORE =
            new MemoryStore() {
                @Override
                public RawDataOperations rawDataOperations() {
                    return RAW_DATA_OPERATIONS;
                }

                @Override
                public ItemOperations itemOperations() {
                    return ITEM_OPERATIONS;
                }

                @Override
                public InsightOperations insightOperations() {
                    return INSIGHT_OPERATIONS;
                }
            };
    private static final CommitDetectorConfig CUSTOM_COMMIT_DETECTION =
            new CommitDetectorConfig(6, 2048, 4);
    private static final InsightBuildConfig CUSTOM_INSIGHT_BUILD =
            new InsightBuildConfig(7, 5, 3, 2);

    @Test
    void extractionAssemblerUsesNestedRawdataAndInsightOptions() {
        MemoryAssemblyContext context =
                context(
                        Map.of(),
                        MemoryBuildOptions.builder()
                                .extraction(
                                        new ExtractionOptions(
                                                ExtractionCommonOptions.defaults(),
                                                new RawDataExtractionOptions(
                                                        ConversationChunkingConfig.DEFAULT,
                                                        CUSTOM_COMMIT_DETECTION),
                                                ItemExtractionOptions.defaults(),
                                                new InsightExtractionOptions(
                                                        true, CUSTOM_INSIGHT_BUILD)))
                                .build());

        MemoryExtractionAssembly assembly = new MemoryExtractionAssembler().assemble(context);
        MemoryExtractor extractor = (MemoryExtractor) assembly.pipeline();
        InsightLayer insightLayer = assembly.insightLayer();

        RawDataLayer rawDataLayer = readField(extractor, "rawDataStep", RawDataLayer.class);
        CaptionGenerator defaultCaptionGenerator =
                readField(rawDataLayer, "defaultCaptionGenerator", CaptionGenerator.class);
        @SuppressWarnings("unchecked")
        Map<Class<?>, Object> processors = readField(rawDataLayer, "processors", Map.class);
        ConversationContentProcessor conversationProcessor =
                (ConversationContentProcessor) processors.get(ConversationContent.class);
        CaptionGenerator processorCaptionGenerator =
                readField(conversationProcessor, "captionGenerator", CaptionGenerator.class);
        LlmContextCommitDetector actualBoundaryDetector =
                readField(extractor, "contextCommitDetector", LlmContextCommitDetector.class);
        InsightBuildScheduler scheduler =
                readField(insightLayer, "scheduler", InsightBuildScheduler.class);
        MemoryStore rawDataStore = readField(rawDataLayer, "memoryStore", MemoryStore.class);
        PendingConversationBuffer pendingConversationBuffer =
                readField(extractor, "pendingConversationBuffer", PendingConversationBuffer.class);
        InsightBuffer insightBuffer = readField(scheduler, "bufferStore", InsightBuffer.class);

        assertThat(processorCaptionGenerator).isSameAs(defaultCaptionGenerator);
        assertThat(readField(actualBoundaryDetector, "config", CommitDetectorConfig.class))
                .isEqualTo(CUSTOM_COMMIT_DETECTION);
        assertThat(readField(scheduler, "config", InsightBuildConfig.class))
                .isEqualTo(CUSTOM_INSIGHT_BUILD);
        assertThat(rawDataStore).isSameAs(MEMORY_STORE);
        assertThat(pendingConversationBuffer).isSameAs(PENDING_CONVERSATION_BUFFER);
        assertThat(insightBuffer).isSameAs(INSIGHT_BUFFER_STORE);
    }

    @Test
    void retrievalAssemblerRegistersBuiltInStrategiesAndUsesDataStore() {
        MemoryAssemblyContext context = context();

        DefaultMemoryRetriever retriever = new MemoryRetrievalAssembler().assemble(context);

        @SuppressWarnings("unchecked")
        Map<String, Object> strategies = readField(retriever, "strategies", Map.class);
        MemoryStore store = readField(retriever, "memoryStore", MemoryStore.class);
        assertThat(strategies.keySet())
                .containsExactlyInAnyOrder(
                        RetrievalStrategies.SIMPLE, RetrievalStrategies.DEEP_RETRIEVAL);
        assertThat(store).isSameAs(MEMORY_STORE);
    }

    @Test
    void extractionAssemblerConversationCategoriesUseNewAgentTaxonomy() {
        MemoryExtractionAssembler assembler = new MemoryExtractionAssembler();

        @SuppressWarnings("unchecked")
        EnumSet<MemoryCategory> categories =
                invokeNoArgMethod(assembler, "conversationCategories", EnumSet.class);

        assertThat(categories)
                .containsExactly(
                        MemoryCategory.PROFILE,
                        MemoryCategory.BEHAVIOR,
                        MemoryCategory.EVENT,
                        MemoryCategory.DIRECTIVE,
                        MemoryCategory.PLAYBOOK,
                        MemoryCategory.RESOLUTION);
    }

    @Test
    void extractionAssemblerRoutesSlotSpecificClients() {
        StructuredChatClient captionClient = proxy(StructuredChatClient.class);
        StructuredChatClient chunkerClient = proxy(StructuredChatClient.class);
        StructuredChatClient toolCallClient = proxy(StructuredChatClient.class);
        StructuredChatClient itemClient = proxy(StructuredChatClient.class);
        StructuredChatClient insightClient = proxy(StructuredChatClient.class);
        StructuredChatClient groupClient = proxy(StructuredChatClient.class);
        StructuredChatClient boundaryClient = proxy(StructuredChatClient.class);

        MemoryExtractionAssembly assembly =
                new MemoryExtractionAssembler()
                        .assemble(
                                context(
                                        Map.of(
                                                ChatClientSlot.CAPTION_GENERATOR, captionClient,
                                                ChatClientSlot.CONVERSATION_CHUNKER, chunkerClient,
                                                ChatClientSlot.TOOL_CALL_EXTRACTION, toolCallClient,
                                                ChatClientSlot.ITEM_EXTRACTION, itemClient,
                                                ChatClientSlot.INSIGHT_GENERATOR, insightClient,
                                                ChatClientSlot.INSIGHT_GROUP_CLASSIFIER,
                                                        groupClient,
                                                ChatClientSlot.CONTEXT_COMMIT_DETECTOR,
                                                        boundaryClient),
                                        MemoryBuildOptions.defaults()));

        MemoryExtractor extractor = (MemoryExtractor) assembly.pipeline();
        RawDataLayer rawDataLayer = readField(extractor, "rawDataStep", RawDataLayer.class);
        LlmConversationCaptionGenerator captionGenerator =
                readField(
                        rawDataLayer,
                        "defaultCaptionGenerator",
                        LlmConversationCaptionGenerator.class);
        @SuppressWarnings("unchecked")
        Map<Class<?>, Object> processors = readField(rawDataLayer, "processors", Map.class);
        ConversationContentProcessor conversationProcessor =
                (ConversationContentProcessor) processors.get(ConversationContent.class);
        ToolCallContentProcessor toolCallProcessor =
                (ToolCallContentProcessor) processors.get(ToolCallContent.class);
        LlmConversationChunker llmChunker =
                readField(
                        conversationProcessor,
                        "llmConversationChunker",
                        LlmConversationChunker.class);
        LlmToolCallItemExtractionStrategy toolCallStrategy =
                readField(
                        toolCallProcessor,
                        "itemExtractionStrategy",
                        LlmToolCallItemExtractionStrategy.class);
        MemoryItemLayer memoryItemLayer =
                readField(extractor, "memoryItemStep", MemoryItemLayer.class);
        DefaultMemoryItemExtractor itemExtractor =
                readField(memoryItemLayer, "extractor", DefaultMemoryItemExtractor.class);
        LlmItemExtractionStrategy itemStrategy =
                readField(itemExtractor, "defaultStrategy", LlmItemExtractionStrategy.class);
        InsightBuildScheduler scheduler =
                readField(assembly.insightLayer(), "scheduler", InsightBuildScheduler.class);
        LlmInsightGenerator insightGenerator =
                readField(scheduler, "generator", LlmInsightGenerator.class);
        LlmInsightGroupClassifier insightGroupClassifier =
                readField(scheduler, "groupClassifier", LlmInsightGroupClassifier.class);
        LlmContextCommitDetector boundaryDetector =
                readField(extractor, "contextCommitDetector", LlmContextCommitDetector.class);

        assertThat(readField(captionGenerator, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(captionClient);
        assertThat(readField(llmChunker, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(chunkerClient);
        assertThat(readField(toolCallStrategy, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(toolCallClient);
        assertThat(readField(itemStrategy, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(itemClient);
        assertThat(readField(insightGenerator, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(insightClient);
        assertThat(
                        readField(
                                insightGroupClassifier,
                                "structuredChatClient",
                                StructuredChatClient.class))
                .isSameAs(groupClient);
        assertThat(readField(boundaryDetector, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(boundaryClient);
    }

    @Test
    void retrievalAssemblerRoutesSlotSpecificClients() {
        StructuredChatClient routerClient = proxy(StructuredChatClient.class);
        StructuredChatClient sufficiencyClient = proxy(StructuredChatClient.class);
        StructuredChatClient queryExpanderClient = proxy(StructuredChatClient.class);

        DefaultMemoryRetriever retriever =
                new MemoryRetrievalAssembler()
                        .assemble(
                                context(
                                        Map.of(
                                                ChatClientSlot.INSIGHT_TYPE_ROUTER, routerClient,
                                                ChatClientSlot.SUFFICIENCY_GATE, sufficiencyClient,
                                                ChatClientSlot.QUERY_EXPANDER, queryExpanderClient),
                                        MemoryBuildOptions.defaults()));

        @SuppressWarnings("unchecked")
        Map<String, Object> strategies = readField(retriever, "strategies", Map.class);
        DeepRetrievalStrategy deepStrategy =
                (DeepRetrievalStrategy) strategies.get(RetrievalStrategies.DEEP_RETRIEVAL);
        InsightTierRetriever insightRetriever =
                readField(deepStrategy, "insightRetriever", InsightTierRetriever.class);
        LlmInsightTypeRouter insightTypeRouter =
                readField(insightRetriever, "router", LlmInsightTypeRouter.class);
        LlmSufficiencyGate sufficiencyGate =
                readField(deepStrategy, "sufficiencyGate", LlmSufficiencyGate.class);
        LlmTypedQueryExpander typedQueryExpander =
                readField(deepStrategy, "typedQueryExpander", LlmTypedQueryExpander.class);

        assertThat(readField(insightTypeRouter, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(routerClient);
        assertThat(readField(sufficiencyGate, "structuredChatClient", StructuredChatClient.class))
                .isSameAs(sufficiencyClient);
        assertThat(
                        readField(
                                typedQueryExpander,
                                "structuredChatClient",
                                StructuredChatClient.class))
                .isSameAs(queryExpanderClient);
    }

    private static MemoryAssemblyContext context() {
        return context(Map.of(), MemoryBuildOptions.defaults());
    }

    private static MemoryAssemblyContext context(
            Map<ChatClientSlot, StructuredChatClient> slotClients, MemoryBuildOptions options) {
        return new MemoryAssemblyContext(
                new ChatClientRegistry(CHAT_CLIENT, slotClients),
                MEMORY_STORE,
                MEMORY_BUFFER,
                TEXT_SEARCH,
                MEMORY_VECTOR,
                new NoopReranker(),
                PromptRegistry.EMPTY,
                options);
    }

    @SuppressWarnings("unchecked")
    private static <T> T proxy(Class<T> type) {
        return (T)
                Proxy.newProxyInstance(
                        type.getClassLoader(),
                        new Class<?>[] {type},
                        (instance, method, args) -> {
                            if (method.getDeclaringClass() == Object.class) {
                                return switch (method.getName()) {
                                    case "toString" -> type.getSimpleName() + "Proxy";
                                    case "hashCode" -> System.identityHashCode(instance);
                                    case "equals" -> instance == args[0];
                                    default -> method.invoke(instance, args);
                                };
                            }

                            Class<?> returnType = method.getReturnType();
                            if (returnType == void.class) {
                                return null;
                            }
                            if (returnType == boolean.class) {
                                return false;
                            }
                            if (returnType == int.class) {
                                return 0;
                            }
                            if (returnType == long.class) {
                                return 0L;
                            }
                            if (returnType == float.class) {
                                return 0F;
                            }
                            if (returnType == double.class) {
                                return 0D;
                            }
                            if (returnType == java.util.Optional.class) {
                                return java.util.Optional.empty();
                            }
                            if (returnType == java.util.List.class) {
                                return java.util.List.of();
                            }
                            if (returnType == java.util.Set.class) {
                                return java.util.Set.of();
                            }
                            if (returnType == java.util.Map.class) {
                                return java.util.Map.of();
                            }
                            if (returnType == Mono.class) {
                                return Mono.empty();
                            }
                            if (returnType == Flux.class) {
                                return Flux.empty();
                            }
                            return null;
                        });
    }

    @SuppressWarnings("unchecked")
    private static <T> T readField(Object target, String fieldName, Class<T> fieldType) {
        try {
            var field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            return (T) fieldType.cast(field.get(target));
        } catch (ReflectiveOperationException e) {
            throw new AssertionError(
                    "Failed to read field '" + fieldName + "' from " + target.getClass(), e);
        }
    }

    @SuppressWarnings("unchecked")
    private static <T> T invokeNoArgMethod(Object target, String methodName, Class<T> returnType) {
        try {
            var method = target.getClass().getDeclaredMethod(methodName);
            method.setAccessible(true);
            return (T) returnType.cast(method.invoke(target));
        } catch (ReflectiveOperationException e) {
            throw new AssertionError(
                    "Failed to invoke method '" + methodName + "' on " + target.getClass(), e);
        }
    }
}
