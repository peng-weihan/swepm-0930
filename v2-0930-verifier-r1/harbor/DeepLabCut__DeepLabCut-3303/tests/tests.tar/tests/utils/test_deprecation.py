#
# DeepLabCut Toolbox (deeplabcut.org)
# © A. & M.W. Mathis Labs
# https://github.com/DeepLabCut/DeepLabCut
#
# Please see AUTHORS for contributors.
# https://github.com/DeepLabCut/DeepLabCut/blob/main/AUTHORS
#
# Licensed under GNU Lesser General Public License v3.0
#
import re
import warnings
from collections.abc import Mapping
from dataclasses import fields, is_dataclass

import pytest
from packaging.version import Version

from deeplabcut.utils.deprecation import (
    DLCDeprecationWarning,
    deprecated,
    renamed_parameter,
)

def _metadata_values(metadata):
    """Read required metadata content without prescribing its storage schema.

    The issue names metadata attributes and their information, not a dataclass,
    a ``kind`` discriminator, field spellings, or whether a record is a mapping.
    This helper reads existing values only; it does not fabricate missing data.
    """
    def structured(value):
        return (
            isinstance(value, (Mapping, list, tuple))
            or (is_dataclass(value) and not isinstance(value, type))
            or (not callable(value) and hasattr(value, "__dict__"))
        )

    assert structured(metadata), "metadata must be structured, not an opaque string"
    values = []
    visited = set()

    def visit(value):
        if isinstance(value, (str, Version)) or callable(value) or value is None:
            values.append(value)
            return
        if id(value) in visited:
            return
        visited.add(id(value))
        if isinstance(value, Mapping):
            for key, item in value.items():
                # A mapping keyed by the deprecated name is also structured
                # metadata: the key carries the old-name information.
                visit(key)
                visit(item)
        elif isinstance(value, (list, tuple)):
            for item in value:
                visit(item)
        elif is_dataclass(value):
            for field in fields(value):
                visit(getattr(value, field.name))
        elif hasattr(value, "__dict__"):
            for item in vars(value).values():
                visit(item)
        else:
            values.append(value)

    visit(metadata)
    return values


def _contains_target(values, target):
    for value in values:
        if callable(value) and getattr(value, "__qualname__", None) == target.__qualname__:
            return True
        if isinstance(value, str) and (
            value == target.__name__ or value == target.__qualname__
            or value.endswith("." + target.__qualname__)
        ):
            return True
    return False


# ---------------------------------------------------------------------------
# @deprecated
# ---------------------------------------------------------------------------


def test_deprecated_emits_deprecation_warning():
    @deprecated()
    def old_fn():
        return 42

    with pytest.warns(DLCDeprecationWarning):
        result = old_fn()

    assert result == 42


def test_deprecated_warning_contains_function_name():
    @deprecated()
    def my_old_function():
        pass

    with pytest.warns(DLCDeprecationWarning, match="my_old_function"):
        my_old_function()


def test_deprecated_warning_contains_replacement():
    @deprecated(replacement="new_module.new_fn")
    def old_fn():
        pass

    with pytest.warns(DLCDeprecationWarning, match="new_module.new_fn"):
        old_fn()


def test_deprecated_warning_contains_since_and_removed_in():
    @deprecated(since="3.1", removed_in="4.0")
    def old_fn():
        pass

    with pytest.warns(DLCDeprecationWarning, match="3.1") as record:
        old_fn()

    assert "4.0" in str(record[0].message)


def test_deprecated_preserves_return_value_and_args():
    @deprecated()
    def add(a, b):
        return a + b

    with pytest.warns(DLCDeprecationWarning):
        assert add(2, 3) == 5


def test_deprecated_preserves_name_and_docstring():
    @deprecated(replacement="new_fn")
    def documented_fn():
        """Original docstring."""

    assert documented_fn.__name__ == "documented_fn"
    assert "Original docstring." in documented_fn.__doc__


def test_deprecated_attaches_metadata():
    @deprecated(replacement="new_fn", since="3.1", removed_in="4.0")
    def old_fn():
        pass

    values = _metadata_values(old_fn.__deprecated_info__)
    assert _contains_target(values, old_fn)
    assert "new_fn" in values
    assert any(isinstance(value, Version) and value == Version("3.1") for value in values)
    assert any(isinstance(value, Version) and value == Version("4.0") for value in values)


def test_deprecated_invalid_since_raises():
    with pytest.raises(ValueError):

        @deprecated(since="not-a-version")
        def old_fn():
            pass


def test_deprecated_invalid_removed_in_raises():
    with pytest.raises(ValueError):

        @deprecated(removed_in="definitely-not-a-version")
        def old_fn():
            pass


@pytest.mark.parametrize("removed_in", ["4.0", "3.9"])
def test_deprecated_removed_in_must_be_greater_than_since(removed_in):
    with pytest.raises(ValueError):

        @deprecated(since="4.0", removed_in=removed_in)
        def old_fn():
            pass


# ---------------------------------------------------------------------------
# @renamed_parameter
# ---------------------------------------------------------------------------


def test_renamed_parameter_old_name_emits_warning():
    @renamed_parameter(old="in_random_order", new="shuffle")
    def fn(shuffle=False):
        return shuffle

    with pytest.warns(DLCDeprecationWarning):
        fn(in_random_order=True)


def test_renamed_parameter_old_name_is_forwarded():
    @renamed_parameter(old="in_random_order", new="shuffle")
    def fn(shuffle=False):
        return shuffle

    with pytest.warns(DLCDeprecationWarning):
        result = fn(in_random_order=True)

    assert result is True


def test_renamed_parameter_new_name_no_warning():
    @renamed_parameter(old="in_random_order", new="shuffle")
    def fn(shuffle=False):
        return shuffle

    # No warning should be emitted when using the current name.
    with warnings.catch_warnings():
        warnings.simplefilter("error", DLCDeprecationWarning)
        result = fn(shuffle=True)

    assert result is True


def test_renamed_parameter_warning_contains_names():
    @renamed_parameter(old="videotype", new="extensions", since="3.2")
    def fn(extensions=None):
        return extensions

    with pytest.warns(DLCDeprecationWarning, match="videotype") as record:
        fn(videotype="mp4")

    message = str(record[0].message)
    assert "extensions" in message
    assert "3.2" in message


def test_renamed_parameter_preserves_name():
    @renamed_parameter(old="foo", new="bar")
    def my_fn(bar=None):
        """Docstring."""

    assert my_fn.__name__ == "my_fn"


def test_renamed_parameter_old_and_new_together_raise():
    @renamed_parameter(old="videotype", new="extensions")
    def fn(extensions=None):
        return extensions

    with pytest.raises(TypeError) as caught:
        fn(videotype="mp4", extensions="avi")

    message = str(caught.value).lower()
    assert "videotype" in message and "extensions" in message
    assert re.search(r"\b(both|together|simultaneously|conflict(?:ing)?|mutually exclusive)\b", message)
    assert re.search(r"(?:only|use|prefer|instead).*extensions|extensions.*(?:only|instead)", message)


def test_renamed_parameter_attaches_metadata():
    @renamed_parameter(old="videotype", new="extensions", since="3.2")
    def fn(extensions=None):
        return extensions

    values = _metadata_values(fn.__deprecated_params__)
    assert "videotype" in values
    assert "extensions" in values
    assert _contains_target(values, fn)
    assert any(isinstance(value, Version) and value == Version("3.2") for value in values)


def test_renamed_parameter_invalid_since_raises():
    with pytest.raises(ValueError):

        @renamed_parameter(old="videotype", new="extensions", since="invalid-version")
        def fn(extensions=None):
            return extensions
