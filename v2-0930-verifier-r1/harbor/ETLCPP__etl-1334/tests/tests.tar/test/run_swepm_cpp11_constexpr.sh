#!/bin/bash
set -euo pipefail

# Draft verifier hook. Invoke only after authorization for the small compile.
# REPO is the candidate worktree; OUTPUT must be a fresh persistent log/build
# directory. The container's /logs/verifier must be host-/data-backed.
if [[ $# != 2 ]]; then
  echo "usage: run_swepm_cpp11_constexpr.sh REPO FRESH_OUTPUT_DIR" >&2
  exit 64
fi
repo=$(cd "$1" && pwd -P)
parent=$(cd "$(dirname -- "$2")" && pwd -P)
leaf=$(basename -- "$2")
case "$leaf" in .|..|"") echo "CPP11_SETUP_ERROR invalid output name" >&2; exit 64 ;; esac
output="$parent/$leaf"
case "$output" in
  /data/*|/logs/verifier/*) ;;
  *) echo "CPP11_SETUP_ERROR output must be persistent /data or verifier logs" >&2; exit 64 ;;
esac
if [[ -e "$output" || -L "$output" ]]; then
  echo "CPP11_SETUP_ERROR output already exists; require a fresh directory" >&2
  exit 64
fi
compiler=$(command -v g++) || {
  echo "CPP11_SETUP_ERROR existing g++ unavailable; no installation attempted" >&2
  exit 69
}
test -f "$repo/test/swepm_cpp11_constexpr_contract.cpp"
available_kib=$(df -Pk "$parent" | awk 'NR == 2 {print $4}')
if [[ ! "$available_kib" =~ ^[0-9]+$ ]] || (( available_kib < 16384 )); then
  echo "CPP11_SETUP_ERROR less than 16 MiB free for this small standalone compile" >&2
  exit 73
fi
mkdir -p "$output"
mkdir "$output/tmp"
export TMPDIR="$output/tmp"
df -Pk "$output"
"$compiler" --version

for checked in 1 0; do
  executable="$output/constexpr-cpp11-checked-$checked"
  echo "CPP11_COMPILE checked=$checked standard=c++11"
  "$compiler" -std=c++11 -pedantic-errors -O0 -g0 \
    -I"$repo/include" -DSWEPM_ETL_CHECKED="$checked" \
    "$repo/test/swepm_cpp11_constexpr_contract.cpp" -o "$executable"
  "$executable"
done
echo "CPP11_CONSTEXPR_CONTRACT_PASSED checked_and_unchecked"
