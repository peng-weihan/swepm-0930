// Independent C++11 public-contract check. No UnitTest++ or production edits.
// The runner builds this twice: optional checks enabled, then disabled.
#if __cplusplus != 201103L
#error "This contract test must actually be compiled as C++11."
#endif

#if !defined(SWEPM_ETL_CHECKED) || (SWEPM_ETL_CHECKED != 0 && SWEPM_ETL_CHECKED != 1)
#error "The test runner must explicitly select the checked or unchecked profile."
#endif

// These configuration switches already exist in the base library/profile.
#define ETL_NO_PROFILE_HEADER
#define ETL_THROW_EXCEPTIONS
#if SWEPM_ETL_CHECKED
#define ETL_CHECK_INDEX_OPERATOR
#define ETL_CHECK_EXTRA
#endif

#include "etl/array_wrapper.h"
#include "etl/string_view.h"
#include <cstddef>
#include <cstdio>

// Explicit pointer/range constructors were constexpr in the base public API.
// A NUL inside the view also rules out treating it as a C-string by accident.
constexpr char compile_chars[] = {'L', 'a', '\0', 'z', 'R'};
constexpr etl::string_view compile_view(compile_chars + 1, std::size_t(3));
constexpr etl::string_view range_view(compile_chars + 1, compile_chars + 4);
static_assert(compile_view.front() == 'a', "cpp11_string_front_constant_value");
static_assert(compile_view.back() == 'z', "cpp11_string_back_constant_value");
static_assert(compile_view[0] == 'a', "cpp11_string_first_index_constant_value");
static_assert(compile_view[1] == '\0', "cpp11_string_embedded_nul_constant_value");
static_assert(compile_view[2] == 'z', "cpp11_string_last_index_constant_value");
static_assert(range_view.front() == 'a' && range_view.back() == 'z',
              "cpp11_string_pointer_range_constant_values");
static_assert(&compile_view.front() == compile_chars + 1,
              "cpp11_string_front_returns_original_reference");
static_assert(&compile_view.back() == compile_chars + 3,
              "cpp11_string_back_returns_original_reference");
static_assert(&compile_view[1] == compile_chars + 2,
              "cpp11_string_index_returns_original_reference");

// External linkage meets the base array_wrapper's C++11 reference template
// parameter requirements. Only its existing const operator[] is constexpr.
extern constexpr int compile_numbers[] = {7, 19, 31, 43};
typedef etl::array_wrapper<const int, 4, compile_numbers> ConstantWrapper;
constexpr ConstantWrapper compile_wrapper = {};
static_assert(compile_wrapper[0] == 7, "cpp11_array_first_constant_value");
static_assert(compile_wrapper[2] == 31, "cpp11_array_middle_constant_value");
static_assert(compile_wrapper[3] == 43, "cpp11_array_last_constant_value");
static_assert(&compile_wrapper[2] == compile_numbers + 2,
              "cpp11_array_index_returns_original_reference");

int runtime_numbers[] = {17, 29, 43, 61};
typedef etl::array_wrapper<int, 4, runtime_numbers> MutableWrapper;

#if SWEPM_ETL_CHECKED
// An enabled bounds check must be allowed to propagate the configured error.
static_assert(!noexcept(compile_view[0]), "cpp11_checked_string_index_can_throw");
static_assert(!noexcept(compile_wrapper[0]), "cpp11_checked_const_array_index_can_throw");
#else
// Both operators were noexcept in the base when no optional checks execute.
static_assert(noexcept(compile_view[0]), "cpp11_unchecked_string_index_keeps_noexcept");
static_assert(noexcept(compile_wrapper[0]), "cpp11_unchecked_const_array_index_keeps_noexcept");
#endif

namespace
{
  unsigned checks = 0;
  unsigned failures = 0;

  void check(bool condition, const char* name)
  {
    ++checks;
    if (!condition)
    {
      ++failures;
      std::fprintf(stderr, "CPP11_CONTRACT_FAIL %s\n", name);
    }
  }

  template <typename Expected, typename Operation>
  void expect_error(Operation operation, const char* name)
  {
    bool caught_expected = false;
    try
    {
      operation();
    }
    catch (const Expected&)
    {
      caught_expected = true;
    }
    catch (...)
    {
      // An unrelated exception cannot satisfy the existing container family.
    }
    check(caught_expected, name);
  }
}

int main()
{
  char runtime_chars[] = {'L', 'a', '\0', 'z', 'R'};
  const etl::string_view view(runtime_chars + 1, std::size_t(3));
  check(view.front() == 'a', "string_front_runtime_value");
  check(view.back() == 'z', "string_back_runtime_value");
  check(view[0] == 'a' && view[1] == '\0' && view[2] == 'z', "string_index_runtime_values");
  check(&view.front() == runtime_chars + 1 && &view.back() == runtime_chars + 3,
        "string_runtime_references");

  MutableWrapper wrapper;
  const MutableWrapper& const_wrapper = wrapper;
  wrapper[1] = 37;
  check(runtime_numbers[1] == 37, "mutable_array_index_updates_backing_storage");
  check(const_wrapper[0] == 17 && const_wrapper[1] == 37 && const_wrapper[3] == 61,
        "const_array_runtime_values");
  check(&const_wrapper[1] == runtime_numbers + 1, "const_array_runtime_reference");

#if SWEPM_ETL_CHECKED
  // These existing exception families predate the patch. New leaf class names
  // and the implementation's internal constexpr helper/macro names are free.
  volatile std::size_t boundary = view.size();
  expect_error<etl::string_view_exception>([&]() {
    volatile char value = view[boundary];
    (void)value;
  }, "checked_string_index_at_size_throws");

  // Non-null zero-length range: both missing-check reads would still point
  // within runtime_chars, so a negative control has a deterministic failure.
  const etl::string_view empty_range(runtime_chars + 2, runtime_chars + 2);
  expect_error<etl::string_view_exception>([&]() {
    volatile char value = empty_range.front();
    (void)value;
  }, "checked_nonnull_empty_string_front_throws");
  expect_error<etl::string_view_exception>([&]() {
    volatile char value = empty_range.back();
    (void)value;
  }, "checked_nonnull_empty_string_back_throws");

  volatile std::size_t array_boundary = wrapper.size();
  expect_error<etl::array_wrapper_exception>([&]() {
    // Do not load a possibly unchecked out-of-range value from a bad candidate.
    const int* value = &const_wrapper[array_boundary];
    (void)value;
  }, "checked_const_array_index_at_size_throws");
  expect_error<etl::array_wrapper_exception>([&]() {
    int* value = &wrapper[array_boundary];
    (void)value;
  }, "checked_mutable_array_index_at_size_throws");
#endif

  std::printf("CPP11_CONSTEXPR_PROFILE checked=%d runtime_checks=%u failures=%u\n",
              SWEPM_ETL_CHECKED, checks, failures);
  return failures == 0 ? 0 : 1;
}
