/*
 * Unit tests for Brandt Noise Estimator
 */

#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../src/shared/configurations.h"
#include "../src/shared/noise_estimation/brandt_noise_estimator.h"
#include "../src/shared/utils/spectral_utils.h"

#define TEST_ASSERT(condition, message)                                        \
  do {                                                                         \
    if (!(condition)) {                                                        \
      fprintf(stderr, "TEST FAILED: %s\n", message);                           \
      exit(1);                                                                 \
    }                                                                          \
  } while (0)

#define TEST_FLOAT_CLOSE(a, b, tolerance)                                      \
  TEST_ASSERT(fabsf((a) - (b)) < (tolerance), "Float values not close enough")

void test_brandt_initialization(void) {
  printf("Testing Brandt initialization...\n");

  uint32_t real_size = 257;
  float duration = 1000.0f;
  uint32_t sr = 44100;
  uint32_t fft_size = 512;

  BrandtNoiseEstimator* est =
      brandt_noise_estimator_initialize(real_size, duration, sr, fft_size);
  TEST_ASSERT(est != NULL, "Initialization should succeed");

  brandt_noise_estimator_free(est);
  brandt_noise_estimator_free(NULL); // Should be safe
  printf("✓ Brandt initialization tests passed\n");
}

void test_brandt_run_logic(void) {
  printf("Testing Brandt run logic...\n");

  uint32_t real_size = 64;
  uint32_t sr = 44100;
  uint32_t fft_size = 128;

  BrandtNoiseEstimator* est =
      brandt_noise_estimator_initialize(real_size, 500.0f, sr, fft_size);

  float* spectrum = (float*)calloc(real_size, sizeof(float));
  float* noise_spectrum = (float*)calloc(real_size, sizeof(float));

  for (uint32_t i = 0; i < real_size; i++) {
    spectrum[i] = 1.0f;
  }

  // Use set_state to bypass the learning period/confidence rejected start
  brandt_noise_estimator_set_state(est, spectrum);

  TEST_ASSERT(brandt_noise_estimator_run(est, spectrum, noise_spectrum),
              "Run should succeed");
  // Check output matches the set state
  for (uint32_t i = 0; i < real_size; i++) {
    TEST_FLOAT_CLOSE(noise_spectrum[i], 1.0f, 1e-4f);
  }

  // Silence check logic
  for (uint32_t i = 0; i < real_size; i++) {
    spectrum[i] = 0.0f;
  }
  TEST_ASSERT(brandt_noise_estimator_run(est, spectrum, noise_spectrum),
              "Run should succeed in silence");
  // Should keep output from previous state (1.0) due to silence threshold skip
  for (uint32_t i = 0; i < real_size; i++) {
    TEST_FLOAT_CLOSE(noise_spectrum[i], 1.0f, 1e-4f);
  }

  // NULL checks
  TEST_ASSERT(!brandt_noise_estimator_run(NULL, spectrum, noise_spectrum),
              "Should fail with NULL estimator");
  TEST_ASSERT(!brandt_noise_estimator_run(est, NULL, noise_spectrum),
              "Should fail with NULL input");
  TEST_ASSERT(!brandt_noise_estimator_run(est, spectrum, NULL),
              "Should fail with NULL output");

  brandt_noise_estimator_free(est);
  free(spectrum);
  free(noise_spectrum);
  printf("✓ Brandt run logic tests passed\n");
}

void test_brandt_state_management(void) {
  printf("Testing Brandt state management...\n");

  uint32_t real_size = 64;
  BrandtNoiseEstimator* est =
      brandt_noise_estimator_initialize(real_size, 500.0f, 44100, 128);

  float* profile = (float*)calloc(real_size, sizeof(float));
  for (uint32_t i = 0; i < real_size; i++) {
    profile[i] = 0.5f;
  }

  // Test set state
  brandt_noise_estimator_set_state(est, profile);
  brandt_noise_estimator_set_state(NULL, profile);
  brandt_noise_estimator_set_state(est, NULL);

  // Test update seed
  brandt_noise_estimator_update_seed(est, profile);
  brandt_noise_estimator_update_seed(NULL, profile);
  brandt_noise_estimator_update_seed(est, NULL);

  // Test apply floor
  float* floor = (float*)calloc(real_size, sizeof(float));
  for (uint32_t i = 0; i < real_size; i++) {
    floor[i] = 0.8f;
  }
  brandt_noise_estimator_apply_floor(est, floor);
  brandt_noise_estimator_apply_floor(NULL, floor);
  brandt_noise_estimator_apply_floor(est, NULL);

  brandt_noise_estimator_free(est);
  free(profile);
  free(floor);
  printf("✓ Brandt state management tests passed\n");
}

/*
 * Behavioral regression tests for the opaque Brandt API. These tests never
 * inspect the estimator representation, chosen percentile, sorting algorithm,
 * candidate percentile list, or confidence score.
 *
 * Midpoint quantiles give reproducible exponential noise-power samples without
 * an RNG or fixtures. Different frequency bins see different permutations and
 * means. Eight repeated cycles allow adaptation after a distribution change;
 * tolerances test large observable effects, not reference numeric traces.
 */
enum { LEARNING_BINS = 65, NOISE_PERIOD = 64, LEARNING_FRAMES = 512 };

static float bin_power_scale(uint32_t bin) {
  return 1.0f + (float)bin / (float)LEARNING_BINS;
}

static void make_noise_frame(uint32_t frame, float level, float* spectrum) {
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    uint32_t rank = (17U * frame + 11U * k) % NOISE_PERIOD;
    float quantile = ((float)rank + 0.5f) / (float)NOISE_PERIOD;
    spectrum[k] = -logf(1.0f - quantile) * level * bin_power_scale(k);
  }
}

static void observe_noise_phase(BrandtNoiseEstimator* estimator, float level,
                                float* observed_mean) {
  float input[LEARNING_BINS];
  float output[LEARNING_BINS];
  float minimum[LEARNING_BINS];
  float maximum[LEARNING_BINS];
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    observed_mean[k] = 0.0f;
    minimum[k] = FLT_MAX;
    maximum[k] = 0.0f;
  }
  for (uint32_t frame = 0; frame < LEARNING_FRAMES; frame++) {
    make_noise_frame(frame, level, input);
    TEST_ASSERT(brandt_noise_estimator_run(estimator, input, output),
                "Brandt should accept finite nonnegative noise spectra");
    for (uint32_t k = 0; k < LEARNING_BINS; k++) {
      TEST_ASSERT(isfinite(output[k]) && output[k] >= 0.0f,
                  "Brandt output should stay finite and nonnegative");
      if (frame >= LEARNING_FRAMES - NOISE_PERIOD) {
        observed_mean[k] += output[k] / (float)NOISE_PERIOD;
        minimum[k] = fminf(minimum[k], output[k]);
        maximum[k] = fmaxf(maximum[k], output[k]);
      }
    }
  }
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    TEST_ASSERT(maximum[k] <= 2.0f * minimum[k] + 1e-6f,
                "Stationary noise estimate should not follow individual samples");
  }
}

void test_brandt_learns_changed_noise_power(void) {
  printf("Testing Brandt learning after noise-power changes...\n");
  BrandtNoiseEstimator* est =
      brandt_noise_estimator_initialize(LEARNING_BINS, 512.0f, 8000, 128);
  TEST_ASSERT(est != NULL, "Learning estimator initialization should succeed");
  float seed[LEARNING_BINS];
  float low[LEARNING_BINS];
  float high[LEARNING_BINS];
  float recovered[LEARNING_BINS];
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    seed[k] = bin_power_scale(k);
  }
  brandt_noise_estimator_set_state(est, seed);
  observe_noise_phase(est, 1.0f, low);
  observe_noise_phase(est, 32.0f, high);
  observe_noise_phase(est, 1.0f, recovered);
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    TEST_ASSERT(low[k] > 0.0f,
                "Positive stationary noise should have a positive estimate");
    TEST_ASSERT(high[k] > 4.0f * low[k],
                "Brandt must learn a persistent increase in noise power");
    TEST_ASSERT(high[k] < 64.0f * low[k],
                "Learned noise increase should remain bounded");
    TEST_ASSERT(recovered[k] < high[k] / 4.0f && recovered[k] > 0.0f,
                "Brandt must relearn after noise power decreases");
  }
  brandt_noise_estimator_free(est);
}

void test_brandt_learns_without_seed(void) {
  printf("Testing Brandt learning without an injected noise profile...\n");
  BrandtNoiseEstimator* est =
      brandt_noise_estimator_initialize(LEARNING_BINS, 512.0f, 8000, 128);
  TEST_ASSERT(est != NULL, "Unseeded estimator initialization should succeed");
  float observed[LEARNING_BINS];
  observe_noise_phase(est, 2.0f, observed);
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    float level = 2.0f * bin_power_scale(k);
    TEST_ASSERT(observed[k] > 0.1f * level && observed[k] < 8.0f * level,
                "Unseeded Brandt must learn finite noise power from its input");
  }
  brandt_noise_estimator_free(est);
}

void test_brandt_rejects_persistent_nonnoise_plateau(void) {
  printf("Testing confidence protection against a nonnoise plateau...\n");
  BrandtNoiseEstimator* est =
      brandt_noise_estimator_initialize(LEARNING_BINS, 512.0f, 8000, 128);
  TEST_ASSERT(est != NULL, "Confidence estimator initialization should succeed");
  float baseline[LEARNING_BINS];
  float input[LEARNING_BINS];
  float output[LEARNING_BINS];
  observe_noise_phase(est, 1.0f, baseline);
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    input[k] = 1000.0f * bin_power_scale(k);
  }
  /* Constant power is deliberately inconsistent with noise-power statistics.
   * Do not require an exact confidence score or a bit-for-bit held estimate. */
  for (uint32_t frame = 0; frame < LEARNING_FRAMES; frame++) {
    TEST_ASSERT(brandt_noise_estimator_run(est, input, output),
                "Nonnoise frames should not make processing fail");
  }
  for (uint32_t k = 0; k < LEARNING_BINS; k++) {
    TEST_ASSERT(isfinite(output[k]) && output[k] > 0.0f,
                "Confidence rejection should preserve a usable noise estimate");
    TEST_ASSERT(output[k] < 100.0f * baseline[k],
                "Low-confidence nonnoise plateau must not become the noise floor");
  }
  brandt_noise_estimator_free(est);
}


int main(void) {
  printf("Running Brandt Noise Estimator tests...\n\n");

  test_brandt_initialization();
  test_brandt_run_logic();
  test_brandt_state_management();
  test_brandt_learns_changed_noise_power();
  test_brandt_learns_without_seed();
  test_brandt_rejects_persistent_nonnoise_plateau();

  printf("\n✅ All Brandt tests passed!\n");
  return 0;
}
